# SentinelAI Deployment & Infrastructure Guide

This guide covers production deployment configurations across containerized environments, cloud hosting, and continuous integration.

---

## 1. Containerized Deployment (Docker Compose)

Launch the full stack (PostgreSQL 16, Redis 7, FastAPI Backend, and Vite/Express Frontend):

```bash
docker-compose up -d --build
```

Health check verification:
```bash
curl http://localhost:3000/api/v1/dashboard/summary
```

---

## 2. Environment Variables Specification

Define these in `.env`:

| Variable | Description | Default / Example |
|---|---|---|
| `PORT` | Web server listening port | `3000` |
| `NODE_ENV` | Environment mode | `production` / `development` |
| `GEMINI_API_KEY` | Google Gemini AI Studio API key | Secure injected secret |
| `DATABASE_URL` | PostgreSQL connection string | `postgresql://user:pass@localhost:5432/sentinelai` |
| `REDIS_URL` | Redis task queue connection string | `redis://localhost:6379/0` |

---

## 3. Production Deployment Paths

### Full-Stack Express (Render / Cloud Run / VPS)
- Build command: `npm run build`
- Start command: `npm start` (runs `tsx server.ts` on port 3000)

### Frontend Vercel + Backend Render
- **Frontend**: Connect Git repository to Vercel, set framework to Vite, configure API proxy rewrites to FastAPI backend.
- **Backend**: Deploy `backend/Dockerfile` to Render or AWS ECS with attached managed PostgreSQL and Redis.
