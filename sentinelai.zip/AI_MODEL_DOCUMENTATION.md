# SentinelAI AI/ML Architecture & Model Documentation

SentinelAI incorporates a hybrid AI detection architecture combining probabilistic machine learning and large language models for explainable threat triage.

---

## 1. Large Language Model Integration (SentinelAI Copilot)
- **Model**: `gemini-3.8-flash` via `@google/genai` TypeScript SDK on the server side.
- **Role**: Forensic hypothesis generation, attack narrative correlation, and remediation action formulation.
- **Interface**: Server-side proxy endpoints (`/api/v1/ai/investigate`, `/api/v1/ai/chat`).
- **Telemetry**: HTTP header `User-Agent: aistudio-build`.
- **Structured Schema**:
  ```json
  {
    "summary": "Forensic narrative",
    "risk_level": "critical",
    "evidence": [{"fact": "...", "sourceEventId": "log-...", "verified": true}],
    "possible_attack_techniques": [{"id": "T1110", "name": "Brute Force", "tactic": "Credential Access"}],
    "confidence": 94,
    "recommended_actions": [{"step": "...", "urgency": "immediate"}],
    "limitations": ["..."]
  }
  ```

---

## 2. Statistical Anomaly & Classification Models
- **Anomaly Detection**: Isolation Forest model trained on normalized connection entropy, packet frequency, and credential failure rates.
- **PhishGuard Heuristic Classifier**: Evaluates Levenshtein distance against known brand domains (e.g., PayPal, Microsoft, Google, Chase), TLD reputation, and SPF/DKIM authentication headers.
- **Model Monitoring**: Version tracking and false-positive feedback loops recorded in the audit trail.
