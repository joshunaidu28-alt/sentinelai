# SentinelAI: Intelligent Cybersecurity Operations & SOC Automation Platform

SentinelAI is an enterprise-grade Security Operations Center (SOC) platform engineered to empower security analysts, incident responders, SOC administrators, and security directors. It combines high-throughput event ingestion, hybrid AI/ML threat detection, real-time phishing triage (PhishGuard AI), authorized vulnerability management, and approval-gated SOAR playbooks into a unified, dark SOC command center.

---

## Key Capabilities

1. **Centralized SOC Command Center**: Real-time KPI summaries, event velocity and throughput telemetry, severity distributions, and an AI-generated daily briefing.
2. **High-Throughput Log Management**: Ingests, normalizes, and validates logs from Firewalls, Identity Providers (Active Directory/Kerberos), EDR agents, WAFs, DNS resolvers, and Network TAPs.
3. **Hybrid AI Threat Detection Engine**:
   - Rule-based regex and burst threshold detection.
   - Anomaly detection via Isolation Forest and Z-score deviation.
   - Normalized multi-factor risk scoring (0–29 Low, 30–59 Medium, 60–79 High, 80–100 Critical).
   - Dynamic MITRE ATT&CK Enterprise v14 taxonomy mapping.
4. **End-to-End Alert & Incident Response**:
   - Comprehensive alert lifecycle (New, Open, Investigating, Escalated, Resolved, False Positive).
   - 6-stage incident response progression (`Detected` → `Triaged` → `Investigating` → `Containment Review` → `Recovery` → `Resolved`).
   - Forensic evidence attachments, investigator notes, and immutable timeline auditing.
5. **PhishGuard AI (Phishing & URL Inspection)**:
   - Safe sandbox URL and email body inspection.
   - Domain age, typosquatting, SPF/DKIM verification, and VirusTotal reputation scoring.
   - 1-click containment: DNS firewall domain blocking and email quarantine.
6. **SentinelAI Copilot (AI Forensic Investigation)**:
   - Structured forensic investigation powered by Google Gemini (`gemini-3.8-flash`).
   - Verified log evidence citations, ATT&CK technique extraction, and actionable remediation steps.
   - Interactive Q&A with built-in prompt injection defense.
7. **SOAR Automation & Playbooks**:
   - Celery / Redis background worker execution architecture.
   - 4 pre-configured enterprise playbooks (Brute Force Defense, Phishing Triage, Zero-Day Vulnerability, Network C2 Isolation).
   - Mandatory analyst approval gates for non-reversible perimeter actions.
8. **Compliance & Reporting**:
   - One-click PDF, CSV, and JSON security summaries.
   - Role-Based Access Control (ADMIN, SECURITY_ANALYST, SOC_MANAGER, VIEWER).
   - Immutable append-only audit trail.

---

## Architecture Overview

```
                      +-----------------------------+
                      |   SentinelAI Dark SOC UI    |
                      |  (React 19 + TypeScript +   |
                      |   Tailwind CSS + Lucide)    |
                      +--------------+--------------+
                                     |
                                     | REST API / JSON
                                     v
                      +-----------------------------+
                      |  Full-Stack API Server      |
                      |  (Express / FastAPI Core)   |
                      +--------------+--------------+
                                     |
      +--------------------+---------+---------+--------------------+
      |                    |                   |                    |
      v                    v                   v                    v
+-----------+       +--------------+     +------------+      +--------------+
| Gemini AI |       | Threat Intel |     | PostgreSQL |      | Celery/Redis |
|  Copilot  |       | (VirusTotal) |     |  Database  |      | SOAR Workers |
+-----------+       +--------------+     +------------+      +--------------+
```

---

## Quickstart

### Prerequisites
- Node.js >= 20.x or Docker
- Python 3.11+ (for optional standalone FastAPI backend)

### Running the Applet
```bash
npm install
npm run dev
```
Visit `http://localhost:3000` to access the SentinelAI SOC console.
