# Contributing to SentinelAI

Thank you for contributing to SentinelAI.

---

## Code Quality Standards

1. **TypeScript Strictness**: No implicit `any` where typed interfaces exist.
2. **Deterministic Logic**: Pure detection rules and risk scoring algorithms must be placed in `src/utils/` and covered by automated unit tests in `src/utils/*.test.ts`.
3. **Enterprise SOC Aesthetic**: Maintain the dark command-center aesthetic (#080D18 baseline, #45D6C5 cyan, #438CFF blue). No pill capsules for static metadata.
4. **Security First**: Never expose raw credentials in API responses. Defend against prompt injection by isolating untrusted logs.
5. **Testing**: Run `npx --yes tsx --test src/utils/detection.test.ts` before committing changes.
