# SentinelAI SOAR Automation & Playbook Guide

SentinelAI features an integrated Security Orchestration, Automation, and Response (SOAR) engine powered by background task queues and human-in-the-loop approval gates.

---

## Pre-Configured Playbooks

### Playbook 1: Repeated Login Failures / Brute Force Defense
- **Trigger**: Ingestion of `>= 5` failed logins within 60s from single source IP.
- **Workflow**:
  1. Parse source IP & auth payload.
  2. Query Threat Intelligence (Tor exit nodes, AbuseIPDB).
  3. Calculate normalized risk score.
  4. Notify on-call analyst via webhook/Slack.
  5. *Approval Gate*: Perimeter firewall ACL block request.

### Playbook 2: High-Risk Phishing Triage & Containment
- **Trigger**: PhishGuard AI detection score `>= 60` or brand typosquatting match.
- **Workflow**:
  1. Extract embedded URLs and header hashes.
  2. Query VirusTotal URL reputation.
  3. Declare high-priority incident (INC-2026-PHISH).
  4. *Approval Gate*: Purge email message from all recipient exchange inboxes.

### Playbook 3: Critical CVE Zero-Day Patching
- **Trigger**: Vulnerability detected on Tier-1 asset with CVSS `>= 9.0`.
- **Workflow**:
  1. Verify asset criticality and external network exposure.
  2. Generate remediation guidance.
  3. *Approval Gate*: Deploy emergency firewall mitigation filter.

### Playbook 4: Suspicious Network Beaconing Isolation
- **Trigger**: Outbound DNS tunneling or high-entropy C2 connection confirmed.
- **Workflow**:
  1. Capture 60-second connection flow metadata.
  2. Declare P1 incident.
  3. *Approval Gate*: Isolate host interface via EDR agent.

---

## n8n & External Webhook Integration
SentinelAI supports signed outbound webhooks to n8n, ServiceNow, and Slack with HMAC-SHA256 signature headers and replay prevention.
