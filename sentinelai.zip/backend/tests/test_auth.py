"""
Unit tests for SentinelAI FastAPI backend authentication module
Tests Argon2 password hashing, verification, JWT creation, and session validation.
"""

import sys
import os
import unittest

# Add backend directory to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.auth import (
    get_password_hash,
    verify_password,
    create_access_token,
    decode_access_token,
    register_session,
    revoke_token,
    is_token_revoked,
)

class TestFastApiAuthentication(unittest.TestCase):
    def test_argon2_password_hashing_and_verification(self):
        plain_password = "SuperSecretSOCPassword2026!#"
        hashed = get_password_hash(plain_password)

        self.assertTrue(hashed.startswith("$argon2id$") or len(hashed) > 20)
        # Verify valid password
        self.assertTrue(verify_password(plain_password, hashed))
        # Verify invalid password rejected
        self.assertFalse(verify_password("WrongPassword123!", hashed))

    def test_jwt_token_generation_and_decoding(self):
        claims = {
            "sub": "usr-admin-01",
            "email": "alex.vance@sentinelai.internal",
            "role": "ADMIN",
            "name": "Alex Vance",
        }
        token = create_access_token(claims)
        self.assertIsInstance(token, str)
        self.assertEqual(len(token.split(".")), 3)

        decoded = decode_access_token(token)
        self.assertIsNotNone(decoded)
        self.assertEqual(decoded["email"], "alex.vance@sentinelai.internal")
        self.assertEqual(decoded["role"], "ADMIN")
        self.assertEqual(decoded["iss"], "sentinelai-soc")

    def test_jwt_tampered_signature_rejection(self):
        claims = {"sub": "usr-test", "email": "test@sentinelai.internal", "role": "VIEWER"}
        token = create_access_token(claims)
        # Tamper token signature
        parts = token.split(".")
        tampered_token = f"{parts[0]}.{parts[1]}.tampered_signature_bytes"

        self.assertIsNone(decode_access_token(tampered_token))

    def test_session_registration_and_revocation(self):
        token = create_access_token({"sub": "usr-1", "email": "test@sentinelai.internal"})
        session_id = register_session("usr-1", token)
        self.assertTrue(session_id.startswith("sess_usr-1"))

        self.assertFalse(is_token_revoked(token))
        revoke_token(token)
        self.assertTrue(is_token_revoked(token))

if __name__ == "__main__":
    unittest.main()
