"""
SentinelAI - Enterprise SOC FastAPI Backend Service
Provides high-throughput event ingestion, ML anomaly detection, SOAR automation, and Argon2/JWT authentication.
"""

import os
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional
from fastapi import FastAPI, Depends, HTTPException, Header, status
from fastapi.middleware.cors import CORSMiddleware

from .schemas import (
    UserRegisterRequest,
    UserLoginRequest,
    UserResponse,
    AuthResponse,
    UserRole,
    PasswordResetRequest,
    RoleSwitchRequest,
)
from .auth import (
    get_password_hash,
    verify_password,
    create_access_token,
    decode_access_token,
    register_session,
    revoke_token,
    is_token_revoked,
)

app = FastAPI(
    title="SentinelAI Security Operations Platform API",
    description="Intelligent SOC platform for event monitoring, threat detection, phishing analysis, and SOAR automation.",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# In-Memory Persistence & Seed Data
# ---------------------------------------------------------------------------
db_users: Dict[str, Dict[str, Any]] = {
    "alex.vance@sentinelai.internal": {
        "id": "usr-admin-01",
        "name": "Alex Vance, CISSP",
        "email": "alex.vance@sentinelai.internal",
        "role": UserRole.ADMIN,
        "status": "ACTIVE",
        "mfaEnabled": True,
        "lastLogin": datetime.now(timezone.utc).isoformat(),
        "organizationId": "org-enterprise-global",
        "password_hash": get_password_hash("SentinelAdmin2026!"),
    },
    "sarah.chen@sentinelai.internal": {
        "id": "usr-sec-02",
        "name": "Sarah Chen",
        "email": "sarah.chen@sentinelai.internal",
        "role": UserRole.SECURITY_ANALYST,
        "status": "ACTIVE",
        "mfaEnabled": True,
        "lastLogin": datetime.now(timezone.utc).isoformat(),
        "organizationId": "org-enterprise-global",
        "password_hash": get_password_hash("AnalystSecure#1"),
    },
    "marcus.brody@sentinelai.internal": {
        "id": "usr-mgr-03",
        "name": "Marcus Brody",
        "email": "marcus.brody@sentinelai.internal",
        "role": UserRole.SOC_MANAGER,
        "status": "ACTIVE",
        "mfaEnabled": True,
        "lastLogin": datetime.now(timezone.utc).isoformat(),
        "organizationId": "org-enterprise-global",
        "password_hash": get_password_hash("ManagerSOC$88"),
    },
    "elena.rostova@sentinelai.internal": {
        "id": "usr-view-04",
        "name": "Elena Rostova",
        "email": "elena.rostova@sentinelai.internal",
        "role": UserRole.VIEWER,
        "status": "ACTIVE",
        "mfaEnabled": False,
        "lastLogin": datetime.now(timezone.utc).isoformat(),
        "organizationId": "org-enterprise-global",
        "password_hash": get_password_hash("ViewerAudit!09"),
    },
}

current_active_user_email: str = "alex.vance@sentinelai.internal"

# ---------------------------------------------------------------------------
# Auth Dependencies
# ---------------------------------------------------------------------------
def get_current_user(authorization: Optional[str] = Header(None)) -> Dict[str, Any]:
    """Extract and validate Bearer JWT token from Authorization header."""
    if not authorization:
        # Fallback to current session user for development convenience if no token header provided
        return db_users.get(current_active_user_email, list(db_users.values())[0])

    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authorization scheme. Bearer token required.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if is_token_revoked(token):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Session has been revoked. Please sign in again.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    payload = decode_access_token(token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired access token.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    user_email = payload.get("email")
    user = db_users.get(user_email)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authenticated user no longer exists in SOC directory.",
        )

    if user["status"] == "SUSPENDED":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account has been suspended by SOC Administrator.",
        )

    return user

# ---------------------------------------------------------------------------
# Authentication Routes (/api/v1/auth/...)
# ---------------------------------------------------------------------------
@app.post("/api/v1/auth/register", response_model=AuthResponse, status_code=status.HTTP_201_CREATED, tags=["Auth"])
@app.post("/api/v1/auth/signup", response_model=AuthResponse, status_code=status.HTTP_201_CREATED, tags=["Auth"])
def register_user(payload: UserRegisterRequest):
    """Register a new SOC analyst or administrator with Argon2 password hashing and JWT issuance."""
    email_clean = payload.email.strip().lower()

    if email_clean in db_users:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="An account with this email address already exists in the SOC directory.",
        )

    new_id = f"usr-reg-{int(datetime.now(timezone.utc).timestamp())}"
    hashed_pwd = get_password_hash(payload.password)

    user_record = {
        "id": new_id,
        "name": payload.name.strip(),
        "email": email_clean,
        "role": payload.role,
        "status": "ACTIVE",
        "mfaEnabled": payload.mfaEnabled,
        "lastLogin": datetime.now(timezone.utc).isoformat(),
        "organizationId": "org-enterprise-global",
        "password_hash": hashed_pwd,
    }

    db_users[email_clean] = user_record
    global current_active_user_email
    current_active_user_email = email_clean

    token = create_access_token({
        "sub": new_id,
        "email": email_clean,
        "role": payload.role.value,
        "name": payload.name.strip(),
    })
    register_session(new_id, token)

    user_resp = UserResponse(
        id=user_record["id"],
        name=user_record["name"],
        email=user_record["email"],
        role=user_record["role"],
        status=user_record["status"],
        mfaEnabled=user_record["mfaEnabled"],
        lastLogin=user_record["lastLogin"],
        organizationId=user_record["organizationId"],
    )

    return AuthResponse(
        user=user_resp,
        token=token,
        token_type="bearer",
        message="Account created and authenticated successfully",
    )

@app.post("/api/v1/auth/login", response_model=AuthResponse, tags=["Auth"])
def login_user(payload: UserLoginRequest):
    """Authenticate SOC credentials, verify Argon2 password hash, and issue JWT session token."""
    email_clean = payload.email.strip().lower()
    user = db_users.get(email_clean)

    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email credentials or unauthorized account.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if user["status"] == "SUSPENDED":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account has been suspended by SOC Administrator.",
        )

    # Verify password against Argon2 hash
    if not verify_password(payload.password, user["password_hash"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect password credentials.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # Update last login
    user["lastLogin"] = datetime.now(timezone.utc).isoformat()
    global current_active_user_email
    current_active_user_email = email_clean

    token = create_access_token({
        "sub": user["id"],
        "email": email_clean,
        "role": user["role"].value if hasattr(user["role"], "value") else str(user["role"]),
        "name": user["name"],
    })
    register_session(user["id"], token)

    user_resp = UserResponse(
        id=user["id"],
        name=user["name"],
        email=user["email"],
        role=user["role"],
        status=user["status"],
        mfaEnabled=user["mfaEnabled"],
        lastLogin=user["lastLogin"],
        organizationId=user["organizationId"],
    )

    return AuthResponse(
        user=user_resp,
        token=token,
        token_type="bearer",
        message="Authentication successful",
    )

@app.get("/api/v1/auth/me", tags=["Auth"])
def get_me(user: Dict[str, Any] = Depends(get_current_user)):
    """Retrieve details of the currently authenticated SOC user."""
    return {
        "user": {
            "id": user["id"],
            "name": user["name"],
            "email": user["email"],
            "role": user["role"],
            "status": user["status"],
            "mfaEnabled": user["mfaEnabled"],
            "lastLogin": user["lastLogin"],
            "organizationId": user["organizationId"],
        }
    }

@app.post("/api/v1/auth/logout", tags=["Auth"])
def logout_user(authorization: Optional[str] = Header(None)):
    """Revoke active JWT session and perform logout."""
    if authorization:
        _, _, token = authorization.partition(" ")
        if token:
            revoke_token(token)
    return {"success": True, "message": "Logged out successfully"}

@app.post("/api/v1/auth/switch-role", tags=["Auth"])
def switch_role(payload: RoleSwitchRequest, user: Dict[str, Any] = Depends(get_current_user)):
    """Switch active user's role persona for evaluation testing."""
    user["role"] = payload.role
    return {
        "success": True,
        "user": {
            "id": user["id"],
            "name": user["name"],
            "email": user["email"],
            "role": user["role"],
            "status": user["status"],
            "mfaEnabled": user["mfaEnabled"],
            "lastLogin": user["lastLogin"],
            "organizationId": user["organizationId"],
        },
    }

@app.post("/api/v1/auth/forgot-password", tags=["Auth"])
def forgot_password(payload: PasswordResetRequest):
    """Simulate self-service password reset token dispatch."""
    return {
        "success": True,
        "message": f"Password reset instructions dispatched to verified address: {payload.email}",
    }

# ---------------------------------------------------------------------------
# General SOC API Endpoints
# ---------------------------------------------------------------------------
@app.get("/health", tags=["System"])
def health_check():
    return {
        "status": "healthy",
        "service": "sentinelai-backend",
        "version": "1.0.0",
        "database": "connected",
        "redis_worker": "active",
        "active_users": len(db_users),
    }

@app.get("/api/v1/dashboard/summary", tags=["Dashboard"])
def get_dashboard_summary():
    return {
        "metrics": {
            "totalEvents": 148920,
            "totalAlerts": 4,
            "criticalAlerts": 2,
            "highRiskAlerts": 1,
            "openIncidents": 2,
            "resolvedIncidents": 1,
            "threatIndicatorsCount": 4,
            "monitoredAssetsCount": 5,
            "vulnerabilitiesDetected": 3,
            "automationExecutions": 42,
        },
        "topSuspiciousIps": [
            {"ip": "185.220.101.5", "attempts": 142, "threatLevel": "CRITICAL", "geo": "Netherlands"},
            {"ip": "194.26.29.112", "attempts": 89, "threatLevel": "HIGH", "geo": "Russia"},
            {"ip": "45.154.255.89", "attempts": 64, "threatLevel": "MEDIUM", "geo": "Russia"},
            {"ip": "103.145.13.2", "attempts": 37, "threatLevel": "MEDIUM", "geo": "Singapore"},
        ],
    }

@app.get("/api/v1/dashboard/trends", tags=["Dashboard"])
def get_dashboard_trends():
    return {
        "eventsOverTime": [
            {"time": "00:00", "events": 12400, "anomalies": 12},
            {"time": "04:00", "events": 8900, "anomalies": 8},
            {"time": "08:00", "events": 24500, "anomalies": 34},
            {"time": "12:00", "events": 38200, "anomalies": 52},
            {"time": "16:00", "events": 41900, "anomalies": 68},
            {"time": "20:00", "events": 23000, "anomalies": 28},
        ],
        "severityDistribution": [
            {"name": "Critical", "value": 2, "color": "#F05268"},
            {"name": "High", "value": 1, "color": "#FF754C"},
            {"name": "Medium", "value": 1, "color": "#E8AD4B"},
            {"name": "Low", "value": 0, "color": "#438CFF"},
        ],
        "threatClassification": [
            {"category": "AUTH_ANOMALY", "count": 28},
            {"category": "NETWORK_INTRUSION", "count": 64},
            {"category": "MALWARE_BEHAVIOR", "count": 3},
            {"category": "DATA_EXFILTRATION", "count": 14},
        ],
    }

@app.post("/api/v1/logs/ingest", tags=["Logs"])
def ingest_log_event(event: dict):
    return {
        "status": "INGESTED",
        "event_id": f"log-evt-{int(datetime.now(timezone.utc).timestamp())}",
        "risk_tier": "HIGH" if event.get("severity") == "CRITICAL" else "MEDIUM",
        "mitre_technique": "T1110",
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
