"""
SentinelAI - Pydantic Request & Response Models for Authentication & User Entities
"""

from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field

class UserRole(str, Enum):
    ADMIN = "ADMIN"
    SECURITY_ANALYST = "SECURITY_ANALYST"
    SOC_MANAGER = "SOC_MANAGER"
    VIEWER = "VIEWER"

class UserRegisterRequest(BaseModel):
    name: str = Field(..., min_length=2, max_length=100, description="Full name of security engineer")
    email: str = Field(..., description="Corporate SOC email address")
    password: str = Field(..., min_length=8, description="Secure password")
    role: UserRole = Field(default=UserRole.SECURITY_ANALYST, description="Assigned role")
    mfaEnabled: bool = Field(default=True, description="Enable hardware or TOTP MFA")

class UserLoginRequest(BaseModel):
    email: str = Field(..., description="Corporate SOC email address")
    password: str = Field(..., description="Account password")

class UserResponse(BaseModel):
    id: str
    name: str
    email: str
    role: UserRole
    status: str = "ACTIVE"
    mfaEnabled: bool = True
    lastLogin: str
    avatarUrl: Optional[str] = None
    organizationId: str = "org-enterprise-global"

class AuthResponse(BaseModel):
    user: UserResponse
    token: str
    token_type: str = "bearer"
    message: str = "Authentication successful"

class PasswordResetRequest(BaseModel):
    email: str

class RoleSwitchRequest(BaseModel):
    role: UserRole
