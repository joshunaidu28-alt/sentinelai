# SentinelAI Database Architecture & Schema Specification

The persistence tier is designed for PostgreSQL with UUID primary keys, JSONB for unstructured evidence payloads, foreign key constraints, and indexing on temporal and search fields.

---

## Normalized Entity Relations

### 1. `users`
- `id`: UUID (Primary Key)
- `name`: VARCHAR(255)
- `email`: VARCHAR(255) UNIQUE NOT NULL
- `password_hash`: VARCHAR(255) NOT NULL (Argon2id)
- `role`: VARCHAR(50) (ADMIN, SECURITY_ANALYST, SOC_MANAGER, VIEWER)
- `status`: VARCHAR(50) DEFAULT 'ACTIVE'
- `mfa_enabled`: BOOLEAN DEFAULT TRUE
- `last_login`: TIMESTAMP WITH TIME ZONE
- `created_at`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP

### 2. `monitored_assets`
- `id`: UUID (Primary Key)
- `name`: VARCHAR(255) NOT NULL
- `type`: VARCHAR(50) NOT NULL (SERVER, WORKSTATION, DATABASE, FIREWALL, API_GATEWAY, CLOUD_VM)
- `ip_address`: INET NOT NULL
- `hostname`: VARCHAR(255)
- `owner`: VARCHAR(255)
- `environment`: VARCHAR(50) (PRODUCTION, STAGING, CORPORATE)
- `criticality`: VARCHAR(50) (TIER_1_CRITICAL, TIER_2_HIGH, TIER_3_MEDIUM, TIER_4_LOW)
- `authorized`: BOOLEAN DEFAULT TRUE
- `last_monitored`: TIMESTAMP WITH TIME ZONE

### 3. `security_logs`
- `id`: UUID (Primary Key)
- `timestamp`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP (Indexed)
- `source`: VARCHAR(50) NOT NULL (FIREWALL, AUTH_SERVER, EDR_AGENT, WAF, DNS_PROXY, CLOUD_TRAIL)
- `event_type`: VARCHAR(100) NOT NULL (Indexed)
- `severity`: VARCHAR(20) NOT NULL (CRITICAL, HIGH, MEDIUM, LOW, INFO)
- `source_ip`: INET (Indexed)
- `destination_ip`: INET (Indexed)
- `message`: TEXT NOT NULL
- `payload`: JSONB NOT NULL DEFAULT '{}'::jsonb
- `associated_alert_id`: UUID REFERENCES alerts(id) ON DELETE SET NULL

### 4. `alerts`
- `id`: UUID (Primary Key)
- `title`: VARCHAR(255) NOT NULL
- `timestamp`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
- `severity`: VARCHAR(20) NOT NULL
- `status`: VARCHAR(50) NOT NULL (NEW, OPEN, INVESTIGATING, ESCALATED, RESOLVED, FALSE_POSITIVE)
- `risk_score`: INTEGER NOT NULL CHECK (risk_score >= 0 AND risk_score <= 100)
- `source`: VARCHAR(50) NOT NULL
- `source_ip`: INET
- `destination_ip`: INET
- `detection_rule_id`: VARCHAR(100)
- `mitre_technique`: VARCHAR(50)
- `confidence`: INTEGER NOT NULL CHECK (confidence >= 0 AND confidence <= 100)
- `detection_reason`: TEXT NOT NULL
- `assigned_to`: UUID REFERENCES users(id) ON DELETE SET NULL
- `incident_id`: UUID REFERENCES incidents(id) ON DELETE SET NULL

### 5. `incidents`
- `id`: UUID (Primary Key)
- `incident_number`: VARCHAR(50) UNIQUE NOT NULL
- `title`: VARCHAR(255) NOT NULL
- `status`: VARCHAR(50) NOT NULL (DETECTED, TRIAGED, INVESTIGATING, CONTAINMENT_REVIEW, RECOVERY, RESOLVED)
- `priority`: VARCHAR(20) NOT NULL (P1_CRITICAL, P2_HIGH, P3_MEDIUM, P4_LOW)
- `lead_investigator_id`: UUID REFERENCES users(id)
- `summary`: TEXT NOT NULL
- `mitre_techniques`: TEXT[] DEFAULT '{}'
- `created_at`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
- `updated_at`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP

### 6. `threat_indicators`
- `id`: UUID (Primary Key)
- `type`: VARCHAR(30) NOT NULL (IPV4, DOMAIN, URL, FILE_HASH_SHA256, EMAIL)
- `value`: VARCHAR(512) UNIQUE NOT NULL (Indexed)
- `threat_type`: VARCHAR(50) NOT NULL
- `confidence`: INTEGER CHECK (confidence >= 0 AND confidence <= 100)
- `first_seen`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
- `last_seen`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
- `source`: VARCHAR(255)
- `enrichment_payload`: JSONB DEFAULT '{}'::jsonb

### 7. `playbooks` & `automation_runs`
- `playbooks`: id, name, description, category, requires_approval, enabled, steps (JSONB)
- `automation_runs`: id, playbook_id REFERENCES playbooks(id), status, started_at, completed_at, executed_by, approval_details (JSONB), output_logs (TEXT[])

### 8. `audit_logs` (Immutable Append-Only)
- `id`: UUID (Primary Key)
- `timestamp`: TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
- `user_id`: UUID REFERENCES users(id)
- `action`: VARCHAR(100) NOT NULL
- `category`: VARCHAR(50) NOT NULL
- `details`: TEXT NOT NULL
- `ip_address`: INET NOT NULL
- `status`: VARCHAR(20) NOT NULL (SUCCESS, FAILED, BLOCKED)
