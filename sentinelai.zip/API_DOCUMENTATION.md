# SentinelAI REST API Documentation

Base URI: `/api/v1`

---

## Authentication & User Session
- `GET /api/v1/auth/me` -> Retrieves the current authenticated SOC operator.
- `POST /api/v1/auth/switch-role` -> Switches active role between `ADMIN`, `SECURITY_ANALYST`, `SOC_MANAGER`, `VIEWER`.
- `GET /api/v1/users` -> Lists all registered operators and their RBAC status.
- `POST /api/v1/users` -> Creates a new operator with assigned role.
- `PATCH /api/v1/users/:id` -> Updates operator status or permissions.

## Dashboard & Metrics
- `GET /api/v1/dashboard/summary` -> Returns aggregate counters: total events, critical alerts, open incidents, active IOCs, monitored assets.
- `GET /api/v1/dashboard/trends` -> Returns time-series telemetry (event velocity, severity breakdowns, MITRE category distribution).

## Security Logs & Ingestion
- `GET /api/v1/logs?severity=&source=&search=` -> Paginated, searchable security event logs.
- `POST /api/v1/logs/ingest` -> Ingests structured JSON log event, executes risk scoring, and auto-generates alerts if risk >= 50.

## Alert Management
- `GET /api/v1/alerts?severity=&status=&search=` -> Returns list of alerts.
- `GET /api/v1/alerts/:id` -> Returns full alert details including forensic evidence and notes.
- `PATCH /api/v1/alerts/:id` -> Updates alert status or assignment.
- `POST /api/v1/alerts/:id/notes` -> Adds an analyst investigation note.
- `POST /api/v1/alerts/:id/escalate-to-incident` -> Promotes alert into a formal incident.

## Incident Response
- `GET /api/v1/incidents` -> Returns all declared security incidents.
- `POST /api/v1/incidents` -> Declares a new security incident.
- `GET /api/v1/incidents/:id` -> Retrieves incident timeline, notes, and affected assets.
- `PATCH /api/v1/incidents/:id` -> Updates status through the 6 lifecycle stages.
- `POST /api/v1/incidents/:id/notes` -> Appends forensic response note.

## Phishing & URL Analysis
- `POST /api/v1/phishing/analyze` -> Analyzes URL/email for typosquatting, SPF/DKIM flags, and reputation.
- `GET /api/v1/phishing/history` -> Historical phishing triage reports.

## Network Security & Vulnerabilities
- `GET /api/v1/network/events` -> Active connection flows and anomaly flags.
- `GET /api/v1/network/stats` -> Protocol bandwidth metrics and active sensor count.
- `GET /api/v1/vulnerabilities` -> CVE catalog with CVSS scores.
- `POST /api/v1/vulnerabilities/scans` -> Launches authorized Nmap or OWASP ZAP scan on scoped asset.

## Threat Intelligence (IOCs)
- `GET /api/v1/threats` -> Lists IOC repository.
- `POST /api/v1/threats` -> Adds new IP, domain, URL, or hash indicator.
- `POST /api/v1/threats/enrich` -> Queries VirusTotal API for reputation score and Autonomous System info.

## AI Investigation Assistant (Copilot)
- `POST /api/v1/ai/investigate` -> Structured forensic investigation using Gemini (`gemini-3.8-flash`).
- `POST /api/v1/ai/chat` -> Conversational Copilot Q&A with prompt injection defense.

## SOAR Automation & Playbooks
- `GET /api/v1/automation/playbooks` -> Catalogs configured SOAR playbooks.
- `POST /api/v1/automation/playbooks/:id/execute` -> Spawns an automation run.
- `GET /api/v1/automation/runs` -> Retrieves automation runs.
- `POST /api/v1/automation/runs/:id/approve` -> Authorizes or denies pending approval run.

## Reports & Audit
- `GET /api/v1/reports` -> Lists generated security briefs.
- `POST /api/v1/reports/generate` -> Compiles PDF/CSV/JSON security report.
- `GET /api/v1/audit-logs` -> Immutable audit trail of all platform activities.
- `GET /api/v1/integrations` -> Integration configs.
- `POST /api/v1/integrations/:id/test` -> Validates connection latency to external tool.
