# SentinelAI Testing & Quality Assurance Suite

SentinelAI enforces multi-layer verification spanning pure logic unit testing, API integration testing, and headless browser end-to-end journeys.

---

## 1. Running Unit Tests

Pure calculations, heuristic classification, and MITRE correlation are verified using Node's native test runner (`node:test` and `node:assert/strict`):

```bash
npx --yes tsx --test src/utils/detection.test.ts
```

### Verified Scenarios:
1. `calculateRiskScore`: Multi-factor composite risk evaluation against critical Tier-1 assets with known threat intelligence correlations.
2. `calculateRiskScore`: Low risk baseline verification for informational routine traffic.
3. `analyzePhishing`: Brand typosquatting and urgency keyword detection.
4. `analyzePhishing`: False-positive avoidance on clean corporate emails.
5. `correlateMitre`: T1110 (Brute Force), T1046 (Port Sweep), and T1078 (Privilege Escalation) mapping.

---

## 2. Browser Verification (Playwright CLI)

Automated end-to-end verification runs headlessly inside the container:

```bash
# Capture full desktop layout
playwright-cli open --browser=chromium http://localhost:3000
playwright-cli resize 1440 900
playwright-cli screenshot --filename=.playwright-cli/verification.png
playwright-cli close
```
