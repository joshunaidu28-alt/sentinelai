import React, { useState } from 'react';
import {
  X,
  Copy,
  Check,
  ShieldAlert,
  LifeBuoy,
  UserCheck,
  Clock,
  Send,
  ArrowRight,
  AlertTriangle,
  FileCode,
} from 'lucide-react';
import { SecurityLog, SecurityAlert, SecurityIncident, AlertStatus, IncidentStatus } from '../../types/index.ts';
import { SeverityBadge, StatusBadge } from '../common/StatCard.tsx';

export const LogDetailDrawer: React.FC<{
  log: SecurityLog | null;
  onClose: () => void;
}> = ({ log, onClose }) => {
  const [copied, setCopied] = useState(false);
  if (!log) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(JSON.stringify(log, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs">
      <div className="w-full max-w-lg bg-[#101B2D] border-l border-[#1A273D] h-full flex flex-col shadow-2xl p-6 overflow-y-auto space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#1A273D]">
          <div>
            <div className="text-[10px] font-mono text-[#45D6C5] font-semibold">{log.id}</div>
            <h3 className="text-sm font-semibold text-[#E8EEF9] mt-0.5">{log.eventType}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#8C9CB5] hover:text-[#E8EEF9] hover:bg-[#15233B]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-3 text-xs">
          <div className="grid grid-cols-2 gap-2 p-3 rounded-lg bg-[#15233B]">
            <div>
              <span className="text-[10px] text-[#8C9CB5] uppercase">Severity</span>
              <div><SeverityBadge severity={log.severity} /></div>
            </div>
            <div>
              <span className="text-[10px] text-[#8C9CB5] uppercase">Sensor Source</span>
              <div className="font-mono font-semibold text-[#45D6C5]">{log.source}</div>
            </div>
            <div>
              <span className="text-[10px] text-[#8C9CB5] uppercase">Source IP</span>
              <div className="font-mono text-[#438CFF]">{log.sourceIp || 'Internal'}</div>
            </div>
            <div>
              <span className="text-[10px] text-[#8C9CB5] uppercase">Destination IP</span>
              <div className="font-mono text-[#8C9CB5]">{log.destinationIp || 'Perimeter Gateway'}</div>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Normalized Message</label>
            <div className="p-3 rounded-lg bg-[#0C1424] text-[#E8EEF9]">{log.message}</div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-[11px] font-semibold text-[#8C9CB5]">Structured Payload (JSON)</label>
              <button onClick={handleCopy} className="text-[11px] text-[#45D6C5] hover:underline flex items-center gap-1">
                {copied ? <Check className="w-3 h-3 text-[#42C99A]" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Copied' : 'Copy JSON'}</span>
              </button>
            </div>
            <pre className="p-3 rounded-lg bg-[#0A101C] border border-[#1A273D] text-[11px] font-mono text-[#45D6C5] overflow-x-auto max-h-56">
              {JSON.stringify(log.payload, null, 2)}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};

export const AlertDetailDrawer: React.FC<{
  alert: SecurityAlert | null;
  onClose: () => void;
  onUpdateStatus: (alertId: string, status: AlertStatus) => Promise<any>;
  onAddNote: (alertId: string, text: string) => Promise<any>;
  onEscalate: (alertId: string) => Promise<any>;
}> = ({ alert, onClose, onUpdateStatus, onAddNote, onEscalate }) => {
  const [newNote, setNewNote] = useState('');
  const [isSubmittingNote, setIsSubmittingNote] = useState(false);

  if (!alert) return null;

  const handleNoteSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNote.trim()) return;
    setIsSubmittingNote(true);
    try {
      await onAddNote(alert.id, newNote);
      setNewNote('');
    } finally {
      setIsSubmittingNote(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs">
      <div className="w-full max-w-xl bg-[#101B2D] border-l border-[#1A273D] h-full flex flex-col shadow-2xl p-6 overflow-y-auto space-y-4">
        {/* Drawer Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#1A273D]">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono text-[#45D6C5] font-semibold">{alert.id}</span>
              <SeverityBadge severity={alert.severity} />
            </div>
            <h3 className="text-sm font-semibold text-[#E8EEF9] mt-0.5">{alert.title}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#8C9CB5] hover:text-[#E8EEF9] hover:bg-[#15233B]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Status & Risk Bar */}
        <div className="p-3 rounded-lg bg-[#15233B] flex items-center justify-between text-xs">
          <div>
            <span className="text-[10px] text-[#8C9CB5] block uppercase">Current Status</span>
            <select
              value={alert.status}
              onChange={(e) => onUpdateStatus(alert.id, e.target.value as AlertStatus)}
              className="bg-[#101B2D] border border-[#1A273D] rounded px-2 py-1 text-xs text-[#E8EEF9] font-mono outline-none mt-0.5"
            >
              <option value="NEW">NEW</option>
              <option value="OPEN">OPEN</option>
              <option value="INVESTIGATING">INVESTIGATING</option>
              <option value="ESCALATED">ESCALATED</option>
              <option value="RESOLVED">RESOLVED</option>
              <option value="FALSE_POSITIVE">FALSE_POSITIVE</option>
            </select>
          </div>

          <div className="text-right">
            <span className="text-[10px] text-[#8C9CB5] block uppercase">Risk Score / Confidence</span>
            <span className="text-lg font-mono font-bold text-[#F05268]">
              {alert.riskScore}/100 <span className="text-xs font-normal text-[#8C9CB5]">({alert.confidence}%)</span>
            </span>
          </div>
        </div>

        {/* Detection Details */}
        <div className="space-y-3 text-xs">
          <div>
            <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Detection Logic & Context</label>
            <div className="p-3 rounded-lg bg-[#0C1424] text-[#E8EEF9] leading-relaxed">
              {alert.detectionReason}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px] text-[#8C9CB5]">
            <div className="p-2.5 rounded bg-[#15233B]">
              <span className="block text-[10px] uppercase">Rule Trigger</span>
              <span className="text-[#E8EEF9] font-semibold">{alert.ruleName}</span>
            </div>
            <div className="p-2.5 rounded bg-[#15233B]">
              <span className="block text-[10px] uppercase">MITRE Technique</span>
              <span className="text-[#45D6C5] font-mono font-semibold">
                {alert.mitreTechnique || 'T1110'} ({alert.mitreTactic || 'Credential Access'})
              </span>
            </div>
          </div>

          {/* Evidence List */}
          <div>
            <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Supporting Forensic Evidence</label>
            <div className="space-y-1.5">
              {alert.evidence.map((ev, i) => (
                <div key={i} className="p-2 rounded bg-[#0C1424] font-mono text-[11px] flex justify-between">
                  <span className="text-[#8C9CB5]">{ev.description}:</span>
                  <span className="text-[#E8EEF9] font-semibold">{ev.value}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Analyst Notes Thread */}
          <div className="pt-2 border-t border-[#1A273D] space-y-2">
            <label className="block text-[11px] font-semibold text-[#8C9CB5]">Analyst Investigation Notes</label>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {alert.notes.map((note) => (
                <div key={note.id} className="p-2.5 rounded-lg bg-[#15233B] text-[11px]">
                  <div className="flex items-center justify-between text-[#8C9CB5] mb-1">
                    <span className="font-semibold text-[#E8EEF9]">{note.author}</span>
                    <span>{new Date(note.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <p className="text-[#8C9CB5]">{note.text}</p>
                </div>
              ))}
              {alert.notes.length === 0 && (
                <div className="text-[11px] text-[#8C9CB5] italic">No analyst notes recorded yet.</div>
              )}
            </div>

            <form onSubmit={handleNoteSubmit} className="flex gap-2">
              <input
                type="text"
                value={newNote}
                onChange={(e) => setNewNote(e.target.value)}
                placeholder="Add investigation finding or triage observation..."
                className="flex-1 bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs text-[#E8EEF9] outline-none"
              />
              <button
                type="submit"
                disabled={isSubmittingNote}
                className="px-3 py-1.5 rounded-lg bg-[#45D6C5] text-[#080D18] text-xs font-semibold"
              >
                Post
              </button>
            </form>
          </div>

          {/* Escalate CTA */}
          <div className="pt-3 border-t border-[#1A273D] flex items-center justify-between">
            <button
              onClick={() => onEscalate(alert.id)}
              className="w-full py-2 rounded-lg text-xs font-semibold bg-[#F05268]/20 hover:bg-[#F05268]/30 text-[#F05268] border border-[#F05268]/30 transition-colors flex items-center justify-center gap-1.5"
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Escalate Alert to Formal Incident</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export const IncidentDetailDrawer: React.FC<{
  incident: SecurityIncident | null;
  onClose: () => void;
  onUpdateStatus: (incidentId: string, status: IncidentStatus) => Promise<any>;
  onAddNote: (incidentId: string, content: string) => Promise<any>;
}> = ({ incident, onClose, onUpdateStatus, onAddNote }) => {
  const [newNote, setNewNote] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!incident) return null;

  const handleNoteSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNote.trim()) return;
    setIsSubmitting(true);
    try {
      await onAddNote(incident.id, newNote);
      setNewNote('');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs">
      <div className="w-full max-w-xl bg-[#101B2D] border-l border-[#1A273D] h-full flex flex-col shadow-2xl p-6 overflow-y-auto space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#1A273D]">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-bold text-[#45D6C5]">{incident.incidentNumber}</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#F05268]/20 text-[#F05268] font-bold">
                {incident.priority.replace(/_/g, ' ')}
              </span>
            </div>
            <h3 className="text-sm font-semibold text-[#E8EEF9] mt-0.5">{incident.title}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#8C9CB5] hover:text-[#E8EEF9] hover:bg-[#15233B]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Stage Status */}
        <div className="p-3 rounded-lg bg-[#15233B] flex items-center justify-between text-xs">
          <div>
            <span className="text-[10px] text-[#8C9CB5] block uppercase">Lifecycle Stage</span>
            <select
              value={incident.status}
              onChange={(e) => onUpdateStatus(incident.id, e.target.value as IncidentStatus)}
              className="bg-[#101B2D] border border-[#1A273D] rounded px-2 py-1 text-xs text-[#E8EEF9] font-mono outline-none mt-0.5"
            >
              <option value="DETECTED">DETECTED</option>
              <option value="TRIAGED">TRIAGED</option>
              <option value="INVESTIGATING">INVESTIGATING</option>
              <option value="CONTAINMENT_REVIEW">CONTAINMENT_REVIEW</option>
              <option value="RECOVERY">RECOVERY</option>
              <option value="RESOLVED">RESOLVED</option>
            </select>
          </div>

          <div className="text-right">
            <span className="text-[10px] text-[#8C9CB5] block uppercase">Lead Responder</span>
            <span className="text-xs font-semibold text-[#E8EEF9]">{incident.leadInvestigatorName}</span>
          </div>
        </div>

        {/* Summary */}
        <div className="space-y-3 text-xs">
          <div>
            <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Executive Summary</label>
            <div className="p-3 rounded-lg bg-[#0C1424] text-[#E8EEF9] leading-relaxed">
              {incident.summary}
            </div>
          </div>

          {/* Timeline Audit Trail */}
          <div>
            <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-2">Response Timeline</label>
            <div className="space-y-2 border-l-2 border-[#1A273D] ml-2 pl-3">
              {incident.timeline.map((step) => (
                <div key={step.id} className="relative text-[11px]">
                  <span className="absolute -left-[19px] top-1.5 w-2.5 h-2.5 rounded-full bg-[#45D6C5]" />
                  <div className="flex items-center justify-between text-[#8C9CB5]">
                    <span className="font-semibold text-[#E8EEF9]">{step.stage}</span>
                    <span className="font-mono text-[10px]">{new Date(step.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <p className="text-[#8C9CB5] mt-0.5">{step.description}</p>
                  <div className="text-[10px] text-[#45D6C5] font-mono mt-0.5">By {step.author}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Response Notes */}
          <div className="pt-2 border-t border-[#1A273D] space-y-2">
            <label className="block text-[11px] font-semibold text-[#8C9CB5]">Forensic Response Notes</label>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {incident.notes.map((n) => (
                <div key={n.id} className="p-2.5 rounded bg-[#15233B] text-[11px]">
                  <div className="flex items-center justify-between text-[#8C9CB5] mb-1">
                    <span className="font-semibold text-[#E8EEF9]">{n.author}</span>
                    <span>{new Date(n.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <p className="text-[#8C9CB5]">{n.content}</p>
                </div>
              ))}
            </div>

            <form onSubmit={handleNoteSubmit} className="flex gap-2">
              <input
                type="text"
                value={newNote}
                onChange={(e) => setNewNote(e.target.value)}
                placeholder="Log containment action or forensic update..."
                className="flex-1 bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs text-[#E8EEF9] outline-none"
              />
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-3 py-1.5 rounded-lg bg-[#45D6C5] text-[#080D18] text-xs font-semibold"
              >
                Log
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
