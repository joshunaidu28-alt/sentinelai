import React, { useState } from 'react';
import {
  Shield,
  Lock,
  Mail,
  User,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  X,
  UserCheck,
} from 'lucide-react';
import { User as UserType, UserRole } from '../../types/index.ts';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess: (user: UserType, token?: string) => void;
  currentUser?: UserType | null;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onAuthSuccess,
  currentUser,
}) => {
  const [tab, setTab] = useState<'LOGIN' | 'REGISTER' | 'FORGOT'>('LOGIN');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<UserRole>('SECURITY_ANALYST');
  const [mfaEnabled, setMfaEnabled] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  // Preset demo personas for instant 1-click evaluation
  const demoPersonas = [
    {
      name: 'Alex Vance (Admin)',
      email: 'alex.vance@sentinelai.internal',
      role: 'ADMIN',
      desc: 'Full administrative & incident authority',
    },
    {
      name: 'Sarah Chen (Analyst)',
      email: 'sarah.chen@sentinelai.internal',
      role: 'SECURITY_ANALYST',
      desc: 'Triage alerts & forensic workflows',
    },
    {
      name: 'Marcus Brody (Manager)',
      email: 'marcus.brody@sentinelai.internal',
      role: 'SOC_MANAGER',
      desc: 'Authorize SOAR containment playbooks',
    },
    {
      name: 'Elena Rostova (Viewer)',
      email: 'elena.rostova@sentinelai.internal',
      role: 'VIEWER',
      desc: 'Read-only telemetry & executive reports',
    },
  ];

  const handleQuickFill = (personaEmail: string) => {
    setEmail(personaEmail);
    setPassword('Sentinel2026!');
    setError(null);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please provide both work email and password.');
      return;
    }
    setLoading(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const res = await fetch('/api/v1/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Login failed');
      }

      onAuthSuccess(data.user, data.token);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Authentication error. Please check credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !password) {
      setError('Full name, email, and password are required.');
      return;
    }
    setLoading(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const res = await fetch('/api/v1/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, role, mfaEnabled }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Registration failed');
      }

      onAuthSuccess(data.user, data.token);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Registration failed. Email might already exist.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setError('Enter your registered work email.');
      return;
    }
    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/v1/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      setSuccessMessage(data.message || 'Reset instructions dispatched.');
    } catch (err: any) {
      setError('Unable to dispatch reset token.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
    >
      <div className="w-full max-w-md bg-[#101B2D] border border-[#1A273D] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-[#0C1424] border-b border-[#1A273D] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#45D6C5]/20 to-[#438CFF]/20 border border-[#45D6C5]/40 flex items-center justify-center">
              <Shield className="w-4 h-4 text-[#45D6C5]" />
            </div>
            <div>
              <h2 id="auth-modal-title" className="text-sm font-bold text-[#E8EEF9]">
                SentinelAI Security Operations
              </h2>
              <p className="text-[11px] text-[#8C9CB5]">Enterprise SOC Access & Verification</p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close authentication modal"
            className="p-1.5 rounded-lg text-[#8C9CB5] hover:text-[#E8EEF9] hover:bg-[#1A273D] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="grid grid-cols-3 border-b border-[#1A273D] bg-[#0C1424]/60 text-xs">
          <button
            onClick={() => {
              setTab('LOGIN');
              setError(null);
            }}
            className={`py-3 text-center font-medium transition-colors border-b-2 ${
              tab === 'LOGIN'
                ? 'border-[#45D6C5] text-[#45D6C5] bg-[#15233B]/50'
                : 'border-transparent text-[#8C9CB5] hover:text-[#E8EEF9]'
            }`}
          >
            Sign In
          </button>
          <button
            onClick={() => {
              setTab('REGISTER');
              setError(null);
            }}
            className={`py-3 text-center font-medium transition-colors border-b-2 ${
              tab === 'REGISTER'
                ? 'border-[#45D6C5] text-[#45D6C5] bg-[#15233B]/50'
                : 'border-transparent text-[#8C9CB5] hover:text-[#E8EEF9]'
            }`}
          >
            Register
          </button>
          <button
            onClick={() => {
              setTab('FORGOT');
              setError(null);
            }}
            className={`py-3 text-center font-medium transition-colors border-b-2 ${
              tab === 'FORGOT'
                ? 'border-[#45D6C5] text-[#45D6C5] bg-[#15233B]/50'
                : 'border-transparent text-[#8C9CB5] hover:text-[#E8EEF9]'
            }`}
          >
            Reset Key
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-4">
          {/* Status Alerts */}
          {error && (
            <div
              role="alert"
              className="p-3 rounded-lg bg-[#F05268]/15 border border-[#F05268]/30 flex items-start gap-2.5 text-xs text-[#F05268]"
            >
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {successMessage && (
            <div
              role="status"
              className="p-3 rounded-lg bg-[#42C99A]/15 border border-[#42C99A]/30 flex items-start gap-2.5 text-xs text-[#42C99A]"
            >
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* TAB 1: LOGIN */}
          {tab === 'LOGIN' && (
            <form onSubmit={handleLogin} className="space-y-3.5">
              <div>
                <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1.5">
                  SOC Work Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-[#8C9CB5] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="analyst@sentinelai.internal"
                    className="w-full bg-[#15233B] border border-[#1A273D] focus:border-[#45D6C5] rounded-lg pl-9 pr-3 py-2 text-xs text-[#E8EEF9] placeholder-[#8C9CB5]/50 outline-none"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-[11px] font-semibold text-[#8C9CB5]">
                    Password Credentials
                  </label>
                  <button
                    type="button"
                    onClick={() => setTab('FORGOT')}
                    className="text-[10px] text-[#45D6C5] hover:underline"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-[#8C9CB5] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full bg-[#15233B] border border-[#1A273D] focus:border-[#45D6C5] rounded-lg pl-9 pr-9 py-2 text-xs text-[#E8EEF9] placeholder-[#8C9CB5]/50 outline-none"
                  />
                  <button
                    type="button"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8C9CB5] hover:text-[#E8EEF9]"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-[#8C9CB5] pt-1">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    defaultChecked
                    className="rounded bg-[#15233B] border-[#1A273D] text-[#45D6C5] focus:ring-0"
                  />
                  <span className="text-[11px]">Remember terminal session</span>
                </label>
                <span className="text-[10px] font-mono text-[#42C99A]">256-bit TLS</span>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 rounded-lg bg-[#45D6C5] hover:bg-[#38bcae] text-[#080D18] font-bold text-xs transition-colors flex items-center justify-center gap-2 mt-2"
              >
                {loading ? 'Authenticating...' : 'Sign In to SOC'}
              </button>

              {/* 1-Click Quick Demo Personas */}
              <div className="pt-4 border-t border-[#1A273D]">
                <div className="text-[11px] font-semibold text-[#8C9CB5] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <UserCheck className="w-3.5 h-3.5 text-[#45D6C5]" />
                  <span>1-Click Demo Profiles</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {demoPersonas.map((p) => (
                    <button
                      key={p.role}
                      type="button"
                      onClick={() => handleQuickFill(p.email)}
                      className="p-2 rounded-lg bg-[#15233B] hover:bg-[#1A273D] border border-[#1A273D] hover:border-[#45D6C5]/40 text-left transition-colors"
                    >
                      <div className="text-xs font-semibold text-[#E8EEF9] truncate">{p.name}</div>
                      <div className="text-[10px] font-mono text-[#45D6C5]">{p.role}</div>
                    </button>
                  ))}
                </div>
              </div>
            </form>
          )}

          {/* TAB 2: REGISTER */}
          {tab === 'REGISTER' && (
            <form onSubmit={handleRegister} className="space-y-3.5">
              <div>
                <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1.5">
                  Full Name
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-[#8C9CB5] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Jordan Mitchell, CISSP"
                    className="w-full bg-[#15233B] border border-[#1A273D] focus:border-[#45D6C5] rounded-lg pl-9 pr-3 py-2 text-xs text-[#E8EEF9] placeholder-[#8C9CB5]/50 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1.5">
                  Enterprise Work Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-[#8C9CB5] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="jordan.mitchell@sentinelai.internal"
                    className="w-full bg-[#15233B] border border-[#1A273D] focus:border-[#45D6C5] rounded-lg pl-9 pr-3 py-2 text-xs text-[#E8EEF9] placeholder-[#8C9CB5]/50 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1.5">
                  Initial Assigned Role (RBAC)
                </label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as UserRole)}
                  className="w-full bg-[#15233B] border border-[#1A273D] focus:border-[#45D6C5] rounded-lg px-3 py-2 text-xs text-[#E8EEF9] outline-none"
                >
                  <option value="SECURITY_ANALYST">Security Analyst (Investigate & Respond)</option>
                  <option value="SOC_MANAGER">SOC Manager (Playbook Approval & Operations)</option>
                  <option value="ADMIN">SOC Administrator (Full System Configuration)</option>
                  <option value="VIEWER">Viewer (Read-Only Metrics & Dashboards)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1.5">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-[#8C9CB5] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Min 8 characters, letters & symbols"
                    className="w-full bg-[#15233B] border border-[#1A273D] focus:border-[#45D6C5] rounded-lg pl-9 pr-9 py-2 text-xs text-[#E8EEF9] placeholder-[#8C9CB5]/50 outline-none"
                  />
                  <button
                    type="button"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8C9CB5] hover:text-[#E8EEF9]"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="p-3 rounded-lg bg-[#15233B] border border-[#1A273D] flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-[#E8EEF9]">Hardware MFA Protection</div>
                  <div className="text-[10px] text-[#8C9CB5]">Require FIDO2 / TOTP challenge</div>
                </div>
                <input
                  type="checkbox"
                  checked={mfaEnabled}
                  onChange={(e) => setMfaEnabled(e.target.checked)}
                  className="rounded bg-[#101B2D] border-[#1A273D] text-[#45D6C5] focus:ring-0"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 rounded-lg bg-[#45D6C5] hover:bg-[#38bcae] text-[#080D18] font-bold text-xs transition-colors flex items-center justify-center gap-2 mt-2"
              >
                {loading ? 'Creating Account...' : 'Complete Registration'}
              </button>
            </form>
          )}

          {/* TAB 3: FORGOT PASSWORD */}
          {tab === 'FORGOT' && (
            <form onSubmit={handleForgot} className="space-y-3.5">
              <p className="text-xs text-[#8C9CB5] leading-relaxed">
                Enter your authorized enterprise email address. The SentinelAI identity engine will dispatch an encrypted one-time recovery key to your corporate mailbox.
              </p>

              <div>
                <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1.5">
                  Verified Work Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-[#8C9CB5] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="analyst@sentinelai.internal"
                    className="w-full bg-[#15233B] border border-[#1A273D] focus:border-[#45D6C5] rounded-lg pl-9 pr-3 py-2 text-xs text-[#E8EEF9] placeholder-[#8C9CB5]/50 outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 rounded-lg bg-[#438CFF] hover:bg-[#3277e6] text-white font-bold text-xs transition-colors flex items-center justify-center gap-2"
              >
                <KeyRound className="w-4 h-4" />
                <span>{loading ? 'Dispatching...' : 'Send Recovery Dispatch'}</span>
              </button>

              <button
                type="button"
                onClick={() => setTab('LOGIN')}
                className="w-full py-2 text-center text-xs text-[#8C9CB5] hover:text-[#E8EEF9]"
              >
                Back to Sign In
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
