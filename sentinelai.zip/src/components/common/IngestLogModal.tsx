import React, { useState } from 'react';
import { X, Send, Sparkles, CheckCircle, AlertTriangle } from 'lucide-react';

interface IngestLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  onIngest: (logData: any) => Promise<any>;
}

export const IngestLogModal: React.FC<IngestLogModalProps> = ({ isOpen, onClose, onIngest }) => {
  const [source, setSource] = useState('AUTH_SERVER');
  const [eventType, setEventType] = useState('AUTH_FAILURE_BURST');
  const [severity, setSeverity] = useState('HIGH');
  const [sourceIp, setSourceIp] = useState('185.220.101.5');
  const [destinationIp, setDestinationIp] = useState('10.0.1.15');
  const [message, setMessage] = useState('Multiple Kerberos pre-authentication failures detected for service account svc_backup');
  const [payloadText, setPayloadText] = useState('{\n  "failureCount": 35,\n  "targetAccount": "svc_backup",\n  "protocol": "Kerberos v5"\n}');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [resultNotice, setResultNotice] = useState<any>(null);

  if (!isOpen) return null;

  const loadPreset = (presetName: string) => {
    setResultNotice(null);
    if (presetName === 'brute') {
      setSource('AUTH_SERVER');
      setEventType('AUTH_FAILURE_BURST');
      setSeverity('CRITICAL');
      setSourceIp('185.220.101.5');
      setDestinationIp('10.0.1.15');
      setMessage('High-velocity Kerberos password spray detected targeting domain admin account svc_backup');
      setPayloadText('{\n  "failureCount": 42,\n  "cipher": "rc4-hmac",\n  "targetAccount": "svc_backup"\n}');
    } else if (presetName === 'powershell') {
      setSource('EDR_AGENT');
      setEventType('SUSPICIOUS_PROCESS_EXECUTION');
      setSeverity('CRITICAL');
      setSourceIp('10.0.8.42');
      setDestinationIp('194.26.29.112');
      setMessage('Encoded PowerShell execution spawned from excel.exe attempting outbound network connection');
      setPayloadText('{\n  "parentProcess": "excel.exe",\n  "commandLine": "powershell.exe -w hidden -enc JABzAD0ATgBlAHcALQ...",\n  "ppid": 3120\n}');
    } else if (presetName === 'portscan') {
      setSource('FIREWALL');
      setEventType('PORT_SCAN_SYN_BURST');
      setSeverity('MEDIUM');
      setSourceIp('45.154.255.89');
      setDestinationIp('192.168.10.5');
      setMessage('Rapid SYN sweep scanning across TCP ports 1-1024 blocked by edge firewall filter');
      setPayloadText('{\n  "portsScanned": 1024,\n  "durationMs": 2400,\n  "action": "DROP"\n}');
    } else if (presetName === 'sqli') {
      setSource('WAF');
      setEventType('SQL_INJECTION_ATTEMPT');
      setSeverity('HIGH');
      setSourceIp('103.145.13.2');
      setDestinationIp('192.168.10.5');
      setMessage('WAF Rule 942100 blocked UNION SELECT payload in /api/v1/billing parameter id');
      setPayloadText('{\n  "parameter": "id",\n  "payload": "\' UNION SELECT null, username, password_hash FROM admin_users--",\n  "response": 403\n}');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setResultNotice(null);

    let parsedPayload = {};
    try {
      parsedPayload = JSON.parse(payloadText);
    } catch {
      parsedPayload = { raw: payloadText };
    }

    try {
      const res = await onIngest({
        source,
        eventType,
        severity,
        sourceIp,
        destinationIp,
        message,
        payload: parsedPayload,
      });
      setResultNotice(res);
    } catch (err: any) {
      setResultNotice({ error: err.message || 'Ingestion failed' });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-2xl bg-[#101B2D] border border-[#1A273D] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#1A273D] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#45D6C5]/10 border border-[#45D6C5]/30 flex items-center justify-center text-[#45D6C5]">
              <Send className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-[#E8EEF9]">Ingest Security Event</h3>
              <p className="text-[11px] text-[#8C9CB5]">
                Simulate or ingest raw structured security telemetry into the detection engine
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#8C9CB5] hover:text-[#E8EEF9] hover:bg-[#15233B] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          {/* Quick Presets */}
          <div>
            <div className="text-[11px] font-semibold text-[#8C9CB5] uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#45D6C5]" />
              <span>Load Threat Scenario Preset</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => loadPreset('brute')}
                className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-[#15233B] hover:bg-[#1E2D45] text-[#E8EEF9] border border-[#1A273D] transition-colors text-left"
              >
                Brute Force Spray
              </button>
              <button
                type="button"
                onClick={() => loadPreset('powershell')}
                className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-[#15233B] hover:bg-[#1E2D45] text-[#E8EEF9] border border-[#1A273D] transition-colors text-left"
              >
                Encoded PowerShell
              </button>
              <button
                type="button"
                onClick={() => loadPreset('sqli')}
                className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-[#15233B] hover:bg-[#1E2D45] text-[#E8EEF9] border border-[#1A273D] transition-colors text-left"
              >
                WAF SQL Injection
              </button>
              <button
                type="button"
                onClick={() => loadPreset('portscan')}
                className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-[#15233B] hover:bg-[#1E2D45] text-[#E8EEF9] border border-[#1A273D] transition-colors text-left"
              >
                SYN Port Sweep
              </button>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Source Sensor</label>
                <select
                  value={source}
                  onChange={(e) => setSource(e.target.value)}
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-2.5 py-1.5 text-xs text-[#E8EEF9] outline-none focus:border-[#45D6C5]"
                >
                  <option value="AUTH_SERVER">AUTH_SERVER</option>
                  <option value="FIREWALL">FIREWALL</option>
                  <option value="EDR_AGENT">EDR_AGENT</option>
                  <option value="WAF">WAF</option>
                  <option value="CLOUD_TRAIL">CLOUD_TRAIL</option>
                  <option value="DNS_PROXY">DNS_PROXY</option>
                  <option value="NETWORK_TAP">NETWORK_TAP</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Event Type</label>
                <input
                  type="text"
                  value={eventType}
                  onChange={(e) => setEventType(e.target.value)}
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-2.5 py-1.5 text-xs text-[#E8EEF9] outline-none focus:border-[#45D6C5]"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Severity</label>
                <select
                  value={severity}
                  onChange={(e) => setSeverity(e.target.value)}
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-2.5 py-1.5 text-xs text-[#E8EEF9] outline-none focus:border-[#45D6C5]"
                >
                  <option value="CRITICAL">CRITICAL</option>
                  <option value="HIGH">HIGH</option>
                  <option value="MEDIUM">MEDIUM</option>
                  <option value="LOW">LOW</option>
                  <option value="INFO">INFO</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Source IP</label>
                <input
                  type="text"
                  value={sourceIp}
                  onChange={(e) => setSourceIp(e.target.value)}
                  placeholder="e.g. 185.220.101.5"
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-2.5 py-1.5 text-xs font-mono text-[#E8EEF9] outline-none focus:border-[#45D6C5]"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Destination IP</label>
                <input
                  type="text"
                  value={destinationIp}
                  onChange={(e) => setDestinationIp(e.target.value)}
                  placeholder="e.g. 10.0.1.15"
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-2.5 py-1.5 text-xs font-mono text-[#E8EEF9] outline-none focus:border-[#45D6C5]"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Message</label>
              <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-2.5 py-1.5 text-xs text-[#E8EEF9] outline-none focus:border-[#45D6C5]"
                required
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Structured Payload (JSON)</label>
              <textarea
                value={payloadText}
                onChange={(e) => setPayloadText(e.target.value)}
                rows={3}
                className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg p-2.5 text-xs font-mono text-[#E8EEF9] outline-none focus:border-[#45D6C5]"
              />
            </div>

            {/* Ingestion Result Box */}
            {resultNotice && (
              <div
                className={`p-3 rounded-lg border text-xs ${
                  resultNotice.error
                    ? 'bg-[#F05268]/10 border-[#F05268]/30 text-[#F05268]'
                    : 'bg-[#42C99A]/10 border-[#42C99A]/30 text-[#42C99A]'
                }`}
              >
                {resultNotice.error ? (
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    <span>{resultNotice.error}</span>
                  </div>
                ) : (
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 font-semibold">
                      <CheckCircle className="w-4 h-4 shrink-0" />
                      <span>Event Ingested Successfully! (ID: {resultNotice.log?.id})</span>
                    </div>
                    <div className="text-[11px] font-mono opacity-90">
                      Calculated Risk Score: {resultNotice.risk?.score}/100 ({resultNotice.risk?.tier}) · MITRE {resultNotice.mitre?.id} ({resultNotice.mitre?.name})
                    </div>
                    {resultNotice.alertCreated && (
                      <div className="text-[11px] text-[#F05268] font-semibold pt-1">
                        High risk triggered Alert generation: {resultNotice.alertCreated.id}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            <div className="pt-2 flex items-center justify-end gap-3 border-t border-[#1A273D]">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-lg text-xs font-medium text-[#8C9CB5] hover:text-[#E8EEF9] hover:bg-[#15233B] transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold bg-[#45D6C5] hover:bg-[#38bcae] text-[#080D18] transition-colors disabled:opacity-50"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isSubmitting ? 'Ingesting...' : 'Ingest Event'}</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
