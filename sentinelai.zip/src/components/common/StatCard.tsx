import React from 'react';
import { Severity, AlertStatus, IncidentStatus } from '../../types/index.ts';

interface StatCardProps {
  label: string;
  value: number | string;
  subtext?: string;
  trend?: string;
  trendDirection?: 'up' | 'down' | 'neutral';
  icon?: React.ComponentType<{ className?: string }>;
  accentColor?: string;
  onClick?: () => void;
}

export const StatCard: React.FC<StatCardProps> = ({
  label,
  value,
  subtext,
  trend,
  trendDirection = 'neutral',
  icon: Icon,
  accentColor = '#45D6C5',
  onClick,
}) => {
  return (
    <div
      onClick={onClick}
      className={`p-4 rounded-xl bg-[#101B2D] border border-[#1A273D] hover:border-[#2D4263] transition-all flex flex-col justify-between ${
        onClick ? 'cursor-pointer hover:bg-[#132035]' : ''
      }`}
    >
      <div className="flex items-center justify-between gap-2 mb-2">
        <span className="text-xs font-medium text-[#8C9CB5] tracking-wide uppercase truncate">
          {label}
        </span>
        {Icon && (
          <div
            className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
            style={{ backgroundColor: `${accentColor}15`, color: accentColor }}
          >
            <Icon className="w-4 h-4" />
          </div>
        )}
      </div>

      <div className="flex items-baseline justify-between gap-2">
        <span className="text-2xl font-bold font-mono tracking-tight text-[#E8EEF9] tabular-nums">
          {typeof value === 'number' ? value.toLocaleString() : value}
        </span>
        {trend && (
          <span
            className={`text-[11px] font-mono font-medium ${
              trendDirection === 'up'
                ? 'text-[#F05268]'
                : trendDirection === 'down'
                ? 'text-[#42C99A]'
                : 'text-[#8C9CB5]'
            }`}
          >
            {trend}
          </span>
        )}
      </div>

      {subtext && <div className="text-[11px] text-[#8C9CB5]/80 mt-1 truncate">{subtext}</div>}
    </div>
  );
};

export const SeverityBadge: React.FC<{ severity: Severity }> = ({ severity }) => {
  switch (severity) {
    case 'CRITICAL':
      return (
        <span className="inline-flex items-center text-[11px] font-mono font-semibold text-[#F05268]">
          <span className="w-1.5 h-1.5 rounded-full bg-[#F05268] mr-1.5" />
          CRITICAL
        </span>
      );
    case 'HIGH':
      return (
        <span className="inline-flex items-center text-[11px] font-mono font-semibold text-[#FF754C]">
          <span className="w-1.5 h-1.5 rounded-full bg-[#FF754C] mr-1.5" />
          HIGH
        </span>
      );
    case 'MEDIUM':
      return (
        <span className="inline-flex items-center text-[11px] font-mono font-medium text-[#E8AD4B]">
          <span className="w-1.5 h-1.5 rounded-full bg-[#E8AD4B] mr-1.5" />
          MEDIUM
        </span>
      );
    case 'LOW':
      return (
        <span className="inline-flex items-center text-[11px] font-mono font-medium text-[#438CFF]">
          <span className="w-1.5 h-1.5 rounded-full bg-[#438CFF] mr-1.5" />
          LOW
        </span>
      );
    case 'INFO':
    default:
      return (
        <span className="inline-flex items-center text-[11px] font-mono font-medium text-[#8C9CB5]">
          <span className="w-1.5 h-1.5 rounded-full bg-[#8C9CB5] mr-1.5" />
          INFO
        </span>
      );
  }
};

export const StatusBadge: React.FC<{ status: AlertStatus | IncidentStatus | string }> = ({ status }) => {
  const getStyle = () => {
    switch (status) {
      case 'NEW':
      case 'DETECTED':
        return 'text-[#45D6C5]';
      case 'OPEN':
      case 'TRIAGED':
        return 'text-[#438CFF]';
      case 'INVESTIGATING':
        return 'text-[#E8AD4B]';
      case 'ESCALATED':
      case 'CONTAINMENT_REVIEW':
        return 'text-[#F05268]';
      case 'RECOVERY':
        return 'text-[#A070FF]';
      case 'RESOLVED':
      case 'REMEDIATED':
        return 'text-[#42C99A]';
      case 'FALSE_POSITIVE':
      case 'ACCEPTED_RISK':
        return 'text-[#8C9CB5]';
      default:
        return 'text-[#8C9CB5]';
    }
  };

  return (
    <span className={`text-[11px] font-mono font-medium tracking-wide uppercase ${getStyle()}`}>
      {status.replace(/_/g, ' ')}
    </span>
  );
};
