import React from 'react';
import {
  ShieldAlert,
  Activity,
  FileText,
  AlertTriangle,
  Bell,
  LifeBuoy,
  Mail,
  Network,
  Bug,
  Database,
  Bot,
  Zap,
  GitBranch,
  BarChart3,
  Server,
  Users,
  ShieldCheck,
  Cpu,
  Sliders,
  Settings,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';

export type NavItemKey =
  | 'overview'
  | 'monitoring'
  | 'logs'
  | 'threats'
  | 'alerts'
  | 'incidents'
  | 'phishing'
  | 'network'
  | 'vulnerabilities'
  | 'intel'
  | 'copilot'
  | 'automation'
  | 'playbooks'
  | 'reports'
  | 'assets'
  | 'users'
  | 'audit'
  | 'integrations'
  | 'ai-config'
  | 'settings';

interface SidebarProps {
  activeNav: NavItemKey;
  onSelectNav: (key: NavItemKey) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  criticalCount: number;
}

interface NavSection {
  title: string;
  items: Array<{
    key: NavItemKey;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badgeCount?: number;
  }>;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeNav,
  onSelectNav,
  collapsed,
  onToggleCollapse,
  criticalCount,
}) => {
  const sections: NavSection[] = [
    {
      title: 'Operations',
      items: [
        { key: 'overview', label: 'Overview Dashboard', icon: Activity },
        { key: 'monitoring', label: 'Security Monitoring', icon: ShieldAlert },
        { key: 'logs', label: 'Security Logs', icon: FileText },
        { key: 'threats', label: 'Threat Detection', icon: AlertTriangle },
        { key: 'alerts', label: 'Alert Management', icon: Bell, badgeCount: criticalCount },
        { key: 'incidents', label: 'Incident Management', icon: LifeBuoy },
      ],
    },
    {
      title: 'Intel & Analysis',
      items: [
        { key: 'phishing', label: 'Phishing Detection', icon: Mail },
        { key: 'network', label: 'Network Security', icon: Network },
        { key: 'vulnerabilities', label: 'Vulnerability Mgmt', icon: Bug },
        { key: 'intel', label: 'Threat Intelligence', icon: Database },
        { key: 'copilot', label: 'AI Investigation', icon: Bot },
      ],
    },
    {
      title: 'SOAR & Automation',
      items: [
        { key: 'automation', label: 'Automation Center', icon: Zap },
        { key: 'playbooks', label: 'Playbook Mgmt', icon: GitBranch },
        { key: 'reports', label: 'Security Reports', icon: BarChart3 },
        { key: 'assets', label: 'Asset Management', icon: Server },
      ],
    },
    {
      title: 'Administration',
      items: [
        { key: 'users', label: 'User Management', icon: Users },
        { key: 'audit', label: 'Audit Logs', icon: ShieldCheck },
        { key: 'integrations', label: 'Integrations', icon: Cpu },
        { key: 'ai-config', label: 'AI Configuration', icon: Sliders },
        { key: 'settings', label: 'System Settings', icon: Settings },
      ],
    },
  ];

  return (
    <aside
      className={`fixed top-0 bottom-0 left-0 z-30 flex flex-col bg-[#0C1424] border-r border-[#1A273D] transition-all duration-200 select-none ${
        collapsed ? 'w-18' : 'w-64'
      }`}
    >
      {/* Brand Zone */}
      <div className="h-16 px-4 flex items-center justify-between border-b border-[#1A273D]">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="w-9 h-9 rounded-lg bg-[#45D6C5]/10 border border-[#45D6C5]/30 flex items-center justify-center shrink-0">
            <ShieldAlert className="w-5 h-5 text-[#45D6C5]" />
          </div>
          {!collapsed && (
            <div className="flex flex-col truncate">
              <span className="text-base font-bold text-[#E8EEF9] tracking-tight whitespace-nowrap">
                SentinelAI
              </span>
              <span className="text-[11px] text-[#8C9CB5] tracking-wide uppercase font-medium">
                Enterprise SOC
              </span>
            </div>
          )}
        </div>
        <button
          onClick={onToggleCollapse}
          className="p-1.5 rounded-md text-[#8C9CB5] hover:text-[#E8EEF9] hover:bg-[#101B2D] transition-colors"
          title={collapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
          aria-label={collapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      {/* Nav List */}
      <div className="flex-1 overflow-y-auto px-2 py-3 space-y-5">
        {sections.map((section) => (
          <div key={section.title} className="space-y-1">
            {!collapsed && (
              <div className="px-3 text-[10px] font-semibold text-[#8C9CB5]/70 uppercase tracking-wider mb-1.5">
                {section.title}
              </div>
            )}
            {section.items.map((item) => {
              const Icon = item.icon;
              const isActive = activeNav === item.key;
              return (
                <button
                  key={item.key}
                  onClick={() => onSelectNav(item.key)}
                  title={collapsed ? item.label : undefined}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-all text-left group ${
                    isActive
                      ? 'bg-[#15233B] text-[#45D6C5] font-semibold border-l-2 border-[#45D6C5]'
                      : 'text-[#8C9CB5] hover:text-[#E8EEF9] hover:bg-[#101B2D]'
                  }`}
                >
                  <Icon
                    className={`w-4 h-4 shrink-0 transition-colors ${
                      isActive ? 'text-[#45D6C5]' : 'text-[#8C9CB5] group-hover:text-[#E8EEF9]'
                    }`}
                  />
                  {!collapsed && <span className="truncate flex-1">{item.label}</span>}
                  {!collapsed && item.badgeCount !== undefined && item.badgeCount > 0 && (
                    <span className="text-[10px] font-mono font-semibold px-1.5 py-0.2 rounded bg-[#F05268]/20 text-[#F05268] border border-[#F05268]/30">
                      {item.badgeCount}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* Footer Profile Status */}
      <div className="p-3 border-t border-[#1A273D] bg-[#0A101C]">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-[#438CFF]/20 border border-[#438CFF]/40 flex items-center justify-center font-bold text-xs text-[#438CFF] shrink-0">
            AV
          </div>
          {!collapsed && (
            <div className="flex-1 min-w-0">
              <div className="text-xs font-semibold text-[#E8EEF9] truncate">Alex Vance</div>
              <div className="text-[10px] text-[#45D6C5] font-mono">SOC Admin · Active</div>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
};
