import React, { useState } from 'react';
import {
  Search,
  Bell,
  RefreshCw,
  PlusCircle,
  Shield,
  UserCheck,
  CheckCircle2,
  AlertOctagon,
  LogOut,
  LogIn,
} from 'lucide-react';
import { UserRole, User } from '../../types/index.ts';

interface TopNavProps {
  currentModuleTitle: string;
  currentModuleCategory: string;
  activeRole: UserRole;
  onChangeRole: (role: UserRole) => void;
  onRefresh: () => void;
  isRefreshing: boolean;
  onOpenIngestModal: () => void;
  criticalAlertsCount: number;
  openIncidentsCount: number;
  currentUser?: User | null;
  onOpenAuthModal: () => void;
  onLogout: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  currentModuleTitle,
  currentModuleCategory,
  activeRole,
  onChangeRole,
  onRefresh,
  isRefreshing,
  onOpenIngestModal,
  criticalAlertsCount,
  openIncidentsCount,
  currentUser,
  onOpenAuthModal,
  onLogout,
}) => {
  const [showRoleDropdown, setShowRoleDropdown] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const roles: { role: UserRole; label: string; desc: string }[] = [
    { role: 'ADMIN', label: 'Admin', desc: 'Full application & configuration access' },
    { role: 'SECURITY_ANALYST', label: 'Security Analyst', desc: 'Investigate alerts, incidents, & run tools' },
    { role: 'SOC_MANAGER', label: 'SOC Manager', desc: 'Approve playbooks & review operational metrics' },
    { role: 'VIEWER', label: 'Viewer', desc: 'Read-only access to dashboards & reports' },
  ];

  return (
    <header className="h-16 px-6 bg-[#0C1424] border-b border-[#1A273D] flex items-center justify-between gap-4 sticky top-0 z-20">
      {/* Zone 1: Breadcrumbs */}
      <div className="flex items-center gap-2 text-xs">
        <span className="text-[#8C9CB5]">SentinelAI</span>
        <span className="text-[#8C9CB5]/50">/</span>
        <span className="text-[#8C9CB5]">{currentModuleCategory}</span>
        <span className="text-[#8C9CB5]/50">/</span>
        <span className="font-semibold text-[#E8EEF9]">{currentModuleTitle}</span>
      </div>

      {/* Zone 2: Global Search */}
      <div className="flex-1 max-w-md mx-4 relative hidden md:block">
        <Search className="w-4 h-4 text-[#8C9CB5] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search by IP, hash, CVE, alert, or incident..."
          className="w-full bg-[#101B2D] border border-[#1A273D] focus:border-[#45D6C5] rounded-lg pl-9 pr-3 py-1.5 text-xs text-[#E8EEF9] placeholder-[#8C9CB5]/60 outline-none transition-colors"
        />
      </div>

      {/* Zone 3: Quick Actions & Status */}
      <div className="flex items-center gap-3 shrink-0">
        {/* Quick Tickers */}
        <div className="hidden lg:flex items-center gap-4 text-xs font-mono mr-2">
          <div className="flex items-center gap-1.5 text-[#F05268]">
            <AlertOctagon className="w-3.5 h-3.5" />
            <span>{criticalAlertsCount} Critical</span>
          </div>
          <div className="text-[#1A273D]">|</div>
          <div className="flex items-center gap-1.5 text-[#E8AD4B]">
            <Shield className="w-3.5 h-3.5" />
            <span>{openIncidentsCount} Open Incidents</span>
          </div>
        </div>

        {/* Refresh */}
        <button
          onClick={onRefresh}
          disabled={isRefreshing}
          className="p-2 rounded-lg text-[#8C9CB5] hover:text-[#E8EEF9] hover:bg-[#101B2D] border border-[#1A273D] transition-colors"
          title="Refresh SOC telemetry"
          aria-label="Refresh SOC telemetry"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-[#45D6C5]' : ''}`} />
        </button>

        {/* Ingest Log CTA */}
        {activeRole !== 'VIEWER' && (
          <button
            onClick={onOpenIngestModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[#101B2D] hover:bg-[#15233B] text-[#45D6C5] border border-[#45D6C5]/30 transition-colors whitespace-nowrap"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Ingest Event</span>
          </button>
        )}

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative p-2 rounded-lg text-[#8C9CB5] hover:text-[#E8EEF9] hover:bg-[#101B2D] border border-[#1A273D] transition-colors"
            title="Notifications"
            aria-label="Notifications"
          >
            <Bell className="w-3.5 h-3.5" />
            {criticalAlertsCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-[#F05268] rounded-full" />
            )}
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-[#101B2D] border border-[#1A273D] rounded-xl shadow-2xl p-4 z-50">
              <div className="flex items-center justify-between pb-2 border-b border-[#1A273D] mb-3">
                <span className="text-xs font-semibold text-[#E8EEF9]">Active Notifications</span>
                <span className="text-[10px] text-[#8C9CB5] font-mono">Real-time alerts</span>
              </div>
              <div className="space-y-2.5 text-xs">
                <div className="p-2.5 rounded-lg bg-[#15233B] border border-[#F05268]/20">
                  <div className="flex items-center justify-between text-[#F05268] font-medium text-[11px] mb-1">
                    <span>Critical Alert alt-001</span>
                    <span className="font-mono text-[10px]">2m ago</span>
                  </div>
                  <p className="text-[#8C9CB5] text-[11px]">
                    Kerberos pre-authentication failure burst on DC-01 from Tor Exit node.
                  </p>
                </div>
                <div className="p-2.5 rounded-lg bg-[#15233B] border border-[#E8AD4B]/20">
                  <div className="flex items-center justify-between text-[#E8AD4B] font-medium text-[11px] mb-1">
                    <span>Playbook Pending Approval</span>
                    <span className="font-mono text-[10px]">15m ago</span>
                  </div>
                  <p className="text-[#8C9CB5] text-[11px]">
                    Firewall perimeter block waiting for authorization in Automation Center.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* User Profile & Auth Session */}
        {currentUser ? (
          <div className="relative">
            <button
              onClick={() => setShowRoleDropdown(!showRoleDropdown)}
              className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-[#101B2D] border border-[#1A273D] text-[#E8EEF9] hover:border-[#45D6C5]/50 transition-colors"
              title="User Account & Security Role"
            >
              <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-[#45D6C5] to-[#438CFF] text-[#080D18] font-bold text-[10px] flex items-center justify-center">
                {currentUser.name.charAt(0)}
              </div>
              <span className="font-medium text-xs max-w-[100px] truncate hidden sm:inline">
                {currentUser.name.split(' ')[0]}
              </span>
              <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-[#15233B] text-[#45D6C5] border border-[#45D6C5]/30">
                {activeRole}
              </span>
            </button>

            {showRoleDropdown && (
              <div className="absolute right-0 mt-2 w-72 bg-[#101B2D] border border-[#1A273D] rounded-xl shadow-2xl p-2 z-50">
                {/* Account Summary */}
                <div className="px-3 py-2.5 border-b border-[#1A273D] mb-1">
                  <div className="text-xs font-bold text-[#E8EEF9] truncate">{currentUser.name}</div>
                  <div className="text-[11px] text-[#8C9CB5] truncate font-mono">{currentUser.email}</div>
                  <div className="flex items-center justify-between mt-1.5 text-[10px]">
                    <span className="text-[#42C99A] font-semibold flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#42C99A]" />
                      Active SOC Session
                    </span>
                    <span className="text-[#8C9CB5]">MFA Enabled</span>
                  </div>
                </div>

                <div className="px-2 py-1 text-[10px] font-semibold text-[#8C9CB5] uppercase tracking-wider">
                  Switch Role Persona (RBAC)
                </div>
                <div className="space-y-1 mt-1">
                  {roles.map((r) => {
                    const isCurrent = activeRole === r.role;
                    return (
                      <button
                        key={r.role}
                        onClick={() => {
                          onChangeRole(r.role);
                          setShowRoleDropdown(false);
                        }}
                        className={`w-full flex items-start gap-2.5 p-2 rounded-lg text-left transition-colors ${
                          isCurrent
                            ? 'bg-[#15233B] text-[#45D6C5] border border-[#45D6C5]/30'
                            : 'hover:bg-[#1A273D] text-[#8C9CB5]'
                        }`}
                      >
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-semibold text-[#E8EEF9]">{r.label}</span>
                            {isCurrent && <CheckCircle2 className="w-3.5 h-3.5 text-[#45D6C5]" />}
                          </div>
                          <p className="text-[10px] text-[#8C9CB5] mt-0.5 leading-tight">{r.desc}</p>
                        </div>
                      </button>
                    );
                  })}
                </div>

                <div className="pt-2 mt-2 border-t border-[#1A273D] space-y-1">
                  <button
                    onClick={() => {
                      setShowRoleDropdown(false);
                      onOpenAuthModal();
                    }}
                    className="w-full flex items-center gap-2 p-2 rounded-lg text-left text-xs text-[#E8EEF9] hover:bg-[#15233B] transition-colors"
                  >
                    <LogIn className="w-3.5 h-3.5 text-[#45D6C5]" />
                    <span>Switch / Register New Account</span>
                  </button>
                  <button
                    onClick={() => {
                      setShowRoleDropdown(false);
                      onLogout();
                    }}
                    className="w-full flex items-center gap-2 p-2 rounded-lg text-left text-xs text-[#F05268] hover:bg-[#F05268]/10 transition-colors"
                  >
                    <LogOut className="w-3.5 h-3.5 text-[#F05268]" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <button
            onClick={onOpenAuthModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#45D6C5] hover:bg-[#38bcae] text-[#080D18] transition-colors"
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>Sign In</span>
          </button>
        )}
      </div>
    </header>
  );
};
