/**
 * SentinelAI - TypeScript Type Definitions
 */

export type UserRole = 'ADMIN' | 'SECURITY_ANALYST' | 'SOC_MANAGER' | 'VIEWER';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  status: 'ACTIVE' | 'SUSPENDED';
  mfaEnabled: boolean;
  lastLogin: string;
  avatarUrl?: string;
  organizationId: string;
}

export type Severity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';

export type AlertStatus = 'NEW' | 'OPEN' | 'INVESTIGATING' | 'ESCALATED' | 'RESOLVED' | 'FALSE_POSITIVE';

export type IncidentStatus = 'DETECTED' | 'TRIAGED' | 'INVESTIGATING' | 'CONTAINMENT_REVIEW' | 'RECOVERY' | 'RESOLVED';

export type IncidentPriority = 'P1_CRITICAL' | 'P2_HIGH' | 'P3_MEDIUM' | 'P4_LOW';

export interface SecurityLog {
  id: string;
  timestamp: string;
  source: 'FIREWALL' | 'AUTH_SERVER' | 'EDR_AGENT' | 'CLOUD_TRAIL' | 'WAF' | 'NETWORK_TAP' | 'DNS_PROXY';
  eventType: string;
  severity: Severity;
  sourceIp?: string;
  destinationIp?: string;
  sourceGeo?: string;
  message: string;
  payload: Record<string, any>;
  processed: boolean;
  associatedAlertId?: string;
}

export interface SecurityAlert {
  id: string;
  title: string;
  timestamp: string;
  severity: Severity;
  status: AlertStatus;
  riskScore: number; // 0-100
  source: string;
  sourceIp?: string;
  destinationIp?: string;
  detectionRuleId?: string;
  ruleName: string;
  mitreTechnique?: string;
  mitreTactic?: string;
  assignedTo?: string;
  assignedToName?: string;
  incidentId?: string;
  evidence: Array<{
    type: string;
    description: string;
    value: string;
  }>;
  detectionReason: string;
  confidence: number; // 0-100
  notes: Array<{
    id: string;
    author: string;
    timestamp: string;
    text: string;
  }>;
}

export interface SecurityIncident {
  id: string;
  incidentNumber: string;
  title: string;
  status: IncidentStatus;
  priority: IncidentPriority;
  leadInvestigator: string;
  leadInvestigatorName: string;
  createdAt: string;
  updatedAt: string;
  summary: string;
  mitreTechniques: string[];
  affectedAssets: string[];
  alertIds: string[];
  evidenceIds: string[];
  timeline: Array<{
    id: string;
    timestamp: string;
    stage: IncidentStatus;
    author: string;
    description: string;
  }>;
  notes: Array<{
    id: string;
    author: string;
    timestamp: string;
    content: string;
  }>;
}

export interface PhishingAnalysis {
  id: string;
  targetUrl?: string;
  emailSubject?: string;
  senderEmail?: string;
  headers?: string;
  riskScore: number; // 0 - 100
  classification: 'SAFE' | 'SUSPICIOUS' | 'MALICIOUS_PHISHING';
  indicators: string[];
  domainReputation: {
    domain: string;
    ageDays: number;
    registrar: string;
    dnsValid: boolean;
    spfPassed: boolean;
    dkimPassed: boolean;
    virusTotalScore: string;
  };
  evidence: string[];
  recommendedActions: string[];
  analyzedAt: string;
}

export interface NetworkConnection {
  id: string;
  timestamp: string;
  sourceIp: string;
  sourcePort: number;
  destinationIp: string;
  destinationPort: number;
  protocol: 'TCP' | 'UDP' | 'ICMP' | 'DNS' | 'HTTPS' | 'SSH';
  bytesSent: number;
  bytesReceived: number;
  flags: string;
  status: 'ALLOWED' | 'BLOCKED' | 'FLAGGED_ANOMALOUS';
  anomalyReason?: string;
}

export interface Vulnerability {
  id: string;
  cveId: string;
  title: string;
  description: string;
  cvssScore: number; // 0.0 - 10.0
  severity: Severity;
  assetId: string;
  assetName: string;
  status: 'OPEN' | 'ACKNOWLEDGED' | 'IN_PROGRESS' | 'REMEDIATED' | 'ACCEPTED_RISK';
  remediationPlan: string;
  discoveredAt: string;
  scannedBy: 'NMAP_VULNERS' | 'OWASP_ZAP' | 'TRIVY_CONTAINER' | 'MANUAL_AUDIT';
}

export interface ThreatIndicator {
  id: string;
  type: 'IPV4' | 'DOMAIN' | 'URL' | 'FILE_HASH_SHA256' | 'EMAIL';
  value: string;
  threatType: 'C2_SERVER' | 'RANSOMWARE_DISTRIBUTION' | 'PHISHING_HOST' | 'BOTNET_NODE' | 'EXPLOIT_DROPPER';
  confidence: number;
  firstSeen: string;
  lastSeen: string;
  source: string;
  activeStatus: 'ACTIVE' | 'REVOKED' | 'UNDER_REVIEW';
  enrichment?: {
    reputationScore: number;
    maliciousVotes: number;
    harmlessVotes: number;
    country?: string;
    autonomousSystem?: string;
  };
}

export interface DetectionRule {
  id: string;
  name: string;
  description: string;
  category: 'AUTH_ANOMALY' | 'NETWORK_INTRUSION' | 'MALWARE_BEHAVIOR' | 'PRIVILEGE_ESCALATION' | 'DATA_EXFILTRATION';
  severity: Severity;
  enabled: boolean;
  thresholdCount: number;
  timeWindowSeconds: number;
  mitreId: string;
  matchedCount: number;
  lastTriggered?: string;
}

export interface Playbook {
  id: string;
  name: string;
  description: string;
  triggerEvent: string;
  category: 'BRUTE_FORCE' | 'PHISHING' | 'VULNERABILITY' | 'NETWORK_ANOMALY';
  requiresApproval: boolean;
  enabled: boolean;
  steps: Array<{
    order: number;
    name: string;
    actionType: 'ENRICH_IOC' | 'CREATE_ALERT' | 'ISOLATE_HOST' | 'BLOCK_IP' | 'NOTIFY_TEAM' | 'CREATE_INCIDENT';
    status: 'PENDING' | 'EXECUTING' | 'COMPLETED' | 'WAITING_APPROVAL';
  }>;
  executionCount: number;
}

export interface AutomationRun {
  id: string;
  playbookId: string;
  playbookName: string;
  triggerPayload: string;
  status: 'PENDING_APPROVAL' | 'RUNNING' | 'COMPLETED' | 'REJECTED' | 'FAILED';
  startedAt: string;
  completedAt?: string;
  executedBy: string;
  requiresApproval: boolean;
  approvalDetails?: {
    approvedBy?: string;
    approvedAt?: string;
    reason?: string;
  };
  outputLogs: string[];
}

export interface SecurityReport {
  id: string;
  title: string;
  type: 'DAILY_SUMMARY' | 'WEEKLY_THREAT' | 'INCIDENT_INVESTIGATION' | 'VULNERABILITY_ASSESSMENT' | 'SOC_METRICS';
  generatedAt: string;
  generatedBy: string;
  dateRange: string;
  format: 'PDF' | 'CSV' | 'JSON';
  summaryMetrics: Record<string, any>;
  findingsCount: number;
}

export interface MonitoredAsset {
  id: string;
  name: string;
  type: 'SERVER' | 'WORKSTATION' | 'CLOUD_VM' | 'DATABASE' | 'FIREWALL' | 'API_GATEWAY';
  ipAddress: string;
  hostname: string;
  owner: string;
  environment: 'PRODUCTION' | 'STAGING' | 'CORPORATE';
  criticality: 'TIER_1_CRITICAL' | 'TIER_2_HIGH' | 'TIER_3_MEDIUM' | 'TIER_4_LOW';
  authorized: boolean;
  lastMonitored: string;
  activeAlertsCount: number;
  openVulnerabilitiesCount: number;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  action: string;
  category: 'AUTH' | 'ALERT_MODIFIED' | 'INCIDENT_ACTION' | 'PLAYBOOK_EXECUTED' | 'SETTINGS_CHANGED' | 'REPORT_EXPORTED';
  details: string;
  ipAddress: string;
  status: 'SUCCESS' | 'FAILED' | 'BLOCKED';
}

export interface IntegrationConfig {
  id: string;
  name: string;
  provider: 'GEMINI_AI' | 'VIRUSTOTAL' | 'MITRE_ATTACK' | 'NMAP' | 'OWASP_ZAP' | 'REDIS' | 'N8N_WEBHOOK' | 'SMTP';
  status: 'CONNECTED' | 'DISCONNECTED' | 'ERROR';
  maskedApiKey?: string;
  endpointUrl?: string;
  lastSync?: string;
  latencyMs?: number;
  error?: string;
  requiredFor: string;
}

export interface AiInvestigationResponse {
  summary: string;
  risk_level: 'critical' | 'high' | 'medium' | 'low';
  evidence: Array<{
    fact: string;
    sourceEventId: string;
    verified: boolean;
  }>;
  possible_attack_techniques: Array<{
    id: string;
    name: string;
    tactic: string;
    rationale: string;
  }>;
  confidence: number;
  recommended_actions: Array<{
    step: string;
    urgency: 'immediate' | 'high' | 'routine';
    targetAssetOrIp?: string;
  }>;
  limitations: string[];
}
