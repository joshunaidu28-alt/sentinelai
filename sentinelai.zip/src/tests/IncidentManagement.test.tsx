import React from 'react';
import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { IncidentManagement } from '../pages/IncidentManagement.tsx';
import { SecurityIncident } from '../types/index.ts';

const mockIncidents: SecurityIncident[] = [
  {
    id: 'inc-001',
    incidentNumber: 'INC-2026-0842',
    title: 'Adversary Lateral Movement on DC-01',
    status: 'INVESTIGATING',
    priority: 'P1_CRITICAL',
    leadInvestigator: 'usr-admin-01',
    leadInvestigatorName: 'Alex Vance',
    createdAt: '2026-11-05T12:00:00Z',
    updatedAt: '2026-11-05T13:30:00Z',
    summary: 'Kerberos brute-force followed by unusual SMB named pipe creation on Domain Controller.',
    mitreTechniques: ['T1110', 'T1021.002'],
    affectedAssets: ['ast-001'],
    alertIds: ['alt-001'],
    evidenceIds: ['ev-01'],
    timeline: [
      {
        id: 'tl-1',
        timestamp: '2026-11-05T12:00:00Z',
        stage: 'DETECTED',
        author: 'System',
        description: 'Auto escalated from SIEM alert',
      },
    ],
    notes: [
      {
        id: 'n-1',
        author: 'Alex Vance',
        timestamp: '2026-11-05T12:30:00Z',
        content: 'Host isolated from general workstation VLAN.',
      },
    ],
  },
  {
    id: 'inc-002',
    incidentNumber: 'INC-2026-0843',
    title: 'Executive Phishing Credential Harvest Campaign',
    status: 'CONTAINMENT_REVIEW',
    priority: 'P2_HIGH',
    leadInvestigator: 'usr-sec-02',
    leadInvestigatorName: 'Sarah Chen',
    createdAt: '2026-11-05T10:00:00Z',
    updatedAt: '2026-11-05T11:15:00Z',
    summary: 'Spear-phishing email targeting CFO with typo-squatted wire transfer URL.',
    mitreTechniques: ['T1566.002'],
    affectedAssets: ['ast-004'],
    alertIds: ['alt-002'],
    evidenceIds: ['ev-02'],
    timeline: [],
    notes: [],
  },
  {
    id: 'inc-003',
    incidentNumber: 'INC-2026-0844',
    title: 'Cloud Storage Bucket Data Spill',
    status: 'RESOLVED',
    priority: 'P3_MEDIUM',
    leadInvestigator: 'usr-sec-02',
    leadInvestigatorName: 'Sarah Chen',
    createdAt: '2026-11-05T08:00:00Z',
    updatedAt: '2026-11-05T09:30:00Z',
    summary: 'Public read ACL remediated on analytics bucket.',
    mitreTechniques: ['T1530'],
    affectedAssets: ['ast-003'],
    alertIds: [],
    evidenceIds: [],
    timeline: [],
    notes: [],
  },
];

describe('IncidentManagement Component - Rendering Verification', () => {
  it('renders header, description, and New Incident CTA', () => {
    render(
      <IncidentManagement
        incidents={mockIncidents}
        onSelectIncident={vi.fn()}
        onCreateIncident={vi.fn()}
        onUpdateIncidentStatus={vi.fn()}
      />
    );

    expect(screen.getByText('Incident Management')).toBeInTheDocument();
    expect(
      screen.getByText(
        'End-to-end incident response lifecycle, containment coordination, and forensic timeline'
      )
    ).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /New Incident/i })).toBeInTheDocument();
  });

  it('renders all lifecycle stages with stage order labels', () => {
    render(
      <IncidentManagement
        incidents={mockIncidents}
        onSelectIncident={vi.fn()}
        onCreateIncident={vi.fn()}
        onUpdateIncidentStatus={vi.fn()}
      />
    );

    expect(screen.getByText('STAGE 01')).toBeInTheDocument();
    expect(screen.getByText('STAGE 02')).toBeInTheDocument();
    expect(screen.getByText('STAGE 03')).toBeInTheDocument();
    expect(screen.getByText('STAGE 04')).toBeInTheDocument();
    expect(screen.getByText('STAGE 05')).toBeInTheDocument();
    expect(screen.getByText('STAGE 06')).toBeInTheDocument();

    expect(screen.getAllByText('DETECTED').length).toBeGreaterThan(0);
    expect(screen.getAllByText('TRIAGED').length).toBeGreaterThan(0);
    expect(screen.getAllByText('INVESTIGATING').length).toBeGreaterThan(0);
    expect(screen.getAllByText('CONTAINMENT REVIEW').length).toBeGreaterThan(0);
    expect(screen.getAllByText('RECOVERY').length).toBeGreaterThan(0);
    expect(screen.getAllByText('RESOLVED').length).toBeGreaterThan(0);
  });

  it('renders incident cards with priority badges, summaries, MITRE tags, and lead analysts', () => {
    render(
      <IncidentManagement
        incidents={mockIncidents}
        onSelectIncident={vi.fn()}
        onCreateIncident={vi.fn()}
        onUpdateIncidentStatus={vi.fn()}
      />
    );

    // Card 1
    expect(screen.getByText('INC-2026-0842')).toBeInTheDocument();
    expect(screen.getByText('Adversary Lateral Movement on DC-01')).toBeInTheDocument();
    expect(screen.getByText('P1 CRITICAL')).toBeInTheDocument();
    expect(screen.getByText(/Lead: Alex Vance/i)).toBeInTheDocument();
    expect(screen.getByText(/MITRE: T1110, T1021.002/i)).toBeInTheDocument();

    // Card 2
    expect(screen.getByText('INC-2026-0843')).toBeInTheDocument();
    expect(screen.getByText('Executive Phishing Credential Harvest Campaign')).toBeInTheDocument();
    expect(screen.getByText('P2 HIGH')).toBeInTheDocument();
    expect(screen.getAllByText(/Lead: Sarah Chen/i).length).toBeGreaterThan(0);

    // Card 3
    expect(screen.getByText('INC-2026-0844')).toBeInTheDocument();
    expect(screen.getByText('Cloud Storage Bucket Data Spill')).toBeInTheDocument();
  });
});

describe('IncidentManagement Component - Status State Transitions', () => {
  it('triggers onUpdateIncidentStatus when changing stage to CONTAINMENT_REVIEW', async () => {
    const onUpdateIncidentStatus = vi.fn().mockResolvedValue(undefined);
    const user = userEvent.setup();

    render(
      <IncidentManagement
        incidents={mockIncidents}
        onSelectIncident={vi.fn()}
        onCreateIncident={vi.fn()}
        onUpdateIncidentStatus={onUpdateIncidentStatus}
      />
    );

    const stageSelects = screen.getAllByRole('combobox');
    await user.selectOptions(stageSelects[0], 'CONTAINMENT_REVIEW');

    expect(onUpdateIncidentStatus).toHaveBeenCalledTimes(1);
    expect(onUpdateIncidentStatus).toHaveBeenCalledWith('inc-001', 'CONTAINMENT_REVIEW');
  });

  it('triggers onUpdateIncidentStatus when changing stage to RESOLVED', async () => {
    const onUpdateIncidentStatus = vi.fn().mockResolvedValue(undefined);
    const user = userEvent.setup();

    render(
      <IncidentManagement
        incidents={mockIncidents}
        onSelectIncident={vi.fn()}
        onCreateIncident={vi.fn()}
        onUpdateIncidentStatus={onUpdateIncidentStatus}
      />
    );

    const stageSelects = screen.getAllByRole('combobox');
    await user.selectOptions(stageSelects[1], 'RESOLVED');

    expect(onUpdateIncidentStatus).toHaveBeenCalledTimes(1);
    expect(onUpdateIncidentStatus).toHaveBeenCalledWith('inc-002', 'RESOLVED');
  });

  it('renders all six lifecycle transition options in stage select dropdown', () => {
    render(
      <IncidentManagement
        incidents={mockIncidents}
        onSelectIncident={vi.fn()}
        onCreateIncident={vi.fn()}
        onUpdateIncidentStatus={vi.fn()}
      />
    );

    const stageSelects = screen.getAllByRole('combobox');
    const options = Array.from(stageSelects[0].querySelectorAll('option')).map((o) => o.value);

    expect(options).toEqual([
      'DETECTED',
      'TRIAGED',
      'INVESTIGATING',
      'CONTAINMENT_REVIEW',
      'RECOVERY',
      'RESOLVED',
    ]);
  });
});

describe('IncidentManagement Component - Interaction Testing', () => {
  it('opens Declare Incident modal, cancels, and confirms closure', async () => {
    const user = userEvent.setup();
    render(
      <IncidentManagement
        incidents={mockIncidents}
        onSelectIncident={vi.fn()}
        onCreateIncident={vi.fn()}
        onUpdateIncidentStatus={vi.fn()}
      />
    );

    // Open modal
    await user.click(screen.getByRole('button', { name: /New Incident/i }));
    expect(screen.getByText('Declare Security Incident')).toBeInTheDocument();

    // Cancel modal
    await user.click(screen.getByRole('button', { name: /Cancel/i }));
    expect(screen.queryByText('Declare Security Incident')).not.toBeInTheDocument();
  });

  it('submits new incident form with validated priority and text fields', async () => {
    const onCreateIncident = vi.fn().mockResolvedValue(undefined);
    const user = userEvent.setup();

    render(
      <IncidentManagement
        incidents={mockIncidents}
        onSelectIncident={vi.fn()}
        onCreateIncident={onCreateIncident}
        onUpdateIncidentStatus={vi.fn()}
      />
    );

    await user.click(screen.getByRole('button', { name: /New Incident/i }));

    const titleInput = screen.getByLabelText(/Incident Title/i);
    const prioritySelect = screen.getByLabelText(/Priority/i);
    const summaryInput = screen.getByLabelText(/Executive Summary/i);

    await user.type(titleInput, 'Ransomware Canary Triggered on File Server');
    await user.selectOptions(prioritySelect, 'P1_CRITICAL');
    await user.type(summaryInput, 'Multiple .lockbit extensions detected on backup volume.');

    await user.click(screen.getByRole('button', { name: /Declare Incident/i }));

    expect(onCreateIncident).toHaveBeenCalledTimes(1);
    expect(onCreateIncident).toHaveBeenCalledWith({
      title: 'Ransomware Canary Triggered on File Server',
      priority: 'P1_CRITICAL',
      summary: 'Multiple .lockbit extensions detected on backup volume.',
    });
    // Modal automatically closes after submit
    expect(screen.queryByText('Declare Security Incident')).not.toBeInTheDocument();
  });

  it('triggers onSelectIncident when clicking Timeline & Notes button', async () => {
    const onSelectIncident = vi.fn();
    const user = userEvent.setup();

    render(
      <IncidentManagement
        incidents={mockIncidents}
        onSelectIncident={onSelectIncident}
        onCreateIncident={vi.fn()}
        onUpdateIncidentStatus={vi.fn()}
      />
    );

    const timelineBtns = screen.getAllByRole('button', { name: /Timeline & Notes/i });
    await user.click(timelineBtns[0]);

    expect(onSelectIncident).toHaveBeenCalledTimes(1);
    expect(onSelectIncident).toHaveBeenCalledWith(mockIncidents[0]);
  });

  it('triggers onSelectIncident when clicking anywhere on the incident card', async () => {
    const onSelectIncident = vi.fn();
    const user = userEvent.setup();

    render(
      <IncidentManagement
        incidents={mockIncidents}
        onSelectIncident={onSelectIncident}
        onCreateIncident={vi.fn()}
        onUpdateIncidentStatus={vi.fn()}
      />
    );

    const incidentTitle = screen.getByText('Adversary Lateral Movement on DC-01');
    await user.click(incidentTitle);

    expect(onSelectIncident).toHaveBeenCalledTimes(1);
    expect(onSelectIncident).toHaveBeenCalledWith(mockIncidents[0]);
  });

  it('stops event propagation when interacting with stage dropdown on card', async () => {
    const onSelectIncident = vi.fn();
    const onUpdateIncidentStatus = vi.fn().mockResolvedValue(undefined);
    const user = userEvent.setup();

    render(
      <IncidentManagement
        incidents={mockIncidents}
        onSelectIncident={onSelectIncident}
        onCreateIncident={vi.fn()}
        onUpdateIncidentStatus={onUpdateIncidentStatus}
      />
    );

    const stageSelects = screen.getAllByRole('combobox');
    await user.selectOptions(stageSelects[0], 'TRIAGED');

    expect(onUpdateIncidentStatus).toHaveBeenCalledTimes(1);
    // Clicking the select shouldn't also select the entire card
    expect(onSelectIncident).not.toHaveBeenCalled();
  });
});
