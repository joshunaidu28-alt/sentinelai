import { describe, it, expect } from 'vitest';
import {
  SecurityLogSchema,
  SecurityAlertSchema,
  SecurityIncidentSchema,
  UserSchema,
  DashboardSummarySchema,
  validateApiResponse,
  LogsResponseSchema,
} from '../schemas/apiSchemas.ts';

describe('Zod API Response Schemas', () => {
  it('validates a conformant SecurityLog item', () => {
    const rawLog = {
      id: 'log-101',
      timestamp: '2026-11-05T10:00:00Z',
      source: 'FIREWALL',
      eventType: 'PORT_SCAN',
      severity: 'HIGH',
      sourceIp: '198.51.100.4',
      destinationIp: '10.0.1.1',
      message: 'Inbound SYN sweep detected',
      payload: { ports: [22, 80, 443] },
      processed: true,
    };

    const parsed = SecurityLogSchema.parse(rawLog);
    expect(parsed.id).toBe('log-101');
    expect(parsed.severity).toBe('HIGH');
    expect(parsed.source).toBe('FIREWALL');
  });

  it('rejects an invalid severity in SecurityLogSchema', () => {
    const badLog = {
      id: 'log-102',
      timestamp: '2026-11-05T10:00:00Z',
      source: 'FIREWALL',
      eventType: 'PORT_SCAN',
      severity: 'SUPER_FATAL', // invalid severity
      message: 'Invalid severity test',
    };

    const result = SecurityLogSchema.safeParse(badLog);
    expect(result.success).toBe(false);
  });

  it('validates a full SecurityAlert item with evidence and notes', () => {
    const rawAlert = {
      id: 'alt-55',
      title: 'SQL Injection detected in API endpoint',
      timestamp: '2026-11-05T11:00:00Z',
      severity: 'CRITICAL',
      status: 'NEW',
      riskScore: 88,
      source: 'WAF',
      sourceIp: '203.0.113.19',
      detectionReason: 'Matched regex for UNION SELECT query injection.',
      confidence: 95,
      evidence: [
        {
          type: 'HTTP_PAYLOAD',
          description: 'SQL injection string in search parameter',
          value: "' OR 1=1 --",
        },
      ],
      notes: [
        {
          id: 'note-1',
          author: 'Alex Vance',
          timestamp: '2026-11-05T11:05:00Z',
          text: 'Verified malicious payload.',
        },
      ],
    };

    const parsed = SecurityAlertSchema.parse(rawAlert);
    expect(parsed.id).toBe('alt-55');
    expect(parsed.riskScore).toBe(88);
    expect(parsed.evidence.length).toBe(1);
  });

  it('validates a SecurityIncident and its timeline', () => {
    const rawIncident = {
      id: 'inc-99',
      incidentNumber: 'INC-2026-0899',
      title: 'Perimeter Breach Attempt',
      status: 'TRIAGED',
      priority: 'P1_CRITICAL',
      leadInvestigator: 'usr-1',
      leadInvestigatorName: 'Alex Vance',
      createdAt: '2026-11-05T09:00:00Z',
      updatedAt: '2026-11-05T09:30:00Z',
      summary: 'Automated perimeter alert escalated after correlation.',
      mitreTechniques: ['T1190'],
      affectedAssets: ['ast-001'],
      alertIds: ['alt-55'],
      evidenceIds: [],
      timeline: [
        {
          id: 'tl-1',
          timestamp: '2026-11-05T09:00:00Z',
          stage: 'DETECTED',
          author: 'SIEM',
          description: 'Detected via WAF log',
        },
      ],
      notes: [],
    };

    const parsed = SecurityIncidentSchema.parse(rawIncident);
    expect(parsed.incidentNumber).toBe('INC-2026-0899');
    expect(parsed.timeline[0].stage).toBe('DETECTED');
  });

  it('validates DashboardSummarySchema with SOC metrics', () => {
    const rawSummary = {
      metrics: {
        totalEvents: 14820,
        totalAlerts: 42,
        criticalAlerts: 5,
        highRiskAlerts: 12,
        openIncidents: 4,
        resolvedIncidents: 19,
        threatIndicatorsCount: 64,
        monitoredAssetsCount: 8,
        vulnerabilitiesDetected: 14,
        automationExecutions: 28,
      },
      topSuspiciousIps: [
        { ip: '185.220.101.5', attempts: 142, threatLevel: 'CRITICAL', geo: 'Netherlands' },
      ],
    };

    const parsed = DashboardSummarySchema.parse(rawSummary);
    expect(parsed.metrics.totalEvents).toBe(14820);
    expect(parsed.metrics.criticalAlerts).toBe(5);
    expect(parsed.topSuspiciousIps.length).toBe(1);
  });

  it('validates UserSchema role validation', () => {
    const validUser = {
      id: 'usr-10',
      name: 'Sarah Chen',
      email: 'sarah.chen@sentinelai.internal',
      role: 'SECURITY_ANALYST',
      status: 'ACTIVE',
      mfaEnabled: true,
      lastLogin: '2026-11-05T12:00:00Z',
      organizationId: 'org-enterprise',
    };

    expect(UserSchema.parse(validUser).role).toBe('SECURITY_ANALYST');

    const invalidUser = { ...validUser, role: 'SUPER_HACKER' };
    expect(UserSchema.safeParse(invalidUser).success).toBe(false);
  });

  it('validateApiResponse gracefully returns fallback when payload fails validation', () => {
    const corruptedPayload = { invalidKey: 'unrecognized schema structure' };
    const fallback = { logs: [] };

    const result = validateApiResponse(
      LogsResponseSchema,
      corruptedPayload,
      fallback,
      'CorruptedLogsTest'
    );

    expect(result).toEqual(fallback);
  });
});
