import React from 'react';
import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { AlertManagement } from '../pages/ThreatDetection.tsx';
import { SecurityAlert } from '../types/index.ts';

const mockAlerts: SecurityAlert[] = [
  {
    id: 'alt-001',
    title: 'Kerberos Pre-Authentication Failure Burst',
    timestamp: '2026-11-05T14:20:00Z',
    severity: 'CRITICAL',
    status: 'OPEN',
    riskScore: 94,
    source: 'AUTH_SERVER',
    sourceIp: '185.220.101.45',
    destinationIp: '10.0.1.15',
    ruleName: 'Brute Force Authentication Burst (Rule 101)',
    mitreTechnique: 'T1110',
    detectionReason: '28 failed Kerberos authentication requests within 60s targeting svc_backup.',
    confidence: 96,
    assignedToName: 'Sarah Chen',
    evidence: [{ type: 'IOC_IP', description: 'Tor exit relay', value: '185.220.101.45' }],
    notes: [],
  },
  {
    id: 'alt-002',
    title: 'PowerShell Child Process Spawned from Excel',
    timestamp: '2026-11-05T14:15:00Z',
    severity: 'HIGH',
    status: 'INVESTIGATING',
    riskScore: 78,
    source: 'EDR_AGENT',
    sourceIp: '10.0.8.42',
    destinationIp: '198.51.100.22',
    ruleName: 'Suspicious Office Child Process (Rule 204)',
    mitreTechnique: 'T1059.001',
    detectionReason: 'winword.exe executed powershell.exe -EncodedCommand',
    confidence: 89,
    assignedToName: 'Alex Vance',
    evidence: [{ type: 'PROCESS_TREE', description: 'Malicious macro spawn', value: 'powershell.exe' }],
    notes: [],
  },
  {
    id: 'alt-003',
    title: 'Port Scan from Internal Host',
    timestamp: '2026-11-05T14:00:00Z',
    severity: 'MEDIUM',
    status: 'RESOLVED',
    riskScore: 45,
    source: 'FIREWALL',
    sourceIp: '10.0.9.11',
    destinationIp: '10.0.1.0/24',
    ruleName: 'High Velocity Port Sweep (Rule 302)',
    mitreTechnique: 'T1046',
    detectionReason: 'Sequential SYN sweep across 100 ports',
    confidence: 75,
    assignedToName: 'Sarah Chen',
    evidence: [],
    notes: [],
  },
  {
    id: 'alt-004',
    title: 'SQL Injection Blocked at Perimeter WAF',
    timestamp: '2026-11-05T13:45:00Z',
    severity: 'CRITICAL',
    status: 'ESCALATED',
    riskScore: 91,
    source: 'WAF',
    sourceIp: '203.0.113.88',
    destinationIp: '10.0.2.5',
    ruleName: 'OWASP SQL Injection Signature Match (Rule 401)',
    mitreTechnique: 'T1190',
    detectionReason: 'UNION SELECT statement detected in query parameters',
    confidence: 94,
    assignedToName: 'Alex Vance',
    evidence: [],
    notes: [],
  },
];

describe('AlertManagement Component - Rendering Verification', () => {
  it('renders header, description, and total alert counter', () => {
    render(
      <AlertManagement
        alerts={mockAlerts}
        onSelectAlert={vi.fn()}
        onUpdateAlertStatus={vi.fn()}
        onEscalateAlert={vi.fn()}
      />
    );

    expect(screen.getByText('Alert Management')).toBeInTheDocument();
    expect(
      screen.getByText('Triage, investigate, assign, and escalate security detection alerts')
    ).toBeInTheDocument();
    expect(screen.getByText(/Showing 4 of 4 alerts/i)).toBeInTheDocument();
  });

  it('renders table columns correctly', () => {
    render(
      <AlertManagement
        alerts={mockAlerts}
        onSelectAlert={vi.fn()}
        onUpdateAlertStatus={vi.fn()}
        onEscalateAlert={vi.fn()}
      />
    );

    expect(screen.getByRole('columnheader', { name: 'Alert ID' })).toBeInTheDocument();
    expect(screen.getByRole('columnheader', { name: 'Severity' })).toBeInTheDocument();
    expect(screen.getByRole('columnheader', { name: 'Risk' })).toBeInTheDocument();
    expect(screen.getByRole('columnheader', { name: 'Alert Title & Reason' })).toBeInTheDocument();
    expect(screen.getByRole('columnheader', { name: 'Source IP' })).toBeInTheDocument();
    expect(screen.getByRole('columnheader', { name: 'Assigned To' })).toBeInTheDocument();
    expect(screen.getByRole('columnheader', { name: 'Status' })).toBeInTheDocument();
    expect(screen.getByRole('columnheader', { name: 'Actions' })).toBeInTheDocument();
  });

  it('renders alert rows with corresponding data, risk scores, and assigned analysts', () => {
    render(
      <AlertManagement
        alerts={mockAlerts}
        onSelectAlert={vi.fn()}
        onUpdateAlertStatus={vi.fn()}
        onEscalateAlert={vi.fn()}
      />
    );

    expect(screen.getByText('alt-001')).toBeInTheDocument();
    expect(screen.getByText('Kerberos Pre-Authentication Failure Burst')).toBeInTheDocument();
    expect(screen.getByText('94/100')).toBeInTheDocument();
    expect(screen.getByText('185.220.101.45')).toBeInTheDocument();

    expect(screen.getByText('alt-002')).toBeInTheDocument();
    expect(screen.getByText('PowerShell Child Process Spawned from Excel')).toBeInTheDocument();
    expect(screen.getByText('78/100')).toBeInTheDocument();

    expect(screen.getByText('alt-003')).toBeInTheDocument();
    expect(screen.getByText('Port Scan from Internal Host')).toBeInTheDocument();
    expect(screen.getByText('45/100')).toBeInTheDocument();

    expect(screen.getByText('alt-004')).toBeInTheDocument();
    expect(screen.getByText('SQL Injection Blocked at Perimeter WAF')).toBeInTheDocument();
    expect(screen.getByText('91/100')).toBeInTheDocument();
  });
});

describe('AlertManagement Component - Status State Transitions', () => {
  it('filters alerts by Severity transition', async () => {
    const user = userEvent.setup();
    render(
      <AlertManagement
        alerts={mockAlerts}
        onSelectAlert={vi.fn()}
        onUpdateAlertStatus={vi.fn()}
        onEscalateAlert={vi.fn()}
      />
    );

    const severitySelect = screen.getByLabelText('Severity');

    // Filter to CRITICAL
    await user.selectOptions(severitySelect, 'CRITICAL');
    expect(screen.getByText(/Showing 2 of 4 alerts/i)).toBeInTheDocument();
    expect(screen.getByText('alt-001')).toBeInTheDocument();
    expect(screen.getByText('alt-004')).toBeInTheDocument();
    expect(screen.queryByText('alt-002')).not.toBeInTheDocument();
    expect(screen.queryByText('alt-003')).not.toBeInTheDocument();

    // Filter to HIGH
    await user.selectOptions(severitySelect, 'HIGH');
    expect(screen.getByText(/Showing 1 of 4 alerts/i)).toBeInTheDocument();
    expect(screen.getByText('alt-002')).toBeInTheDocument();
    expect(screen.queryByText('alt-001')).not.toBeInTheDocument();

    // Filter to MEDIUM
    await user.selectOptions(severitySelect, 'MEDIUM');
    expect(screen.getByText(/Showing 1 of 4 alerts/i)).toBeInTheDocument();
    expect(screen.getByText('alt-003')).toBeInTheDocument();

    // Reset to ALL
    await user.selectOptions(severitySelect, 'ALL');
    expect(screen.getByText(/Showing 4 of 4 alerts/i)).toBeInTheDocument();
  });

  it('filters alerts by Status transition', async () => {
    const user = userEvent.setup();
    render(
      <AlertManagement
        alerts={mockAlerts}
        onSelectAlert={vi.fn()}
        onUpdateAlertStatus={vi.fn()}
        onEscalateAlert={vi.fn()}
      />
    );

    const statusSelect = screen.getByLabelText('Status');

    // Filter to OPEN
    await user.selectOptions(statusSelect, 'OPEN');
    expect(screen.getByText(/Showing 1 of 4 alerts/i)).toBeInTheDocument();
    expect(screen.getByText('alt-001')).toBeInTheDocument();

    // Filter to INVESTIGATING
    await user.selectOptions(statusSelect, 'INVESTIGATING');
    expect(screen.getByText(/Showing 1 of 4 alerts/i)).toBeInTheDocument();
    expect(screen.getByText('alt-002')).toBeInTheDocument();

    // Filter to RESOLVED
    await user.selectOptions(statusSelect, 'RESOLVED');
    expect(screen.getByText(/Showing 1 of 4 alerts/i)).toBeInTheDocument();
    expect(screen.getByText('alt-003')).toBeInTheDocument();

    // Filter to ESCALATED
    await user.selectOptions(statusSelect, 'ESCALATED');
    expect(screen.getByText(/Showing 1 of 4 alerts/i)).toBeInTheDocument();
    expect(screen.getByText('alt-004')).toBeInTheDocument();
  });

  it('hides Escalate button for already ESCALATED or RESOLVED alerts', () => {
    render(
      <AlertManagement
        alerts={mockAlerts}
        onSelectAlert={vi.fn()}
        onUpdateAlertStatus={vi.fn()}
        onEscalateAlert={vi.fn()}
      />
    );

    // mockAlerts has:
    // alt-001: OPEN (can escalate)
    // alt-002: INVESTIGATING (can escalate)
    // alt-003: RESOLVED (cannot escalate)
    // alt-004: ESCALATED (cannot escalate)
    // Therefore exactly 2 Escalate buttons should be rendered
    const escalateButtons = screen.getAllByRole('button', { name: /Escalate/i });
    expect(escalateButtons).toHaveLength(2);

    // Every alert has an Investigate button
    const investigateButtons = screen.getAllByRole('button', { name: /Investigate/i });
    expect(investigateButtons).toHaveLength(4);
  });
});

describe('AlertManagement Component - Interaction Testing', () => {
  it('searches alerts by keyword across title, detection reason, and IP', async () => {
    const user = userEvent.setup();
    render(
      <AlertManagement
        alerts={mockAlerts}
        onSelectAlert={vi.fn()}
        onUpdateAlertStatus={vi.fn()}
        onEscalateAlert={vi.fn()}
      />
    );

    const searchInput = screen.getByPlaceholderText(/Search by title, IP, or rule/i);

    // Search by IP
    await user.type(searchInput, '203.0.113.88');
    expect(screen.getByText(/Showing 1 of 4 alerts/i)).toBeInTheDocument();
    expect(screen.getByText('alt-004')).toBeInTheDocument();

    // Clear and search by keyword in detection reason
    await user.clear(searchInput);
    await user.type(searchInput, 'winword.exe');
    expect(screen.getByText(/Showing 1 of 4 alerts/i)).toBeInTheDocument();
    expect(screen.getByText('alt-002')).toBeInTheDocument();
  });

  it('displays empty state when search filters yield no results', async () => {
    const user = userEvent.setup();
    render(
      <AlertManagement
        alerts={mockAlerts}
        onSelectAlert={vi.fn()}
        onUpdateAlertStatus={vi.fn()}
        onEscalateAlert={vi.fn()}
      />
    );

    const searchInput = screen.getByPlaceholderText(/Search by title, IP, or rule/i);
    await user.type(searchInput, 'zero_day_unmatched_string');

    expect(screen.getByText(/No alerts found matching current filters/i)).toBeInTheDocument();
    expect(screen.getByText(/Showing 0 of 4 alerts/i)).toBeInTheDocument();
  });

  it('triggers onSelectAlert when an alert row is clicked', async () => {
    const onSelectAlert = vi.fn();
    const user = userEvent.setup();

    render(
      <AlertManagement
        alerts={mockAlerts}
        onSelectAlert={onSelectAlert}
        onUpdateAlertStatus={vi.fn()}
        onEscalateAlert={vi.fn()}
      />
    );

    // Click the row containing alt-001
    const alertTitle = screen.getByText('Kerberos Pre-Authentication Failure Burst');
    await user.click(alertTitle);

    expect(onSelectAlert).toHaveBeenCalledTimes(1);
    expect(onSelectAlert).toHaveBeenCalledWith(mockAlerts[0]);
  });

  it('triggers onEscalateAlert when Escalate button is clicked and stops row event propagation', async () => {
    const onSelectAlert = vi.fn();
    const onEscalateAlert = vi.fn().mockResolvedValue(undefined);
    const user = userEvent.setup();

    render(
      <AlertManagement
        alerts={mockAlerts}
        onSelectAlert={onSelectAlert}
        onUpdateAlertStatus={vi.fn()}
        onEscalateAlert={onEscalateAlert}
      />
    );

    const escalateButtons = screen.getAllByRole('button', { name: /Escalate/i });
    await user.click(escalateButtons[0]);

    expect(onEscalateAlert).toHaveBeenCalledTimes(1);
    expect(onEscalateAlert).toHaveBeenCalledWith('alt-001');
    // Verify stopPropagation prevented onSelectAlert from being triggered
    expect(onSelectAlert).not.toHaveBeenCalled();
  });

  it('triggers onSelectAlert when Investigate button is clicked', async () => {
    const onSelectAlert = vi.fn();
    const user = userEvent.setup();

    render(
      <AlertManagement
        alerts={mockAlerts}
        onSelectAlert={onSelectAlert}
        onUpdateAlertStatus={vi.fn()}
        onEscalateAlert={vi.fn()}
      />
    );

    const investigateButtons = screen.getAllByRole('button', { name: /Investigate/i });
    await user.click(investigateButtons[1]); // alt-002

    expect(onSelectAlert).toHaveBeenCalledTimes(1);
    expect(onSelectAlert).toHaveBeenCalledWith(mockAlerts[1]);
  });
});
