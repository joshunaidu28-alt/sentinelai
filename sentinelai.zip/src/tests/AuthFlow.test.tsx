import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { AuthModal } from '../components/auth/AuthModal.tsx';

describe('AuthModal Component & Flows', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('renders sign in modal with email and password inputs', () => {
    render(
      <AuthModal
        isOpen={true}
        onClose={vi.fn()}
        onAuthSuccess={vi.fn()}
      />
    );

    expect(screen.getByText('SentinelAI Security Operations')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Sign In' })).toBeInTheDocument();
    expect(screen.getByPlaceholderText('analyst@sentinelai.internal')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('••••••••••••')).toBeInTheDocument();
  });

  it('fills email and password when clicking 1-Click Demo Profile', async () => {
    const user = userEvent.setup();
    render(
      <AuthModal
        isOpen={true}
        onClose={vi.fn()}
        onAuthSuccess={vi.fn()}
      />
    );

    const adminBtn = screen.getByRole('button', { name: /Alex Vance \(Admin\)/i });
    await user.click(adminBtn);

    const emailInput = screen.getByPlaceholderText('analyst@sentinelai.internal') as HTMLInputElement;
    const passwordInput = screen.getByPlaceholderText('••••••••••••') as HTMLInputElement;

    expect(emailInput.value).toBe('alex.vance@sentinelai.internal');
    expect(passwordInput.value).toBe('Sentinel2026!');
  });

  it('switches to Register tab and renders name and role selector', async () => {
    const user = userEvent.setup();
    render(
      <AuthModal
        isOpen={true}
        onClose={vi.fn()}
        onAuthSuccess={vi.fn()}
      />
    );

    const registerTab = screen.getByRole('button', { name: 'Register' });
    await user.click(registerTab);

    expect(screen.getByPlaceholderText('Jordan Mitchell, CISSP')).toBeInTheDocument();
    expect(screen.getByText(/Initial Assigned Role \(RBAC\)/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Complete Registration/i })).toBeInTheDocument();
  });

  it('switches to Reset Key tab', async () => {
    const user = userEvent.setup();
    render(
      <AuthModal
        isOpen={true}
        onClose={vi.fn()}
        onAuthSuccess={vi.fn()}
      />
    );

    const resetTab = screen.getByRole('button', { name: 'Reset Key' });
    await user.click(resetTab);

    expect(screen.getByText(/Enter your authorized enterprise email address/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Send Recovery Dispatch/i })).toBeInTheDocument();
  });

  it('authenticates successfully and calls onAuthSuccess and onClose', async () => {
    const onAuthSuccess = vi.fn();
    const onClose = vi.fn();
    const user = userEvent.setup();

    const mockUser = {
      id: 'usr-admin-01',
      name: 'Alex Vance',
      email: 'alex.vance@sentinelai.internal',
      role: 'ADMIN',
      status: 'ACTIVE',
      mfaEnabled: true,
      lastLogin: new Date().toISOString(),
      organizationId: 'org-enterprise',
    };

    global.fetch = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        user: mockUser,
        token: 'mock-jwt-token',
      }),
    } as any);

    render(
      <AuthModal
        isOpen={true}
        onClose={onClose}
        onAuthSuccess={onAuthSuccess}
      />
    );

    await user.click(screen.getByRole('button', { name: /Alex Vance \(Admin\)/i }));
    await user.click(screen.getByRole('button', { name: /Sign In to SOC/i }));

    await waitFor(() => {
      expect(onAuthSuccess).toHaveBeenCalledTimes(1);
      expect(onAuthSuccess).toHaveBeenCalledWith(mockUser, 'mock-jwt-token');
      expect(onClose).toHaveBeenCalledTimes(1);
    });
  });
});
