/**
 * SentinelAI - Zod Validation Schemas for Frontend API Response Integrity
 */

import { z } from 'zod';

export const SeveritySchema = z.enum(['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO']);

export const UserRoleSchema = z.enum(['ADMIN', 'SECURITY_ANALYST', 'SOC_MANAGER', 'VIEWER']);

export const AlertStatusSchema = z.enum([
  'NEW',
  'OPEN',
  'INVESTIGATING',
  'ESCALATED',
  'RESOLVED',
  'FALSE_POSITIVE',
]);

export const IncidentStatusSchema = z.enum([
  'DETECTED',
  'TRIAGED',
  'INVESTIGATING',
  'CONTAINMENT_REVIEW',
  'RECOVERY',
  'RESOLVED',
]);

export const IncidentPrioritySchema = z.enum(['P1_CRITICAL', 'P2_HIGH', 'P3_MEDIUM', 'P4_LOW']);

export const UserSchema = z.object({
  id: z.string(),
  name: z.string(),
  email: z.string().email().or(z.string()),
  role: UserRoleSchema,
  status: z.enum(['ACTIVE', 'SUSPENDED']).default('ACTIVE'),
  mfaEnabled: z.boolean().default(false),
  lastLogin: z.string(),
  avatarUrl: z.string().optional(),
  organizationId: z.string(),
});

export const SecurityLogSchema = z.object({
  id: z.string(),
  timestamp: z.string(),
  source: z.enum([
    'FIREWALL',
    'AUTH_SERVER',
    'EDR_AGENT',
    'CLOUD_TRAIL',
    'WAF',
    'NETWORK_TAP',
    'DNS_PROXY',
  ]),
  eventType: z.string(),
  severity: SeveritySchema,
  sourceIp: z.string().optional(),
  destinationIp: z.string().optional(),
  sourceGeo: z.string().optional(),
  message: z.string(),
  payload: z.record(z.string(), z.any()).default({}),
  processed: z.boolean().default(false),
  associatedAlertId: z.string().optional(),
});

export const AlertEvidenceSchema = z.object({
  type: z.string(),
  description: z.string(),
  value: z.string(),
});

export const AlertNoteSchema = z.object({
  id: z.string(),
  author: z.string(),
  timestamp: z.string(),
  text: z.string(),
});

export const SecurityAlertSchema = z.object({
  id: z.string(),
  title: z.string(),
  timestamp: z.string(),
  severity: SeveritySchema,
  status: AlertStatusSchema,
  riskScore: z.number().min(0).max(100),
  source: z.string(),
  sourceIp: z.string().optional(),
  destinationIp: z.string().optional(),
  detectionRuleId: z.string().optional(),
  ruleName: z.string().default('Unknown Rule'),
  mitreTechnique: z.string().optional(),
  mitreTactic: z.string().optional(),
  assignedTo: z.string().optional(),
  assignedToName: z.string().optional(),
  incidentId: z.string().optional(),
  evidence: z.array(AlertEvidenceSchema).default([]),
  detectionReason: z.string(),
  confidence: z.number().default(80),
  notes: z.array(AlertNoteSchema).default([]),
});

export const IncidentTimelineSchema = z.object({
  id: z.string(),
  timestamp: z.string(),
  stage: IncidentStatusSchema,
  author: z.string(),
  description: z.string(),
});

export const IncidentNoteSchema = z.object({
  id: z.string(),
  author: z.string(),
  timestamp: z.string(),
  content: z.string(),
});

export const SecurityIncidentSchema = z.object({
  id: z.string(),
  incidentNumber: z.string(),
  title: z.string(),
  status: IncidentStatusSchema,
  priority: IncidentPrioritySchema,
  leadInvestigator: z.string(),
  leadInvestigatorName: z.string(),
  createdAt: z.string(),
  updatedAt: z.string(),
  summary: z.string(),
  mitreTechniques: z.array(z.string()).default([]),
  affectedAssets: z.array(z.string()).default([]),
  alertIds: z.array(z.string()).default([]),
  evidenceIds: z.array(z.string()).default([]),
  timeline: z.array(IncidentTimelineSchema).default([]),
  notes: z.array(IncidentNoteSchema).default([]),
});

export const ThreatIndicatorSchema = z.object({
  id: z.string(),
  type: z.enum(['IPV4', 'DOMAIN', 'URL', 'FILE_HASH_SHA256', 'EMAIL']),
  value: z.string(),
  threatType: z.enum([
    'C2_SERVER',
    'RANSOMWARE_DISTRIBUTION',
    'PHISHING_HOST',
    'BOTNET_NODE',
    'EXPLOIT_DROPPER',
  ]),
  confidence: z.number(),
  firstSeen: z.string(),
  lastSeen: z.string(),
  source: z.string(),
  activeStatus: z.enum(['ACTIVE', 'REVOKED', 'UNDER_REVIEW']).default('ACTIVE'),
  enrichment: z
    .object({
      reputationScore: z.number(),
      maliciousVotes: z.number(),
      harmlessVotes: z.number(),
      country: z.string().optional(),
      autonomousSystem: z.string().optional(),
    })
    .optional(),
});

export const VulnerabilitySchema = z.object({
  id: z.string(),
  cveId: z.string(),
  title: z.string(),
  description: z.string(),
  cvssScore: z.number(),
  severity: SeveritySchema,
  assetId: z.string(),
  assetName: z.string(),
  status: z.enum(['OPEN', 'ACKNOWLEDGED', 'IN_PROGRESS', 'REMEDIATED', 'ACCEPTED_RISK']),
  remediationPlan: z.string(),
  discoveredAt: z.string(),
  scannedBy: z.enum(['NMAP_VULNERS', 'OWASP_ZAP', 'TRIVY_CONTAINER', 'MANUAL_AUDIT']),
});

export const MonitoredAssetSchema = z.object({
  id: z.string(),
  name: z.string(),
  type: z.enum(['SERVER', 'WORKSTATION', 'CLOUD_VM', 'DATABASE', 'FIREWALL', 'API_GATEWAY']),
  ipAddress: z.string(),
  hostname: z.string(),
  owner: z.string(),
  environment: z.enum(['PRODUCTION', 'STAGING', 'CORPORATE']),
  criticality: z.enum(['TIER_1_CRITICAL', 'TIER_2_HIGH', 'TIER_3_MEDIUM', 'TIER_4_LOW']),
  authorized: z.boolean(),
  lastMonitored: z.string(),
  activeAlertsCount: z.number().default(0),
  openVulnerabilitiesCount: z.number().default(0),
});

export const NetworkConnectionSchema = z.object({
  id: z.string(),
  timestamp: z.string(),
  sourceIp: z.string(),
  sourcePort: z.number(),
  destinationIp: z.string(),
  destinationPort: z.number(),
  protocol: z.enum(['TCP', 'UDP', 'ICMP', 'DNS', 'HTTPS', 'SSH']),
  bytesSent: z.number(),
  bytesReceived: z.number(),
  flags: z.string(),
  status: z.enum(['ALLOWED', 'BLOCKED', 'FLAGGED_ANOMALOUS']),
  anomalyReason: z.string().optional(),
});

export const NetworkStatsSchema = z.object({
  protocolDistribution: z
    .array(
      z.object({
        protocol: z.string(),
        percentage: z.number(),
        bytes: z.number(),
      })
    )
    .default([]),
  totalBandwidthMbps: z.number(),
  anomalousConnectionsCount: z.number().default(0),
  activeSensors: z.number().default(8),
  ingressThroughputMbps: z.number().optional(),
  egressThroughputMbps: z.number().optional(),
});

export const PhishingAnalysisSchema = z.object({
  id: z.string(),
  targetUrl: z.string().optional(),
  emailSubject: z.string().optional(),
  senderEmail: z.string().optional(),
  headers: z.string().optional(),
  riskScore: z.number(),
  classification: z.enum(['SAFE', 'SUSPICIOUS', 'MALICIOUS_PHISHING']),
  indicators: z.array(z.string()).default([]),
  domainReputation: z.object({
    domain: z.string(),
    ageDays: z.number(),
    registrar: z.string(),
    dnsValid: z.boolean(),
    spfPassed: z.boolean(),
    dkimPassed: z.boolean(),
    virusTotalScore: z.string(),
  }),
  evidence: z.array(z.string()).default([]),
  recommendedActions: z.array(z.string()).default([]),
  analyzedAt: z.string(),
});

export const PlaybookStepSchema = z.object({
  order: z.number(),
  name: z.string(),
  actionType: z.enum([
    'ENRICH_IOC',
    'CREATE_ALERT',
    'ISOLATE_HOST',
    'BLOCK_IP',
    'NOTIFY_TEAM',
    'CREATE_INCIDENT',
  ]),
  status: z.enum(['PENDING', 'EXECUTING', 'COMPLETED', 'WAITING_APPROVAL']),
});

export const PlaybookSchema = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string(),
  triggerEvent: z.string(),
  category: z.enum(['BRUTE_FORCE', 'PHISHING', 'VULNERABILITY', 'NETWORK_ANOMALY']),
  requiresApproval: z.boolean(),
  enabled: z.boolean(),
  steps: z.array(PlaybookStepSchema),
  executionCount: z.number().default(0),
});

export const AutomationRunSchema = z.object({
  id: z.string(),
  playbookId: z.string(),
  playbookName: z.string(),
  triggerPayload: z.string(),
  status: z.enum(['PENDING_APPROVAL', 'RUNNING', 'COMPLETED', 'REJECTED', 'FAILED']),
  startedAt: z.string(),
  completedAt: z.string().optional(),
  executedBy: z.string(),
  requiresApproval: z.boolean(),
  approvalDetails: z
    .object({
      approvedBy: z.string().optional(),
      approvedAt: z.string().optional(),
      reason: z.string().optional(),
    })
    .optional(),
  outputLogs: z.array(z.string()).default([]),
});

export const SecurityReportSchema = z.object({
  id: z.string(),
  title: z.string(),
  type: z.enum([
    'DAILY_SUMMARY',
    'WEEKLY_THREAT',
    'INCIDENT_INVESTIGATION',
    'VULNERABILITY_ASSESSMENT',
    'SOC_METRICS',
  ]),
  generatedAt: z.string(),
  generatedBy: z.string(),
  dateRange: z.string(),
  format: z.enum(['PDF', 'CSV', 'JSON']),
  summaryMetrics: z.record(z.string(), z.any()).default({}),
  findingsCount: z.number().default(0),
});

export const AuditLogEntrySchema = z.object({
  id: z.string(),
  timestamp: z.string(),
  userId: z.string(),
  userName: z.string(),
  action: z.string(),
  category: z.enum([
    'AUTH',
    'ALERT_MODIFIED',
    'INCIDENT_ACTION',
    'PLAYBOOK_EXECUTED',
    'SETTINGS_CHANGED',
    'REPORT_EXPORTED',
  ]),
  details: z.string(),
  ipAddress: z.string(),
  status: z.enum(['SUCCESS', 'FAILED', 'BLOCKED']),
});

export const IntegrationConfigSchema = z.object({
  id: z.string(),
  name: z.string(),
  provider: z.enum([
    'GEMINI_AI',
    'VIRUSTOTAL',
    'MITRE_ATTACK',
    'NMAP',
    'OWASP_ZAP',
    'REDIS',
    'N8N_WEBHOOK',
    'SMTP',
  ]),
  status: z.enum(['CONNECTED', 'DISCONNECTED', 'ERROR']),
  maskedApiKey: z.string().optional(),
  endpointUrl: z.string().optional(),
  lastSync: z.string().optional(),
  latencyMs: z.number().optional(),
  error: z.string().optional(),
  requiredFor: z.string(),
});

export const DashboardSummarySchema = z.object({
  metrics: z.object({
    totalEvents: z.number(),
    totalAlerts: z.number(),
    criticalAlerts: z.number(),
    highRiskAlerts: z.number(),
    openIncidents: z.number(),
    resolvedIncidents: z.number(),
    threatIndicatorsCount: z.number(),
    monitoredAssetsCount: z.number(),
    vulnerabilitiesDetected: z.number(),
    automationExecutions: z.number(),
  }),
  topSuspiciousIps: z
    .array(
      z.object({
        ip: z.string(),
        attempts: z.number(),
        threatLevel: z.string(),
        geo: z.string().optional(),
      })
    )
    .default([]),
});

export const DashboardTrendsSchema = z.object({
  eventsOverTime: z.array(
    z.object({
      time: z.string(),
      events: z.number(),
      anomalies: z.number(),
    })
  ),
  severityDistribution: z.array(
    z.object({
      name: z.string(),
      value: z.number(),
      color: z.string(),
    })
  ),
  threatClassification: z.array(
    z.object({
      category: z.string(),
      count: z.number(),
    })
  ),
  incidentStages: z
    .array(
      z.object({
        stage: z.string(),
        count: z.number(),
      })
    )
    .optional(),
});

// Response Wrappers
export const LogsResponseSchema = z.object({
  logs: z.array(SecurityLogSchema),
  total: z.number().optional(),
});

export const AlertsResponseSchema = z.object({
  alerts: z.array(SecurityAlertSchema),
  total: z.number().optional(),
});

export const IncidentsResponseSchema = z.object({
  incidents: z.array(SecurityIncidentSchema),
  total: z.number().optional(),
});

export const ThreatsResponseSchema = z.object({
  indicators: z.array(ThreatIndicatorSchema),
});

export const VulnerabilitiesResponseSchema = z.object({
  vulnerabilities: z.array(VulnerabilitySchema),
});

export const AssetsResponseSchema = z.object({
  assets: z.array(MonitoredAssetSchema),
});

export const NetworkEventsResponseSchema = z.object({
  connections: z.array(NetworkConnectionSchema),
});

export const PhishingHistoryResponseSchema = z.object({
  history: z.array(PhishingAnalysisSchema),
});

export const PlaybooksResponseSchema = z.object({
  playbooks: z.array(PlaybookSchema),
});

export const AutomationRunsResponseSchema = z.object({
  runs: z.array(AutomationRunSchema),
});

export const ReportsResponseSchema = z.object({
  reports: z.array(SecurityReportSchema),
});

export const UsersResponseSchema = z.object({
  users: z.array(UserSchema),
});

export const AuditLogsResponseSchema = z.object({
  auditLogs: z.array(AuditLogEntrySchema),
});

export const IntegrationsResponseSchema = z.object({
  integrations: z.array(IntegrationConfigSchema),
});

export const AuthResponseSchema = z.object({
  user: UserSchema,
  token: z.string().optional(),
  message: z.string().optional(),
});

/**
 * Utility helper to safely validate and parse API responses.
 * If validation fails, it logs a descriptive warning and returns the fallback.
 */
export function validateApiResponse<T>(
  schema: z.ZodType<T>,
  data: unknown,
  fallback: T,
  endpointName: string
): T {
  const result = schema.safeParse(data);
  if (!result.success) {
    console.warn(
      `[SentinelAI Zod Validation Notice] Schema mismatch on ${endpointName}:`,
      result.error.issues
    );
    return fallback;
  }
  return result.data;
}
