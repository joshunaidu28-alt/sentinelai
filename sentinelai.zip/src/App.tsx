/**
 * SentinelAI - AI-Powered Cybersecurity Operations & Automation Platform (SOC)
 */

import React, { useState, useEffect } from 'react';
import { Sidebar, NavItemKey } from './components/layout/Sidebar.tsx';
import { TopNav } from './components/layout/TopNav.tsx';
import { IngestLogModal } from './components/common/IngestLogModal.tsx';
import { AuthModal } from './components/auth/AuthModal.tsx';
import {
  LogDetailDrawer,
  AlertDetailDrawer,
  IncidentDetailDrawer,
} from './components/drawers/DetailDrawers.tsx';

import { OverviewDashboard } from './pages/OverviewDashboard.tsx';
import { SecurityMonitoring, SecurityLogs } from './pages/SecurityMonitoring.tsx';
import { ThreatDetection, AlertManagement } from './pages/ThreatDetection.tsx';
import { IncidentManagement } from './pages/IncidentManagement.tsx';
import { PhishingDetection } from './pages/PhishingDetection.tsx';
import { NetworkSecurity, VulnerabilityManagement } from './pages/NetworkSecurity.tsx';
import { ThreatIntelligence, AiInvestigation } from './pages/ThreatIntelligence.tsx';
import { AutomationCenter, PlaybookManagement } from './pages/AutomationCenter.tsx';
import { SecurityReports, AssetManagement } from './pages/SecurityReports.tsx';
import { UserManagement, AuditLogs } from './pages/UserManagement.tsx';
import {
  IntegrationSettings,
  AiConfiguration,
  SystemSettings,
} from './pages/IntegrationSettings.tsx';

import {
  UserRole,
  User,
  SecurityLog,
  SecurityAlert,
  SecurityIncident,
  ThreatIndicator,
  Vulnerability,
  MonitoredAsset,
  Playbook,
  AutomationRun,
  AuditLogEntry,
  IntegrationConfig,
  PhishingAnalysis,
  SecurityReport,
  NetworkConnection,
  AlertStatus,
  IncidentStatus,
} from './types/index.ts';

import {
  validateApiResponse,
  DashboardSummarySchema,
  DashboardTrendsSchema,
  LogsResponseSchema,
  AlertsResponseSchema,
  IncidentsResponseSchema,
  ThreatsResponseSchema,
  VulnerabilitiesResponseSchema,
  AssetsResponseSchema,
  NetworkEventsResponseSchema,
  NetworkStatsSchema,
  PhishingHistoryResponseSchema,
  PlaybooksResponseSchema,
  AutomationRunsResponseSchema,
  ReportsResponseSchema,
  UsersResponseSchema,
  AuditLogsResponseSchema,
  IntegrationsResponseSchema,
  AuthResponseSchema,
} from './schemas/apiSchemas.ts';

export default function App() {
  const [activeNav, setActiveNav] = useState<NavItemKey>('overview');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeRole, setActiveRole] = useState<UserRole>('ADMIN');
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Modals & Drawers
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isIngestModalOpen, setIsIngestModalOpen] = useState(false);
  const [selectedLog, setSelectedLog] = useState<SecurityLog | null>(null);
  const [selectedAlert, setSelectedAlert] = useState<SecurityAlert | null>(null);
  const [selectedIncident, setSelectedIncident] = useState<SecurityIncident | null>(null);

  // Application Data States
  const [summaryMetrics, setSummaryMetrics] = useState<any>(null);
  const [trendsData, setTrendsData] = useState<any>(null);
  const [logs, setLogs] = useState<SecurityLog[]>([]);
  const [alerts, setAlerts] = useState<SecurityAlert[]>([]);
  const [incidents, setIncidents] = useState<SecurityIncident[]>([]);
  const [threatIndicators, setThreatIndicators] = useState<ThreatIndicator[]>([]);
  const [vulnerabilities, setVulnerabilities] = useState<Vulnerability[]>([]);
  const [assets, setAssets] = useState<MonitoredAsset[]>([]);
  const [networkConnections, setNetworkConnections] = useState<NetworkConnection[]>([]);
  const [networkStats, setNetworkStats] = useState<any>(null);
  const [phishingHistory, setPhishingHistory] = useState<PhishingAnalysis[]>([]);
  const [playbooks, setPlaybooks] = useState<Playbook[]>([]);
  const [automationRuns, setAutomationRuns] = useState<AutomationRun[]>([]);
  const [reports, setReports] = useState<SecurityReport[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [auditLogsList, setAuditLogsList] = useState<AuditLogEntry[]>([]);
  const [integrations, setIntegrations] = useState<IntegrationConfig[]>([]);

  // Fetch all core SOC telemetry with strict Zod validation
  const loadAllData = async () => {
    setIsRefreshing(true);
    try {
      const [
        authRes,
        sumRes,
        trRes,
        logsRes,
        alertsRes,
        incRes,
        threatsRes,
        vulnRes,
        assetsRes,
        netRes,
        netStatRes,
        phishRes,
        pbRes,
        runsRes,
        repRes,
        usersRes,
        auditRes,
        intRes,
      ] = await Promise.all([
        fetch('/api/v1/auth/me').then((r) => r.json()).catch(() => null),
        fetch('/api/v1/dashboard/summary').then((r) => r.json()),
        fetch('/api/v1/dashboard/trends').then((r) => r.json()),
        fetch('/api/v1/logs').then((r) => r.json()),
        fetch('/api/v1/alerts').then((r) => r.json()),
        fetch('/api/v1/incidents').then((r) => r.json()),
        fetch('/api/v1/threats').then((r) => r.json()),
        fetch('/api/v1/vulnerabilities').then((r) => r.json()),
        fetch('/api/v1/assets').then((r) => r.json()),
        fetch('/api/v1/network/events').then((r) => r.json()),
        fetch('/api/v1/network/stats').then((r) => r.json()),
        fetch('/api/v1/phishing/history').then((r) => r.json()),
        fetch('/api/v1/automation/playbooks').then((r) => r.json()),
        fetch('/api/v1/automation/runs').then((r) => r.json()),
        fetch('/api/v1/reports').then((r) => r.json()),
        fetch('/api/v1/users').then((r) => r.json()),
        fetch('/api/v1/audit-logs').then((r) => r.json()),
        fetch('/api/v1/integrations').then((r) => r.json()),
      ]);

      if (authRes) {
        const validAuth = validateApiResponse(
          AuthResponseSchema,
          authRes,
          { user: currentUser as any },
          'AuthMe'
        );
        if (validAuth?.user) {
          setCurrentUser(validAuth.user as User);
          setActiveRole(validAuth.user.role);
        }
      }

      // Schema validation via Zod
      const validSummary = validateApiResponse(
        DashboardSummarySchema,
        sumRes,
        null,
        'DashboardSummary'
      );
      const validTrends = validateApiResponse(
        DashboardTrendsSchema,
        trRes,
        null,
        'DashboardTrends'
      );
      const validLogs = validateApiResponse(
        LogsResponseSchema,
        logsRes,
        { logs: [] },
        'Logs'
      );
      const validAlerts = validateApiResponse(
        AlertsResponseSchema,
        alertsRes,
        { alerts: [] },
        'Alerts'
      );
      const validIncidents = validateApiResponse(
        IncidentsResponseSchema,
        incRes,
        { incidents: [] },
        'Incidents'
      );
      const validThreats = validateApiResponse(
        ThreatsResponseSchema,
        threatsRes,
        { indicators: [] },
        'Threats'
      );
      const validVulns = validateApiResponse(
        VulnerabilitiesResponseSchema,
        vulnRes,
        { vulnerabilities: [] },
        'Vulnerabilities'
      );
      const validAssets = validateApiResponse(
        AssetsResponseSchema,
        assetsRes,
        { assets: [] },
        'Assets'
      );
      const validNetEvents = validateApiResponse(
        NetworkEventsResponseSchema,
        netRes,
        { connections: [] },
        'NetworkEvents'
      );
      const validNetStats = validateApiResponse(
        NetworkStatsSchema,
        netStatRes,
        null,
        'NetworkStats'
      );
      const validPhishing = validateApiResponse(
        PhishingHistoryResponseSchema,
        phishRes,
        { history: [] },
        'PhishingHistory'
      );
      const validPlaybooks = validateApiResponse(
        PlaybooksResponseSchema,
        pbRes,
        { playbooks: [] },
        'Playbooks'
      );
      const validRuns = validateApiResponse(
        AutomationRunsResponseSchema,
        runsRes,
        { runs: [] },
        'AutomationRuns'
      );
      const validReports = validateApiResponse(
        ReportsResponseSchema,
        repRes,
        { reports: [] },
        'Reports'
      );
      const validUsers = validateApiResponse(
        UsersResponseSchema,
        usersRes,
        { users: [] },
        'Users'
      );
      const validAudit = validateApiResponse(
        AuditLogsResponseSchema,
        auditRes,
        { auditLogs: [] },
        'AuditLogs'
      );
      const validIntegrations = validateApiResponse(
        IntegrationsResponseSchema,
        intRes,
        { integrations: [] },
        'Integrations'
      );

      // State updates with strictly validated data
      setSummaryMetrics(validSummary);
      setTrendsData(validTrends);
      setLogs(validLogs.logs);
      setAlerts(validAlerts.alerts);
      setIncidents(validIncidents.incidents);
      setThreatIndicators(validThreats.indicators);
      setVulnerabilities(validVulns.vulnerabilities);
      setAssets(validAssets.assets);
      setNetworkConnections(validNetEvents.connections);
      setNetworkStats(validNetStats);
      setPhishingHistory(validPhishing.history);
      setPlaybooks(validPlaybooks.playbooks);
      setAutomationRuns(validRuns.runs);
      setReports(validReports.reports);
      setUsers(validUsers.users as User[]);
      setAuditLogsList(validAudit.auditLogs);
      setIntegrations(validIntegrations.integrations);
    } catch (err) {
      console.warn('Data fetch notice:', err);
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    loadAllData();
  }, []);

  // Auth Handlers
  const handleAuthSuccess = (user: User, token?: string) => {
    setCurrentUser(user);
    setActiveRole(user.role);
    if (token) {
      try {
        localStorage.setItem('sentinelai_session_token', token);
      } catch {}
    }
    loadAllData();
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/v1/auth/logout', { method: 'POST' });
      localStorage.removeItem('sentinelai_session_token');
    } catch {}
    setCurrentUser(null);
    setIsAuthModalOpen(true);
  };

  // Action Handlers
  const handleRoleChange = async (newRole: UserRole) => {
    setActiveRole(newRole);
    try {
      await fetch('/api/v1/auth/switch-role', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: newRole }),
      });
      loadAllData();
    } catch {}
  };

  const handleIngestLog = async (logData: any) => {
    const res = await fetch('/api/v1/logs/ingest', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(logData),
    });
    const data = await res.json();
    loadAllData();
    return data;
  };

  const handleUpdateAlertStatus = async (alertId: string, status: AlertStatus) => {
    const res = await fetch(`/api/v1/alerts/${alertId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    const data = await res.json();
    if (selectedAlert?.id === alertId) {
      setSelectedAlert(data.alert);
    }
    loadAllData();
  };

  const handleAddAlertNote = async (alertId: string, text: string) => {
    const res = await fetch(`/api/v1/alerts/${alertId}/notes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text }),
    });
    const data = await res.json();
    if (selectedAlert?.id === alertId) {
      setSelectedAlert(data.alert);
    }
    loadAllData();
  };

  const handleEscalateAlert = async (alertId: string) => {
    const res = await fetch(`/api/v1/alerts/${alertId}/escalate-to-incident`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });
    const data = await res.json();
    setSelectedAlert(null);
    loadAllData();
    if (data.incident) {
      setSelectedIncident(data.incident);
    }
  };

  const handleCreateIncident = async (data: any) => {
    const res = await fetch('/api/v1/incidents', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const result = await res.json();
    loadAllData();
    if (result.incident) {
      setSelectedIncident(result.incident);
    }
  };

  const handleUpdateIncidentStatus = async (incidentId: string, status: IncidentStatus) => {
    const res = await fetch(`/api/v1/incidents/${incidentId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    const data = await res.json();
    if (selectedIncident?.id === incidentId) {
      setSelectedIncident(data.incident);
    }
    loadAllData();
  };

  const handleAddIncidentNote = async (incidentId: string, content: string) => {
    const res = await fetch(`/api/v1/incidents/${incidentId}/notes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content }),
    });
    const data = await res.json();
    if (selectedIncident?.id === incidentId) {
      setSelectedIncident(data.incident);
    }
    loadAllData();
  };

  const handleAnalyzePhishing = async (data: any) => {
    const res = await fetch('/api/v1/phishing/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const result = await res.json();
    loadAllData();
    return result;
  };

  const handleTriggerScan = async (assetId: string, scanType: string) => {
    const res = await fetch('/api/v1/vulnerabilities/scans', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ assetId, scanType }),
    });
    const result = await res.json();
    loadAllData();
    return result;
  };

  const handleAddIndicator = async (data: any) => {
    const res = await fetch('/api/v1/threats', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const result = await res.json();
    loadAllData();
    return result;
  };

  const handleEnrichIndicator = async (value: string) => {
    const res = await fetch('/api/v1/threats/enrich', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ indicatorValue: value }),
    });
    const result = await res.json();
    loadAllData();
    return result;
  };

  const handleExecutePlaybook = async (playbookId: string) => {
    const res = await fetch(`/api/v1/automation/playbooks/${playbookId}/execute`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ targetContext: 'SOC Console Operator execution' }),
    });
    const result = await res.json();
    loadAllData();
    return result;
  };

  const handleApproveRun = async (runId: string, decision: 'APPROVE' | 'REJECT', reason?: string) => {
    const res = await fetch(`/api/v1/automation/runs/${runId}/approve`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ decision, reason }),
    });
    const result = await res.json();
    loadAllData();
    return result;
  };

  const handleGenerateReport = async (data: any) => {
    const res = await fetch('/api/v1/reports/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const result = await res.json();
    loadAllData();
    return result;
  };

  const handleAddAsset = async (data: any) => {
    const res = await fetch('/api/v1/assets', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const result = await res.json();
    loadAllData();
    return result;
  };

  const handleAddUser = async (data: any) => {
    const res = await fetch('/api/v1/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const result = await res.json();
    loadAllData();
    return result;
  };

  const handleUpdateUser = async (userId: string, data: any) => {
    const res = await fetch(`/api/v1/users/${userId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const result = await res.json();
    loadAllData();
    return result;
  };

  const handleTestIntegration = async (id: string) => {
    const res = await fetch(`/api/v1/integrations/${id}/test`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });
    const result = await res.json();
    loadAllData();
    return result;
  };

  const handleUpdateIntegration = async (id: string, data: any) => {
    const res = await fetch(`/api/v1/integrations/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const result = await res.json();
    loadAllData();
    return result;
  };

  // Nav Titles mapping
  const navMetadata: Record<NavItemKey, { title: string; category: string }> = {
    overview: { title: 'Overview Dashboard', category: 'Operations' },
    monitoring: { title: 'Security Monitoring', category: 'Operations' },
    logs: { title: 'Security Logs', category: 'Operations' },
    threats: { title: 'Threat Detection', category: 'Operations' },
    alerts: { title: 'Alert Management', category: 'Operations' },
    incidents: { title: 'Incident Management', category: 'Operations' },
    phishing: { title: 'Phishing Detection', category: 'Intel & Analysis' },
    network: { title: 'Network Security', category: 'Intel & Analysis' },
    vulnerabilities: { title: 'Vulnerability Management', category: 'Intel & Analysis' },
    intel: { title: 'Threat Intelligence', category: 'Intel & Analysis' },
    copilot: { title: 'AI Investigation Assistant', category: 'Intel & Analysis' },
    automation: { title: 'Automation Center', category: 'SOAR & Automation' },
    playbooks: { title: 'Playbook Management', category: 'SOAR & Automation' },
    reports: { title: 'Security Reports', category: 'SOAR & Automation' },
    assets: { title: 'Asset Management', category: 'SOAR & Automation' },
    users: { title: 'User Management', category: 'Administration' },
    audit: { title: 'Audit Logs', category: 'Administration' },
    integrations: { title: 'Integrations Settings', category: 'Administration' },
    'ai-config': { title: 'AI Configuration', category: 'Administration' },
    settings: { title: 'System Settings', category: 'Administration' },
  };

  const criticalCount = alerts.filter((a) => a.severity === 'CRITICAL').length;
  const openIncidentsCount = incidents.filter((i) => i.status !== 'RESOLVED').length;

  return (
    <div className="min-h-screen bg-[#080D18] text-[#E8EEF9] flex">
      {/* Sidebar Navigation */}
      <Sidebar
        activeNav={activeNav}
        onSelectNav={setActiveNav}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        criticalCount={criticalCount}
      />

      {/* Main Content Area */}
      <div
        className={`flex-1 flex flex-col min-w-0 transition-all duration-200 ${
          sidebarCollapsed ? 'ml-18' : 'ml-64'
        }`}
      >
        <TopNav
          currentModuleTitle={navMetadata[activeNav].title}
          currentModuleCategory={navMetadata[activeNav].category}
          activeRole={activeRole}
          onChangeRole={handleRoleChange}
          onRefresh={loadAllData}
          isRefreshing={isRefreshing}
          onOpenIngestModal={() => setIsIngestModalOpen(true)}
          criticalAlertsCount={criticalCount}
          openIncidentsCount={openIncidentsCount}
          currentUser={currentUser}
          onOpenAuthModal={() => setIsAuthModalOpen(true)}
          onLogout={handleLogout}
        />

        {/* Viewport Content */}
        <main className="flex-1 p-6 max-w-7xl w-full mx-auto">
          {activeNav === 'overview' && (
            <OverviewDashboard
              summaryMetrics={summaryMetrics}
              trendsData={trendsData}
              alerts={alerts}
              incidents={incidents}
              onNavigate={setActiveNav}
              onSelectAlert={setSelectedAlert}
              onSelectIncident={setSelectedIncident}
            />
          )}

          {activeNav === 'monitoring' && (
            <SecurityMonitoring
              logs={logs}
              onOpenIngestModal={() => setIsIngestModalOpen(true)}
              onSelectLog={setSelectedLog}
            />
          )}

          {activeNav === 'logs' && (
            <SecurityLogs
              logs={logs}
              onOpenIngestModal={() => setIsIngestModalOpen(true)}
              onSelectLog={setSelectedLog}
            />
          )}

          {activeNav === 'threats' && <ThreatDetection />}

          {activeNav === 'alerts' && (
            <AlertManagement
              alerts={alerts}
              onSelectAlert={setSelectedAlert}
              onUpdateAlertStatus={handleUpdateAlertStatus}
              onEscalateAlert={handleEscalateAlert}
            />
          )}

          {activeNav === 'incidents' && (
            <IncidentManagement
              incidents={incidents}
              onSelectIncident={setSelectedIncident}
              onCreateIncident={handleCreateIncident}
              onUpdateIncidentStatus={handleUpdateIncidentStatus}
            />
          )}

          {activeNav === 'phishing' && (
            <PhishingDetection history={phishingHistory} onAnalyzePhishing={handleAnalyzePhishing} />
          )}

          {activeNav === 'network' && (
            <NetworkSecurity connections={networkConnections} stats={networkStats} />
          )}

          {activeNav === 'vulnerabilities' && (
            <VulnerabilityManagement
              vulnerabilities={vulnerabilities}
              assets={assets}
              onTriggerScan={handleTriggerScan}
            />
          )}

          {activeNav === 'intel' && (
            <ThreatIntelligence
              indicators={threatIndicators}
              onAddIndicator={handleAddIndicator}
              onEnrichIndicator={handleEnrichIndicator}
            />
          )}

          {activeNav === 'copilot' && (
            <AiInvestigation alerts={alerts} incidents={incidents} />
          )}

          {activeNav === 'automation' && (
            <AutomationCenter
              runs={automationRuns}
              onApproveRun={handleApproveRun}
              onExecutePlaybook={handleExecutePlaybook}
            />
          )}

          {activeNav === 'playbooks' && (
            <PlaybookManagement playbooks={playbooks} onExecutePlaybook={handleExecutePlaybook} />
          )}

          {activeNav === 'reports' && (
            <SecurityReports reports={reports} onGenerateReport={handleGenerateReport} />
          )}

          {activeNav === 'assets' && (
            <AssetManagement assets={assets} onAddAsset={handleAddAsset} />
          )}

          {activeNav === 'users' && (
            <UserManagement
              users={users}
              onAddUser={handleAddUser}
              onUpdateUser={handleUpdateUser}
            />
          )}

          {activeNav === 'audit' && <AuditLogs logs={auditLogsList} />}

          {activeNav === 'integrations' && (
            <IntegrationSettings
              integrations={integrations}
              onTestIntegration={handleTestIntegration}
              onUpdateIntegration={handleUpdateIntegration}
            />
          )}

          {activeNav === 'ai-config' && <AiConfiguration />}

          {activeNav === 'settings' && <SystemSettings />}
        </main>
      </div>

      {/* Global Ingestion Modal */}
      <IngestLogModal
        isOpen={isIngestModalOpen}
        onClose={() => setIsIngestModalOpen(false)}
        onIngest={handleIngestLog}
      />

      {/* Detail Drawers */}
      <LogDetailDrawer log={selectedLog} onClose={() => setSelectedLog(null)} />
      <AlertDetailDrawer
        alert={selectedAlert}
        onClose={() => setSelectedAlert(null)}
        onUpdateStatus={handleUpdateAlertStatus}
        onAddNote={handleAddAlertNote}
        onEscalate={handleEscalateAlert}
      />
      <IncidentDetailDrawer
        incident={selectedIncident}
        onClose={() => setSelectedIncident(null)}
        onUpdateStatus={handleUpdateIncidentStatus}
        onAddNote={handleAddIncidentNote}
      />

      {/* Authentication Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onAuthSuccess={handleAuthSuccess}
        currentUser={currentUser}
      />
    </div>
  );
}
