import React, { useState } from 'react';
import {
  Database,
  Plus,
  Search,
  ExternalLink,
  ShieldCheck,
  RefreshCw,
  Globe,
  Bot,
  Send,
  Sparkles,
  Copy,
  Check,
  AlertTriangle,
  FileText,
} from 'lucide-react';
import { ThreatIndicator, SecurityAlert, SecurityIncident } from '../types/index.ts';

export const ThreatIntelligence: React.FC<{
  indicators: ThreatIndicator[];
  onAddIndicator: (data: any) => Promise<any>;
  onEnrichIndicator: (value: string) => Promise<any>;
}> = ({ indicators, onAddIndicator, onEnrichIndicator }) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newType, setNewType] = useState<'IPV4' | 'DOMAIN' | 'URL' | 'FILE_HASH_SHA256'>('IPV4');
  const [newValue, setNewValue] = useState('');
  const [newThreatType, setNewThreatType] = useState<'C2_SERVER' | 'PHISHING_HOST' | 'BOTNET_NODE' | 'EXPLOIT_DROPPER'>('C2_SERVER');
  const [isEnriching, setIsEnriching] = useState<string | null>(null);
  const [search, setSearch] = useState('');

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newValue) return;
    await onAddIndicator({
      type: newType,
      value: newValue,
      threatType: newThreatType,
      confidence: 90,
      source: 'Analyst Submission',
    });
    setNewValue('');
    setShowAddModal(false);
  };

  const handleEnrich = async (val: string) => {
    setIsEnriching(val);
    try {
      await onEnrichIndicator(val);
    } finally {
      setIsEnriching(null);
    }
  };

  const filtered = indicators.filter((i) =>
    i.value.toLowerCase().includes(search.toLowerCase()) ||
    i.threatType.toLowerCase().includes(search.toLowerCase()) ||
    i.source.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#E8EEF9]">Threat Intelligence (IOCs)</h1>
          <p className="text-xs text-[#8C9CB5] mt-0.5">
            Indicators of Compromise repository enriched with VirusTotal and global threat feeds
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#45D6C5] hover:bg-[#38bcae] text-[#080D18] transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Indicator</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="p-4 rounded-xl bg-[#101B2D] border border-[#1A273D] flex items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-[#8C9CB5] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by IP, domain, hash, threat type..."
            className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg pl-9 pr-3 py-1.5 text-xs text-[#E8EEF9] outline-none focus:border-[#45D6C5]"
          />
        </div>
        <span className="text-xs font-mono text-[#8C9CB5]">
          {filtered.length} Indicators Monitored
        </span>
      </div>

      {/* Indicators Table */}
      <div className="rounded-xl bg-[#101B2D] border border-[#1A273D] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#1A273D] bg-[#0C1424] text-[#8C9CB5] text-[11px]">
                <th className="py-3 px-4 font-medium">Indicator Type</th>
                <th className="py-3 px-4 font-medium">Value</th>
                <th className="py-3 px-4 font-medium">Threat Classification</th>
                <th className="py-3 px-4 font-medium">Confidence</th>
                <th className="py-3 px-4 font-medium">Enrichment (VirusTotal / ASN)</th>
                <th className="py-3 px-4 font-medium">Source</th>
                <th className="py-3 px-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1A273D]">
              {filtered.map((ioc) => (
                <tr key={ioc.id} className="hover:bg-[#15233B]/40 transition-colors">
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-[#1A273D] text-[#45D6C5]">
                      {ioc.type}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono font-semibold text-[#E8EEF9] max-w-xs truncate">
                    {ioc.value}
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span className="text-[11px] font-mono text-[#F05268] font-medium">
                      {ioc.threatType}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-[#42C99A] font-semibold">
                    {ioc.confidence}%
                  </td>
                  <td className="py-3 px-4 text-[#8C9CB5] text-[11px]">
                    {ioc.enrichment ? (
                      <div>
                        <span className="text-[#F05268] font-bold font-mono">
                          {ioc.enrichment.maliciousVotes} engines flagged
                        </span>{' '}
                        · {ioc.enrichment.country || 'Global'} ({ioc.enrichment.autonomousSystem || 'N/A'})
                      </div>
                    ) : (
                      <span className="text-[#8C9CB5]">Not enriched</span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-[#8C9CB5] text-[11px] whitespace-nowrap">
                    {ioc.source}
                  </td>
                  <td className="py-3 px-4 text-right whitespace-nowrap">
                    <button
                      onClick={() => handleEnrich(ioc.value)}
                      disabled={isEnriching === ioc.value}
                      className="flex items-center gap-1.5 px-2.5 py-1 rounded text-[11px] font-medium bg-[#15233B] hover:bg-[#1E2D45] text-[#45D6C5] border border-[#1A273D] transition-colors ml-auto"
                    >
                      <RefreshCw className={`w-3 h-3 ${isEnriching === ioc.value ? 'animate-spin' : ''}`} />
                      <span>{isEnriching === ioc.value ? 'Querying...' : 'Enrich Live'}</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Indicator Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[#101B2D] border border-[#1A273D] rounded-2xl p-6 space-y-4">
            <h3 className="text-sm font-semibold text-[#E8EEF9]">Add Threat Indicator (IOC)</h3>
            <form onSubmit={handleAdd} className="space-y-3 text-xs">
              <div>
                <label className="block text-[#8C9CB5] mb-1 font-semibold">Indicator Type</label>
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value as any)}
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-2 text-[#E8EEF9] outline-none"
                >
                  <option value="IPV4">IPv4 Address</option>
                  <option value="DOMAIN">Domain Name</option>
                  <option value="URL">Full URL</option>
                  <option value="FILE_HASH_SHA256">SHA256 File Hash</option>
                </select>
              </div>

              <div>
                <label className="block text-[#8C9CB5] mb-1 font-semibold">Value</label>
                <input
                  type="text"
                  value={newValue}
                  onChange={(e) => setNewValue(e.target.value)}
                  placeholder="e.g. 194.26.29.112 or malicious-c2.net"
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-2 text-[#E8EEF9] font-mono outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-[#8C9CB5] mb-1 font-semibold">Threat Classification</label>
                <select
                  value={newThreatType}
                  onChange={(e) => setNewThreatType(e.target.value as any)}
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-2 text-[#E8EEF9] outline-none"
                >
                  <option value="C2_SERVER">C2 Command & Control</option>
                  <option value="PHISHING_HOST">Phishing Host</option>
                  <option value="BOTNET_NODE">Botnet Node</option>
                  <option value="EXPLOIT_DROPPER">Exploit Dropper</option>
                </select>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg text-[#8C9CB5]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-[#45D6C5] text-[#080D18] font-semibold"
                >
                  Save Indicator
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export const AiInvestigation: React.FC<{
  alerts: SecurityAlert[];
  incidents: SecurityIncident[];
}> = ({ alerts, incidents }) => {
  const [selectedAlertId, setSelectedAlertId] = useState(alerts[0]?.id || '');
  const [analystPrompt, setAnalystPrompt] = useState(
    'Correlate this alert against known APT techniques, assess lateral movement risk, and recommend containment steps.'
  );
  const [isInvestigating, setIsInvestigating] = useState(false);
  const [investigationResult, setInvestigationResult] = useState<any>(null);
  const [chatMessages, setChatMessages] = useState<Array<{ sender: 'user' | 'assistant'; text: string }>>([
    {
      sender: 'assistant',
      text: 'Greetings Analyst. I am SentinelAI Copilot, powered by Google Gemini. I have loaded your SOC context with 2 active critical alerts. How may I assist your investigation?',
    },
  ]);
  const [chatInput, setChatInput] = useState('');
  const [isChatSending, setIsChatSending] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleInvestigate = async () => {
    setIsInvestigating(true);
    try {
      const res = await fetch('/api/v1/ai/investigate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          alertId: selectedAlertId,
          promptContext: analystPrompt,
        }),
      });
      const data = await res.json();
      setInvestigationResult(data.investigation);
    } catch {
      // Fallback
    } finally {
      setIsInvestigating(false);
    }
  };

  const handleSendChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || isChatSending) return;

    const userText = chatInput;
    setChatInput('');
    setChatMessages((prev) => [...prev, { sender: 'user', text: userText }]);
    setIsChatSending(true);

    try {
      const res = await fetch('/api/v1/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userText, contextAlertId: selectedAlertId }),
      });
      const data = await res.json();
      setChatMessages((prev) => [...prev, { sender: 'assistant', text: data.reply || 'Analysis completed.' }]);
    } catch {
      setChatMessages((prev) => [
        ...prev,
        { sender: 'assistant', text: 'Error contacting AI Copilot. Please verify network or API key status.' },
      ]);
    } finally {
      setIsChatSending(false);
    }
  };

  const copyReport = () => {
    if (!investigationResult) return;
    navigator.clipboard.writeText(JSON.stringify(investigationResult, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold tracking-tight text-[#E8EEF9]">
          SentinelAI Copilot · AI Forensic Investigation
        </h1>
        <p className="text-xs text-[#8C9CB5] mt-0.5">
          Structured LLM investigation assistant with verified log references, prompt injection defense, and MITRE mapping
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Investigation Setup & Structured Report */}
        <div className="lg:col-span-7 space-y-4">
          <div className="p-5 rounded-xl bg-[#101B2D] border border-[#1A273D] space-y-3">
            <h2 className="text-xs font-semibold text-[#E8EEF9] flex items-center gap-2">
              <Bot className="w-4 h-4 text-[#45D6C5]" />
              <span>Select Investigation Scope</span>
            </h2>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-[#8C9CB5] mb-1 font-semibold">Target Security Alert</label>
                <select
                  value={selectedAlertId}
                  onChange={(e) => setSelectedAlertId(e.target.value)}
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs text-[#E8EEF9] outline-none"
                >
                  {alerts.map((a) => (
                    <option key={a.id} value={a.id}>
                      [{a.severity}] {a.id}: {a.title} ({a.riskScore}/100)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[#8C9CB5] mb-1 font-semibold">Investigation Directives</label>
                <textarea
                  value={analystPrompt}
                  onChange={(e) => setAnalystPrompt(e.target.value)}
                  rows={2}
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg p-2.5 text-xs text-[#E8EEF9] outline-none"
                />
              </div>

              <button
                onClick={handleInvestigate}
                disabled={isInvestigating}
                className="w-full py-2 rounded-lg text-xs font-semibold bg-[#45D6C5] hover:bg-[#38bcae] text-[#080D18] transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isInvestigating ? 'Analyzing Forensic Telemetry...' : 'Generate Structured AI Investigation'}</span>
              </button>
            </div>
          </div>

          {/* Investigation Output Card */}
          {investigationResult ? (
            <div className="p-5 rounded-xl bg-[#101B2D] border border-[#1A273D] space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#1A273D]">
                <div>
                  <div className="text-[11px] font-semibold text-[#8C9CB5] uppercase">Forensic Summary</div>
                  <div className="text-sm font-semibold text-[#E8EEF9] mt-0.5">{investigationResult.summary}</div>
                </div>
                <button
                  onClick={copyReport}
                  className="p-1.5 rounded-lg text-[#8C9CB5] hover:text-[#E8EEF9] bg-[#15233B] border border-[#1A273D]"
                  title="Copy JSON Investigation Report"
                >
                  {copied ? <Check className="w-4 h-4 text-[#42C99A]" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              {/* Verified Evidence Box */}
              <div>
                <h4 className="text-xs font-semibold text-[#E8EEF9] mb-2">Verified Event Evidence</h4>
                <div className="space-y-1.5">
                  {investigationResult.evidence?.map((ev: any, idx: number) => (
                    <div key={idx} className="p-2.5 rounded-lg bg-[#15233B] text-xs flex items-start gap-2 text-[#E8EEF9]">
                      <ShieldCheck className="w-3.5 h-3.5 text-[#42C99A] shrink-0 mt-0.5" />
                      <div>
                        <div>{ev.fact}</div>
                        <div className="text-[10px] text-[#45D6C5] font-mono mt-0.5">
                          Verified from Event ID: {ev.sourceEventId}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* MITRE ATT&CK Techniques */}
              <div>
                <h4 className="text-xs font-semibold text-[#E8EEF9] mb-2">Possible ATT&CK Techniques</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {investigationResult.possible_attack_techniques?.map((tech: any, idx: number) => (
                    <div key={idx} className="p-2.5 rounded-lg bg-[#15233B] text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-mono font-bold text-[#45D6C5]">{tech.id}</span>
                        <span className="text-[10px] text-[#8C9CB5]">{tech.tactic}</span>
                      </div>
                      <div className="font-semibold text-[#E8EEF9]">{tech.name}</div>
                      <p className="text-[11px] text-[#8C9CB5] leading-tight">{tech.rationale}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recommended Actions */}
              <div>
                <h4 className="text-xs font-semibold text-[#E8EEF9] mb-2">Recommended Response Actions</h4>
                <div className="space-y-1.5">
                  {investigationResult.recommended_actions?.map((act: any, idx: number) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-lg bg-[#15233B] border border-[#1A273D] text-xs flex items-center justify-between gap-2"
                    >
                      <span className="text-[#E8EEF9]">{act.step}</span>
                      <span
                        className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded uppercase ${
                          act.urgency === 'immediate'
                            ? 'bg-[#F05268]/20 text-[#F05268]'
                            : 'bg-[#E8AD4B]/20 text-[#E8AD4B]'
                        }`}
                      >
                        {act.urgency}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Limitations Notice */}
              {investigationResult.limitations?.length > 0 && (
                <div className="p-2.5 rounded-lg bg-[#0C1424] text-[11px] text-[#8C9CB5] space-y-1">
                  <span className="font-semibold text-[#E8AD4B] flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3" /> AI Model Verification Boundaries:
                  </span>
                  {investigationResult.limitations.map((lim: string, idx: number) => (
                    <div key={idx}>· {lim}</div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="p-8 rounded-xl bg-[#101B2D] border border-[#1A273D] text-center text-[#8C9CB5] text-xs">
              Click "Generate Structured AI Investigation" above to perform deep contextual analysis.
            </div>
          )}
        </div>

        {/* Right Column: Interactive Copilot Chat */}
        <div className="lg:col-span-5 flex flex-col h-[650px] p-5 rounded-xl bg-[#101B2D] border border-[#1A273D]">
          <div className="flex items-center justify-between pb-3 border-b border-[#1A273D] mb-3">
            <div className="flex items-center gap-2">
              <Bot className="w-4 h-4 text-[#45D6C5]" />
              <span className="text-xs font-semibold text-[#E8EEF9]">SentinelAI Copilot Q&A</span>
            </div>
            <span className="text-[10px] font-mono text-[#42C99A]">Model: gemini-3.8-flash</span>
          </div>

          {/* Chat Stream */}
          <div className="flex-1 overflow-y-auto space-y-3 pr-1 text-xs">
            {chatMessages.map((msg, i) => (
              <div
                key={i}
                className={`p-3 rounded-xl max-w-[88%] ${
                  msg.sender === 'user'
                    ? 'ml-auto bg-[#45D6C5]/15 border border-[#45D6C5]/30 text-[#E8EEF9]'
                    : 'mr-auto bg-[#15233B] border border-[#1A273D] text-[#E8EEF9]'
                }`}
              >
                <div className="text-[10px] font-semibold text-[#8C9CB5] mb-1">
                  {msg.sender === 'user' ? 'You' : 'SentinelAI Copilot'}
                </div>
                <div className="whitespace-pre-line leading-relaxed">{msg.text}</div>
              </div>
            ))}
            {isChatSending && (
              <div className="p-3 rounded-xl max-w-[85%] bg-[#15233B] text-xs text-[#8C9CB5] animate-pulse">
                Copilot reasoning...
              </div>
            )}
          </div>

          {/* Chat Input */}
          <form onSubmit={handleSendChat} className="pt-3 border-t border-[#1A273D] flex items-center gap-2">
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              placeholder="Ask Copilot about IOCs, containment, or MITRE..."
              className="flex-1 bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-2 text-xs text-[#E8EEF9] outline-none focus:border-[#45D6C5]"
            />
            <button
              type="submit"
              disabled={isChatSending}
              className="p-2 rounded-lg bg-[#45D6C5] text-[#080D18] hover:bg-[#38bcae] transition-colors disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
