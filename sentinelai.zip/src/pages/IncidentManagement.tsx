import React, { useState } from 'react';
import {
  LifeBuoy,
  Plus,
  Clock,
  Shield,
  UserCheck,
  CheckCircle,
  FileText,
  AlertCircle,
  ArrowRight,
} from 'lucide-react';
import { SecurityIncident, IncidentStatus, IncidentPriority } from '../types/index.ts';
import { StatusBadge } from '../components/common/StatCard.tsx';

interface IncidentManagementProps {
  incidents: SecurityIncident[];
  onSelectIncident: (incident: SecurityIncident) => void;
  onCreateIncident: (data: any) => Promise<void>;
  onUpdateIncidentStatus: (incidentId: string, status: IncidentStatus) => Promise<void>;
}

export const IncidentManagement: React.FC<IncidentManagementProps> = ({
  incidents,
  onSelectIncident,
  onCreateIncident,
  onUpdateIncidentStatus,
}) => {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newPriority, setNewPriority] = useState<IncidentPriority>('P2_HIGH');
  const [newSummary, setNewSummary] = useState('');

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newSummary) return;
    await onCreateIncident({
      title: newTitle,
      priority: newPriority,
      summary: newSummary,
    });
    setNewTitle('');
    setNewSummary('');
    setShowCreateModal(false);
  };

  const stages: IncidentStatus[] = [
    'DETECTED',
    'TRIAGED',
    'INVESTIGATING',
    'CONTAINMENT_REVIEW',
    'RECOVERY',
    'RESOLVED',
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#E8EEF9]">Incident Management</h1>
          <p className="text-xs text-[#8C9CB5] mt-0.5">
            End-to-end incident response lifecycle, containment coordination, and forensic timeline
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#45D6C5] hover:bg-[#38bcae] text-[#080D18] transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Incident</span>
        </button>
      </div>

      {/* Lifecycle Progress Bar visual */}
      <div className="p-4 rounded-xl bg-[#101B2D] border border-[#1A273D]">
        <div className="text-[11px] font-semibold text-[#8C9CB5] uppercase mb-3">
          Incident Response Lifecycle Progression
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-6 gap-2">
          {stages.map((stage, idx) => (
            <div
              key={stage}
              className="p-2.5 rounded-lg bg-[#15233B] border border-[#1A273D] flex flex-col justify-between"
            >
              <div className="flex items-center justify-between text-[10px] text-[#8C9CB5] font-mono mb-1">
                <span>STAGE 0{idx + 1}</span>
                <span className="text-[#45D6C5]">
                  {incidents.filter((i) => i.status === stage).length}
                </span>
              </div>
              <span className="text-xs font-semibold text-[#E8EEF9]">
                {stage.replace(/_/g, ' ')}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Incident Cards / List */}
      <div className="space-y-3">
        {incidents.map((incident) => (
          <div
            key={incident.id}
            onClick={() => onSelectIncident(incident)}
            className="p-5 rounded-xl bg-[#101B2D] border border-[#1A273D] hover:border-[#45D6C5]/40 transition-colors cursor-pointer space-y-3"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-3">
                <span className="font-mono text-xs font-bold text-[#45D6C5] bg-[#45D6C5]/10 px-2.5 py-1 rounded border border-[#45D6C5]/30">
                  {incident.incidentNumber}
                </span>
                <span
                  className={`text-[11px] font-mono font-semibold px-2 py-0.5 rounded ${
                    incident.priority === 'P1_CRITICAL'
                      ? 'bg-[#F05268]/20 text-[#F05268]'
                      : 'bg-[#FF754C]/20 text-[#FF754C]'
                  }`}
                >
                  {incident.priority.replace(/_/g, ' ')}
                </span>
                <h3 className="text-sm font-semibold text-[#E8EEF9]">{incident.title}</h3>
              </div>
              <div className="flex items-center gap-2">
                <StatusBadge status={incident.status} />
              </div>
            </div>

            <p className="text-xs text-[#8C9CB5]">{incident.summary}</p>

            <div className="pt-2 border-t border-[#1A273D] flex flex-wrap items-center justify-between gap-4 text-xs text-[#8C9CB5]">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1.5">
                  <UserCheck className="w-3.5 h-3.5 text-[#45D6C5]" />
                  <span>Lead: {incident.leadInvestigatorName}</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-[#8C9CB5]" />
                  <span>Created: {new Date(incident.createdAt).toLocaleTimeString()}</span>
                </span>
                <span className="font-mono text-[11px] text-[#438CFF]">
                  MITRE: {incident.mitreTechniques.join(', ')}
                </span>
              </div>

              <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                <span className="text-[11px] text-[#8C9CB5]">Move Stage:</span>
                <select
                  value={incident.status}
                  onChange={(e) => onUpdateIncidentStatus(incident.id, e.target.value as IncidentStatus)}
                  className="bg-[#15233B] border border-[#1A273D] rounded px-2 py-1 text-xs text-[#E8EEF9] outline-none"
                >
                  {stages.map((s) => (
                    <option key={s} value={s}>
                      {s.replace(/_/g, ' ')}
                    </option>
                  ))}
                </select>
                <button
                  onClick={() => onSelectIncident(incident)}
                  className="px-2.5 py-1 rounded text-xs font-medium bg-[#15233B] text-[#45D6C5] hover:bg-[#1E2D45] border border-[#1A273D]"
                >
                  Timeline & Notes →
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Create Incident Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-lg bg-[#101B2D] border border-[#1A273D] rounded-2xl shadow-2xl p-6 space-y-4">
            <h3 className="text-sm font-semibold text-[#E8EEF9]">Declare Security Incident</h3>
            <form onSubmit={handleCreate} className="space-y-3 text-xs">
              <div>
                <label htmlFor="incident-title-input" className="block text-[#8C9CB5] mb-1 font-semibold">Incident Title</label>
                <input
                  id="incident-title-input"
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Unauthorized S3 Bucket Exfiltration Spike"
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-2 text-[#E8EEF9] outline-none"
                  required
                />
              </div>

              <div>
                <label htmlFor="incident-priority-select" className="block text-[#8C9CB5] mb-1 font-semibold">Priority</label>
                <select
                  id="incident-priority-select"
                  value={newPriority}
                  onChange={(e) => setNewPriority(e.target.value as IncidentPriority)}
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-2 text-[#E8EEF9] outline-none"
                >
                  <option value="P1_CRITICAL">P1 - Critical (Immediate Blast Radius Containment)</option>
                  <option value="P2_HIGH">P2 - High (Severe Impact)</option>
                  <option value="P3_MEDIUM">P3 - Medium (Moderate Concern)</option>
                  <option value="P4_LOW">P4 - Low (Informational Triage)</option>
                </select>
              </div>

              <div>
                <label htmlFor="incident-summary-textarea" className="block text-[#8C9CB5] mb-1 font-semibold">Executive Summary</label>
                <textarea
                  id="incident-summary-textarea"
                  value={newSummary}
                  onChange={(e) => setNewSummary(e.target.value)}
                  rows={3}
                  placeholder="Describe observed adversary indicators, affected scope, and immediate actions taken."
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg p-2.5 text-[#E8EEF9] outline-none"
                  required
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-3 py-1.5 rounded-lg text-[#8C9CB5] hover:text-[#E8EEF9]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-[#45D6C5] text-[#080D18] font-semibold"
                >
                  Declare Incident
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
