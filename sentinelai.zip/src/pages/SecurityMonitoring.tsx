import React, { useState, useEffect } from 'react';
import { Play, Pause, ShieldAlert, Activity, Wifi, Filter, ArrowDown } from 'lucide-react';
import { SecurityLog } from '../types/index.ts';
import { SeverityBadge } from '../components/common/StatCard.tsx';

interface SecurityMonitoringProps {
  logs: SecurityLog[];
  onOpenIngestModal: () => void;
  onSelectLog: (log: SecurityLog) => void;
}

export const SecurityMonitoring: React.FC<SecurityMonitoringProps> = ({ logs, onOpenIngestModal, onSelectLog }) => {
  const [isStreaming, setIsStreaming] = useState(true);
  const [streamFilter, setStreamFilter] = useState('ALL');
  const [streamedLogs, setStreamedLogs] = useState<SecurityLog[]>(logs);
  const [eventRate, setEventRate] = useState(384); // events/sec

  // Simulate incoming live telemetry stream
  useEffect(() => {
    if (!isStreaming) return;
    const interval = setInterval(() => {
      setEventRate(Math.floor(350 + Math.random() * 80));
    }, 2000);
    return () => clearInterval(interval);
  }, [isStreaming]);

  useEffect(() => {
    setStreamedLogs(logs);
  }, [logs]);

  const filteredLogs = streamedLogs.filter(
    (l) => streamFilter === 'ALL' || l.source === streamFilter || (streamFilter === 'ANOMALIES' && (l.severity === 'CRITICAL' || l.severity === 'HIGH'))
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#E8EEF9]">
            Live Security Monitoring Stream
          </h1>
          <p className="text-xs text-[#8C9CB5] mt-0.5">
            Real-time packet flow inspection and sensor anomaly event ingestion
          </p>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#101B2D] border border-[#1A273D] text-xs font-mono">
            <Wifi className="w-3.5 h-3.5 text-[#45D6C5]" />
            <span className="text-[#8C9CB5]">Throughput:</span>
            <span className="text-[#45D6C5] font-bold tabular-nums">{eventRate} evt/s</span>
          </div>

          <button
            onClick={() => setIsStreaming(!isStreaming)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              isStreaming
                ? 'bg-[#15233B] text-[#E8AD4B] border border-[#E8AD4B]/30'
                : 'bg-[#45D6C5] text-[#080D18]'
            }`}
          >
            {isStreaming ? (
              <>
                <Pause className="w-3.5 h-3.5" />
                <span>Pause Stream</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5" />
                <span>Resume Stream</span>
              </>
            )}
          </button>

          <button
            onClick={onOpenIngestModal}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#15233B] hover:bg-[#1E2D45] text-[#45D6C5] border border-[#45D6C5]/30 transition-colors"
          >
            Inject Sample Event
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {['ALL', 'ANOMALIES', 'AUTH_SERVER', 'FIREWALL', 'EDR_AGENT', 'WAF', 'DNS_PROXY'].map((f) => (
          <button
            key={f}
            onClick={() => setStreamFilter(f)}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-colors whitespace-nowrap ${
              streamFilter === f
                ? 'bg-[#15233B] text-[#45D6C5] border border-[#45D6C5]/30'
                : 'bg-[#101B2D] text-[#8C9CB5] hover:text-[#E8EEF9] border border-[#1A273D]'
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Live Stream Terminal */}
      <div className="rounded-xl bg-[#0A101C] border border-[#1A273D] overflow-hidden flex flex-col h-[560px]">
        {/* Terminal Header */}
        <div className="px-4 py-2.5 bg-[#0C1424] border-b border-[#1A273D] flex items-center justify-between text-xs text-[#8C9CB5]">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#45D6C5]" />
            <span className="font-mono font-semibold text-[#E8EEF9]">SIEM_EVENT_FEED://ACTIVE</span>
          </div>
          <span className="font-mono text-[11px]">Displaying latest {filteredLogs.length} events</span>
        </div>

        {/* Event List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2 font-mono text-xs">
          {filteredLogs.map((log) => (
            <div
              key={log.id}
              onClick={() => onSelectLog(log)}
              className="p-3 rounded-lg bg-[#101B2D]/70 hover:bg-[#15233B] border border-[#1A273D] hover:border-[#45D6C5]/40 transition-colors cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-2"
            >
              <div className="flex items-center gap-3 min-w-0">
                <span className="text-[#8C9CB5] text-[11px] whitespace-nowrap">
                  {new Date(log.timestamp).toLocaleTimeString()}
                </span>
                <span className="px-1.5 py-0.5 rounded text-[10px] bg-[#1A273D] text-[#45D6C5] font-semibold whitespace-nowrap">
                  {log.source}
                </span>
                <SeverityBadge severity={log.severity} />
                <span className="text-[#E8EEF9] truncate font-sans text-xs">{log.message}</span>
              </div>

              <div className="flex items-center gap-3 text-[11px] text-[#8C9CB5] shrink-0">
                {log.sourceIp && (
                  <span>
                    SRC: <span className="text-[#438CFF]">{log.sourceIp}</span>
                  </span>
                )}
                {log.destinationIp && (
                  <span>
                    DST: <span className="text-[#8C9CB5]">{log.destinationIp}</span>
                  </span>
                )}
                <span className="text-[#45D6C5] hover:underline font-sans text-xs">Details →</span>
              </div>
            </div>
          ))}

          {filteredLogs.length === 0 && (
            <div className="h-full flex items-center justify-center text-xs text-[#8C9CB5]">
              No events matched current filter criteria.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export const SecurityLogs: React.FC<{
  logs: SecurityLog[];
  onOpenIngestModal: () => void;
  onSelectLog: (log: SecurityLog) => void;
}> = ({ logs, onOpenIngestModal, onSelectLog }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSeverity, setSelectedSeverity] = useState('ALL');
  const [selectedSource, setSelectedSource] = useState('ALL');

  const filtered = logs.filter((log) => {
    const matchesSearch =
      searchTerm === '' ||
      log.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.eventType.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (log.sourceIp && log.sourceIp.includes(searchTerm));
    const matchesSev = selectedSeverity === 'ALL' || log.severity === selectedSeverity;
    const matchesSrc = selectedSource === 'ALL' || log.source === selectedSource;
    return matchesSearch && matchesSev && matchesSrc;
  });

  const exportLogsAsJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(filtered, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `sentinelai-logs-${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#E8EEF9]">Security Log Management</h1>
          <p className="text-xs text-[#8C9CB5] mt-0.5">
            Normalized repository of ingested firewall, identity, EDR, and network proxy logs
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportLogsAsJson}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#101B2D] hover:bg-[#15233B] text-[#E8EEF9] border border-[#1A273D] transition-colors"
          >
            Export JSON
          </button>
          <button
            onClick={onOpenIngestModal}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#45D6C5] hover:bg-[#38bcae] text-[#080D18] transition-colors"
          >
            Ingest Log
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="p-4 rounded-xl bg-[#101B2D] border border-[#1A273D] grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div>
          <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Search Logs</label>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by IP, event type, message..."
            className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs text-[#E8EEF9] outline-none focus:border-[#45D6C5]"
          />
        </div>

        <div>
          <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Filter by Severity</label>
          <select
            value={selectedSeverity}
            onChange={(e) => setSelectedSeverity(e.target.value)}
            className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs text-[#E8EEF9] outline-none focus:border-[#45D6C5]"
          >
            <option value="ALL">All Severities</option>
            <option value="CRITICAL">Critical</option>
            <option value="HIGH">High</option>
            <option value="MEDIUM">Medium</option>
            <option value="LOW">Low</option>
            <option value="INFO">Info</option>
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Filter by Source</label>
          <select
            value={selectedSource}
            onChange={(e) => setSelectedSource(e.target.value)}
            className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs text-[#E8EEF9] outline-none focus:border-[#45D6C5]"
          >
            <option value="ALL">All Sources</option>
            <option value="FIREWALL">FIREWALL</option>
            <option value="AUTH_SERVER">AUTH_SERVER</option>
            <option value="EDR_AGENT">EDR_AGENT</option>
            <option value="WAF">WAF</option>
            <option value="DNS_PROXY">DNS_PROXY</option>
            <option value="CLOUD_TRAIL">CLOUD_TRAIL</option>
          </select>
        </div>
      </div>

      {/* Logs Table */}
      <div className="rounded-xl bg-[#101B2D] border border-[#1A273D] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#1A273D] bg-[#0C1424] text-[#8C9CB5] text-[11px]">
                <th className="py-3 px-4 font-medium">Timestamp</th>
                <th className="py-3 px-4 font-medium">Severity</th>
                <th className="py-3 px-4 font-medium">Source</th>
                <th className="py-3 px-4 font-medium">Event Type</th>
                <th className="py-3 px-4 font-medium">Message</th>
                <th className="py-3 px-4 font-medium">Source IP</th>
                <th className="py-3 px-4 font-medium text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1A273D]">
              {filtered.map((log) => (
                <tr
                  key={log.id}
                  onClick={() => onSelectLog(log)}
                  className="hover:bg-[#15233B] transition-colors cursor-pointer"
                >
                  <td className="py-3 px-4 font-mono text-[11px] text-[#8C9CB5] whitespace-nowrap">
                    {new Date(log.timestamp).toLocaleTimeString()}
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <SeverityBadge severity={log.severity} />
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-[#45D6C5] whitespace-nowrap">{log.source}</td>
                  <td className="py-3 px-4 font-mono text-[11px] text-[#E8EEF9] whitespace-nowrap">{log.eventType}</td>
                  <td className="py-3 px-4 text-[#8C9CB5] max-w-md truncate">{log.message}</td>
                  <td className="py-3 px-4 font-mono text-[11px] text-[#438CFF] whitespace-nowrap">
                    {log.sourceIp || '—'}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectLog(log);
                      }}
                      className="text-xs text-[#45D6C5] hover:underline font-medium"
                    >
                      Inspect
                    </button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-[#8C9CB5]">
                    No security logs match your search criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
