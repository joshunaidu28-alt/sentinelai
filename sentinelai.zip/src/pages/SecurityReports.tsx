import React, { useState } from 'react';
import {
  BarChart3,
  FileText,
  Download,
  Plus,
  Server,
  ShieldCheck,
  CheckCircle,
  Eye,
  Calendar,
  AlertTriangle,
} from 'lucide-react';
import { SecurityReport, MonitoredAsset } from '../types/index.ts';

export const SecurityReports: React.FC<{
  reports: SecurityReport[];
  onGenerateReport: (data: any) => Promise<any>;
}> = ({ reports, onGenerateReport }) => {
  const [reportTitle, setReportTitle] = useState('Executive SOC Threat Briefing');
  const [reportType, setReportType] = useState('DAILY_SUMMARY');
  const [dateRange, setDateRange] = useState('Past 24 Hours');
  const [format, setFormat] = useState<'PDF' | 'CSV' | 'JSON'>('PDF');
  const [isGenerating, setIsGenerating] = useState(false);
  const [previewReport, setPreviewReport] = useState<SecurityReport | null>(reports[0] || null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsGenerating(true);
    try {
      const res = await onGenerateReport({
        title: reportTitle,
        type: reportType,
        dateRange,
        format,
      });
      if (res?.report) {
        setPreviewReport(res.report);
      }
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = (rep: SecurityReport) => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(rep, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${rep.title.toLowerCase().replace(/\s+/g, '-')}-${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold tracking-tight text-[#E8EEF9]">Security Reporting Center</h1>
        <p className="text-xs text-[#8C9CB5] mt-0.5">
          Generate executive security briefings, audit-grade incident dossiers, and vulnerability compliance summaries
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Generate Form */}
        <div className="lg:col-span-5 p-5 rounded-xl bg-[#101B2D] border border-[#1A273D] space-y-4">
          <h2 className="text-xs font-semibold text-[#E8EEF9] flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-[#45D6C5]" />
            <span>Configure Security Report</span>
          </h2>

          <form onSubmit={handleGenerate} className="space-y-3 text-xs">
            <div>
              <label className="block text-[#8C9CB5] mb-1 font-semibold">Report Title</label>
              <input
                type="text"
                value={reportTitle}
                onChange={(e) => setReportTitle(e.target.value)}
                className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs text-[#E8EEF9] outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-[#8C9CB5] mb-1 font-semibold">Report Template Type</label>
              <select
                value={reportType}
                onChange={(e) => setReportType(e.target.value)}
                className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs text-[#E8EEF9] outline-none"
              >
                <option value="DAILY_SUMMARY">Daily Security Summary</option>
                <option value="WEEKLY_THREAT">Weekly Threat Intelligence Report</option>
                <option value="INCIDENT_INVESTIGATION">Incident Investigation Dossier</option>
                <option value="VULNERABILITY_ASSESSMENT">Vulnerability Assessment & CVSS Review</option>
                <option value="SOC_METRICS">SOC Operational Performance Metrics</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[#8C9CB5] mb-1 font-semibold">Date Range</label>
                <select
                  value={dateRange}
                  onChange={(e) => setDateRange(e.target.value)}
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs text-[#E8EEF9] outline-none"
                >
                  <option value="Past 24 Hours">Past 24 Hours</option>
                  <option value="Past 7 Days">Past 7 Days</option>
                  <option value="Past 30 Days">Past 30 Days</option>
                  <option value="Incident Window">Active Incident Window</option>
                </select>
              </div>

              <div>
                <label className="block text-[#8C9CB5] mb-1 font-semibold">Export Format</label>
                <select
                  value={format}
                  onChange={(e) => setFormat(e.target.value as any)}
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs text-[#E8EEF9] outline-none"
                >
                  <option value="PDF">PDF Document</option>
                  <option value="CSV">CSV Spreadsheet</option>
                  <option value="JSON">Structured JSON</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              disabled={isGenerating}
              className="w-full py-2 rounded-lg text-xs font-semibold bg-[#45D6C5] hover:bg-[#38bcae] text-[#080D18] transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>{isGenerating ? 'Compiling Metrics...' : 'Generate Report'}</span>
            </button>
          </form>

          {/* Historical Reports Archive */}
          <div className="pt-3 border-t border-[#1A273D] space-y-2">
            <span className="text-[11px] font-semibold text-[#8C9CB5] uppercase tracking-wider block">
              Generated Reports Archive:
            </span>
            <div className="space-y-1.5 max-h-56 overflow-y-auto">
              {reports.map((rep) => (
                <div
                  key={rep.id}
                  onClick={() => setPreviewReport(rep)}
                  className={`p-2.5 rounded-lg border text-xs cursor-pointer flex items-center justify-between ${
                    previewReport?.id === rep.id
                      ? 'bg-[#15233B] border-[#45D6C5]'
                      : 'bg-[#0C1424] border-[#1A273D] hover:border-[#2D4263]'
                  }`}
                >
                  <div className="min-w-0 pr-2">
                    <div className="font-semibold text-[#E8EEF9] truncate">{rep.title}</div>
                    <div className="text-[10px] text-[#8C9CB5] font-mono">
                      {rep.dateRange} · {new Date(rep.generatedAt).toLocaleDateString()}
                    </div>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDownload(rep);
                    }}
                    className="p-1 rounded text-[#8C9CB5] hover:text-[#45D6C5]"
                    title="Download Report"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Report Document Preview */}
        <div className="lg:col-span-7">
          {previewReport ? (
            <div className="p-6 rounded-xl bg-[#101B2D] border border-[#1A273D] space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#1A273D]">
                <div>
                  <span className="text-[10px] font-mono text-[#45D6C5] uppercase font-semibold">
                    {previewReport.type.replace(/_/g, ' ')}
                  </span>
                  <h3 className="text-base font-bold text-[#E8EEF9] mt-0.5">{previewReport.title}</h3>
                  <div className="text-[11px] text-[#8C9CB5]">
                    Generated by {previewReport.generatedBy} on {new Date(previewReport.generatedAt).toLocaleString()}
                  </div>
                </div>

                <button
                  onClick={() => handleDownload(previewReport)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#15233B] hover:bg-[#1E2D45] text-[#45D6C5] border border-[#1A273D] transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </button>
              </div>

              {/* Summary KPIs */}
              <div className="p-4 rounded-lg bg-[#0C1424] border border-[#1A273D] space-y-2">
                <span className="text-xs font-semibold text-[#E8EEF9]">Key Forensic Findings:</span>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-1">
                  {Object.entries(previewReport.summaryMetrics).map(([key, val]) => (
                    <div key={key} className="p-2 rounded bg-[#15233B]">
                      <div className="text-[10px] text-[#8C9CB5] uppercase font-mono">{key.replace(/([A-Z])/g, ' $1')}</div>
                      <div className="text-sm font-bold font-mono text-[#E8EEF9]">{String(val)}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Verified Audit Notice */}
              <div className="p-3 rounded-lg bg-[#15233B] border border-[#1A273D] text-[11px] text-[#8C9CB5] flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-[#42C99A] shrink-0" />
                <span>
                  All metrics originated from immutable PostgreSQL security event records and signed audit hashes.
                </span>
              </div>
            </div>
          ) : (
            <div className="p-8 rounded-xl bg-[#101B2D] border border-[#1A273D] text-center text-[#8C9CB5] text-xs">
              Select or generate a report to view full preview.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export const AssetManagement: React.FC<{
  assets: MonitoredAsset[];
  onAddAsset: (data: any) => Promise<any>;
}> = ({ assets, onAddAsset }) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [name, setName] = useState('');
  const [type, setType] = useState<MonitoredAsset['type']>('SERVER');
  const [ipAddress, setIpAddress] = useState('');
  const [owner, setOwner] = useState('Infrastructure Team');
  const [environment, setEnvironment] = useState<'PRODUCTION' | 'STAGING' | 'CORPORATE'>('PRODUCTION');
  const [criticality, setCriticality] = useState<MonitoredAsset['criticality']>('TIER_1_CRITICAL');

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !ipAddress) return;
    await onAddAsset({
      name,
      type,
      ipAddress,
      owner,
      environment,
      criticality,
    });
    setName('');
    setIpAddress('');
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#E8EEF9]">Asset Management & Scope</h1>
          <p className="text-xs text-[#8C9CB5] mt-0.5">
            Authorized infrastructure inventory, criticality tiering, and active vulnerability mapping
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#45D6C5] hover:bg-[#38bcae] text-[#080D18] transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Asset</span>
        </button>
      </div>

      {/* Asset Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {assets.map((asset) => (
          <div
            key={asset.id}
            className="p-5 rounded-xl bg-[#101B2D] border border-[#1A273D] hover:border-[#2D4263] transition-all space-y-3"
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-[#1A273D] text-[#45D6C5]">
                {asset.type}
              </span>
              <span
                className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded ${
                  asset.criticality === 'TIER_1_CRITICAL'
                    ? 'bg-[#F05268]/20 text-[#F05268]'
                    : asset.criticality === 'TIER_2_HIGH'
                    ? 'bg-[#FF754C]/20 text-[#FF754C]'
                    : 'bg-[#438CFF]/20 text-[#438CFF]'
                }`}
              >
                {asset.criticality.replace(/_/g, ' ')}
              </span>
            </div>

            <div>
              <h3 className="text-sm font-semibold text-[#E8EEF9]">{asset.name}</h3>
              <div className="font-mono text-xs text-[#8C9CB5] mt-0.5">
                {asset.ipAddress} · {asset.hostname}
              </div>
            </div>

            <div className="pt-2 border-t border-[#1A273D] grid grid-cols-2 gap-2 text-[11px] text-[#8C9CB5]">
              <div>
                <span className="block text-[10px] uppercase text-[#8C9CB5]/70">Owner:</span>
                <span className="text-[#E8EEF9] truncate block">{asset.owner}</span>
              </div>
              <div>
                <span className="block text-[10px] uppercase text-[#8C9CB5]/70">Env:</span>
                <span className="text-[#E8EEF9] font-mono">{asset.environment}</span>
              </div>
              <div>
                <span className="block text-[10px] uppercase text-[#8C9CB5]/70">Active Alerts:</span>
                <span className="font-mono font-semibold text-[#F05268]">{asset.activeAlertsCount}</span>
              </div>
              <div>
                <span className="block text-[10px] uppercase text-[#8C9CB5]/70">CVEs Open:</span>
                <span className="font-mono font-semibold text-[#E8AD4B]">{asset.openVulnerabilitiesCount}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Asset Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[#101B2D] border border-[#1A273D] rounded-2xl p-6 space-y-4">
            <h3 className="text-sm font-semibold text-[#E8EEF9]">Register Monitored Asset</h3>
            <form onSubmit={handleAdd} className="space-y-3 text-xs">
              <div>
                <label className="block text-[#8C9CB5] mb-1 font-semibold">Asset Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Primary Active Directory DC"
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-2 text-[#E8EEF9] outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-[#8C9CB5] mb-1 font-semibold">IP Address</label>
                <input
                  type="text"
                  value={ipAddress}
                  onChange={(e) => setIpAddress(e.target.value)}
                  placeholder="10.0.1.15"
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-2 text-[#E8EEF9] font-mono outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[#8C9CB5] mb-1 font-semibold">Asset Type</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-2 text-[#E8EEF9] outline-none"
                  >
                    <option value="SERVER">Server</option>
                    <option value="DATABASE">Database</option>
                    <option value="FIREWALL">Firewall</option>
                    <option value="API_GATEWAY">API Gateway</option>
                    <option value="WORKSTATION">Workstation</option>
                    <option value="CLOUD_VM">Cloud VM</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[#8C9CB5] mb-1 font-semibold">Criticality</label>
                  <select
                    value={criticality}
                    onChange={(e) => setCriticality(e.target.value as any)}
                    className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-2 text-[#E8EEF9] outline-none"
                  >
                    <option value="TIER_1_CRITICAL">Tier 1 Critical</option>
                    <option value="TIER_2_HIGH">Tier 2 High</option>
                    <option value="TIER_3_MEDIUM">Tier 3 Medium</option>
                    <option value="TIER_4_LOW">Tier 4 Low</option>
                  </select>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg text-[#8C9CB5]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-[#45D6C5] text-[#080D18] font-semibold"
                >
                  Save Asset
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
