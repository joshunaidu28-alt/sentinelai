import React, { useState } from 'react';
import {
  AlertTriangle,
  ShieldCheck,
  Zap,
  Play,
  CheckCircle2,
  Sliders,
  Eye,
  FileCode,
  Layers,
} from 'lucide-react';
import { DetectionRule, Severity, SecurityAlert, AlertStatus } from '../types/index.ts';
import { SeverityBadge } from '../components/common/StatCard.tsx';
import { calculateRiskScore, correlateMitre } from '../utils/detection.ts';

export const ThreatDetection: React.FC = () => {
  const [rules, setRules] = useState<DetectionRule[]>([
    {
      id: 'rule-01',
      name: 'Brute Force Authentication Burst (Rule 101)',
      description: 'Triggers when >= 5 failed Kerberos or NTLM logins occur within 60s from single source IP.',
      category: 'AUTH_ANOMALY',
      severity: 'CRITICAL',
      enabled: true,
      thresholdCount: 5,
      timeWindowSeconds: 60,
      mitreId: 'T1110',
      matchedCount: 28,
      lastTriggered: '2m ago',
    },
    {
      id: 'rule-02',
      name: 'Suspicious Office Child Process (Rule 204)',
      description: 'Flags execution of PowerShell, cmd.exe, or wscript.exe spawned directly from Microsoft Office.',
      category: 'MALWARE_BEHAVIOR',
      severity: 'CRITICAL',
      enabled: true,
      thresholdCount: 1,
      timeWindowSeconds: 10,
      mitreId: 'T1059.001',
      matchedCount: 3,
      lastTriggered: '5m ago',
    },
    {
      id: 'rule-03',
      name: 'High Velocity Port Sweep (Rule 302)',
      description: 'Detects sequential SYN packets across > 100 ports within 5 seconds.',
      category: 'NETWORK_INTRUSION',
      severity: 'MEDIUM',
      enabled: true,
      thresholdCount: 100,
      timeWindowSeconds: 5,
      mitreId: 'T1046',
      matchedCount: 64,
      lastTriggered: '12m ago',
    },
    {
      id: 'rule-04',
      name: 'OWASP SQL Injection Signature Match (Rule 401)',
      description: 'WAF Core Rule Set filter for SQL UNION/Comment payloads in HTTP GET/POST queries.',
      category: 'DATA_EXFILTRATION',
      severity: 'HIGH',
      enabled: true,
      thresholdCount: 1,
      timeWindowSeconds: 1,
      mitreId: 'T1190',
      matchedCount: 14,
      lastTriggered: '25m ago',
    },
    {
      id: 'rule-05',
      name: 'DNS Tunneling Entropy Anomaly (Rule 502)',
      description: 'Flags excessive Shannon entropy (> 4.5) in DNS TXT queries suggesting data exfiltration.',
      category: 'DATA_EXFILTRATION',
      severity: 'HIGH',
      enabled: true,
      thresholdCount: 10,
      timeWindowSeconds: 120,
      mitreId: 'T1041',
      matchedCount: 6,
      lastTriggered: '40m ago',
    },
  ]);

  // Test sandbox state
  const [testEventType, setTestEventType] = useState('AUTH_FAILURE_BURST');
  const [testSeverity, setTestSeverity] = useState<Severity>('CRITICAL');
  const [testMessage, setTestMessage] = useState('Repeated failed pre-auth attempts from untrusted IP');
  const [testResult, setTestResult] = useState<any>(null);

  const toggleRule = (ruleId: string) => {
    setRules(
      rules.map((r) => (r.id === ruleId ? { ...r, enabled: !r.enabled } : r))
    );
  };

  const handleRunTest = () => {
    const risk = calculateRiskScore({
      baseSeverity: testSeverity,
      assetCriticality: 'TIER_1_CRITICAL',
      hasKnownBadIoc: true,
      iocReputationScore: 88,
      eventFrequencyPerHour: 15,
      unauthorizedAccessAttempt: true,
    });
    const mitre = correlateMitre(testEventType, testMessage);
    setTestResult({ risk, mitre });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold tracking-tight text-[#E8EEF9]">Threat Detection Engine</h1>
        <p className="text-xs text-[#8C9CB5] mt-0.5">
          Hybrid detection architecture: Rule-based heuristics, statistical anomaly scoring, and MITRE ATT&CK taxonomy
        </p>
      </div>

      {/* Detection Architecture Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl bg-[#101B2D] border border-[#1A273D]">
          <div className="text-[11px] font-semibold text-[#8C9CB5] uppercase mb-1 flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-[#45D6C5]" />
            <span>Rule Engine</span>
          </div>
          <div className="text-lg font-bold font-mono text-[#E8EEF9]">5 Active Rules</div>
          <p className="text-[11px] text-[#8C9CB5] mt-1">High-speed regex & threshold matchers</p>
        </div>

        <div className="p-4 rounded-xl bg-[#101B2D] border border-[#1A273D]">
          <div className="text-[11px] font-semibold text-[#8C9CB5] uppercase mb-1 flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-[#438CFF]" />
            <span>Anomaly Scoring</span>
          </div>
          <div className="text-lg font-bold font-mono text-[#E8EEF9]">Isolation Forest</div>
          <p className="text-[11px] text-[#8C9CB5] mt-1">Z-score frequency deviation baseline</p>
        </div>

        <div className="p-4 rounded-xl bg-[#101B2D] border border-[#1A273D]">
          <div className="text-[11px] font-semibold text-[#8C9CB5] uppercase mb-1 flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-[#E8AD4B]" />
            <span>MITRE ATT&CK</span>
          </div>
          <div className="text-lg font-bold font-mono text-[#E8EEF9]">v14 Enterprise</div>
          <p className="text-[11px] text-[#8C9CB5] mt-1">Tactics & technique correlation</p>
        </div>

        <div className="p-4 rounded-xl bg-[#101B2D] border border-[#1A273D]">
          <div className="text-[11px] font-semibold text-[#8C9CB5] uppercase mb-1 flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-[#42C99A]" />
            <span>Threat Intel Match</span>
          </div>
          <div className="text-lg font-bold font-mono text-[#E8EEF9]">VirusTotal & AbuseIPDB</div>
          <p className="text-[11px] text-[#8C9CB5] mt-1">Real-time indicator correlation</p>
        </div>
      </div>

      {/* Rules Table */}
      <div className="rounded-xl bg-[#101B2D] border border-[#1A273D] overflow-hidden">
        <div className="px-5 py-3.5 bg-[#0C1424] border-b border-[#1A273D] flex items-center justify-between">
          <h2 className="text-xs font-semibold text-[#E8EEF9]">Active Detection Rule Set</h2>
          <span className="text-[11px] font-mono text-[#8C9CB5]">{rules.length} Rules Configured</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#1A273D] text-[#8C9CB5] text-[11px]">
                <th className="py-3 px-4 font-medium">Status</th>
                <th className="py-3 px-4 font-medium">Rule Name & Logic</th>
                <th className="py-3 px-4 font-medium">Category</th>
                <th className="py-3 px-4 font-medium">Severity</th>
                <th className="py-3 px-4 font-medium">MITRE ID</th>
                <th className="py-3 px-4 font-medium text-right">Trigger Hits</th>
                <th className="py-3 px-4 font-medium text-right">Toggle</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1A273D]">
              {rules.map((rule) => (
                <tr key={rule.id} className="hover:bg-[#15233B]/40 transition-colors">
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span
                      className={`inline-flex items-center text-[10px] font-mono font-semibold px-2 py-0.5 rounded ${
                        rule.enabled
                          ? 'bg-[#42C99A]/15 text-[#42C99A] border border-[#42C99A]/30'
                          : 'bg-[#8C9CB5]/15 text-[#8C9CB5] border border-[#8C9CB5]/30'
                      }`}
                    >
                      {rule.enabled ? 'ACTIVE' : 'DISABLED'}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-semibold text-[#E8EEF9]">{rule.name}</div>
                    <div className="text-[11px] text-[#8C9CB5] mt-0.5">{rule.description}</div>
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-[#8C9CB5] whitespace-nowrap">
                    {rule.category}
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <SeverityBadge severity={rule.severity} />
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-[#45D6C5] whitespace-nowrap">
                    {rule.mitreId}
                  </td>
                  <td className="py-3 px-4 font-mono text-right text-[#E8EEF9]">
                    {rule.matchedCount}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => toggleRule(rule.id)}
                      className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
                        rule.enabled
                          ? 'bg-[#15233B] hover:bg-[#1E2D45] text-[#8C9CB5]'
                          : 'bg-[#45D6C5] text-[#080D18]'
                      }`}
                    >
                      {rule.enabled ? 'Disable' : 'Enable'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detection Sandbox Test Card */}
      <div className="p-5 rounded-xl bg-[#101B2D] border border-[#1A273D]">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-xs font-semibold text-[#E8EEF9]">Detection Engine Test Sandbox</h3>
            <p className="text-[11px] text-[#8C9CB5]">
              Simulate an incoming log payload to verify normalized risk scoring and MITRE correlation
            </p>
          </div>
          <button
            onClick={handleRunTest}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#45D6C5] hover:bg-[#38bcae] text-[#080D18] transition-colors"
          >
            <Play className="w-3.5 h-3.5" />
            <span>Evaluate Payload</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
          <div>
            <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Event Type</label>
            <input
              type="text"
              value={testEventType}
              onChange={(e) => setTestEventType(e.target.value)}
              className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs text-[#E8EEF9] outline-none"
            />
          </div>
          <div>
            <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Base Severity</label>
            <select
              value={testSeverity}
              onChange={(e) => setTestSeverity(e.target.value as Severity)}
              className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs text-[#E8EEF9] outline-none"
            >
              <option value="CRITICAL">CRITICAL</option>
              <option value="HIGH">HIGH</option>
              <option value="MEDIUM">MEDIUM</option>
              <option value="LOW">LOW</option>
            </select>
          </div>
          <div>
            <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Message Details</label>
            <input
              type="text"
              value={testMessage}
              onChange={(e) => setTestMessage(e.target.value)}
              className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs text-[#E8EEF9] outline-none"
            />
          </div>
        </div>

        {testResult && (
          <div className="p-4 rounded-lg bg-[#15233B] border border-[#45D6C5]/30 space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-[#E8EEF9]">Evaluation Output:</span>
              <span className="font-mono font-bold text-[#F05268]">
                Composite Risk Score: {testResult.risk.score}/100 ({testResult.risk.tier})
              </span>
            </div>
            <div className="text-[11px] text-[#8C9CB5]">
              MITRE Correlation: <span className="text-[#45D6C5] font-semibold">{testResult.mitre.id} - {testResult.mitre.name}</span> ({testResult.mitre.tactic})
            </div>
            <div className="text-[11px] text-[#8C9CB5]">
              Contributing Factors: {testResult.risk.factors.join(' · ')}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export const AlertManagement: React.FC<{
  alerts: SecurityAlert[];
  onSelectAlert: (alert: SecurityAlert) => void;
  onUpdateAlertStatus: (alertId: string, status: AlertStatus) => Promise<void>;
  onEscalateAlert: (alertId: string) => Promise<void>;
}> = ({ alerts, onSelectAlert, onUpdateAlertStatus, onEscalateAlert }) => {
  const [severityFilter, setSeverityFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [search, setSearch] = useState('');

  const filtered = alerts.filter((a) => {
    const matchesSev = severityFilter === 'ALL' || a.severity === severityFilter;
    const matchesStat = statusFilter === 'ALL' || a.status === statusFilter;
    const matchesSearch =
      search === '' ||
      a.title.toLowerCase().includes(search.toLowerCase()) ||
      a.detectionReason.toLowerCase().includes(search.toLowerCase()) ||
      (a.sourceIp && a.sourceIp.includes(search));
    return matchesSev && matchesStat && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#E8EEF9]">Alert Management</h1>
          <p className="text-xs text-[#8C9CB5] mt-0.5">
            Triage, investigate, assign, and escalate security detection alerts
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-[#8C9CB5]">
            Showing {filtered.length} of {alerts.length} alerts
          </span>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="p-4 rounded-xl bg-[#101B2D] border border-[#1A273D] grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div>
          <label htmlFor="search-alerts-input" className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Search Alerts</label>
          <input
            id="search-alerts-input"
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by title, IP, or rule..."
            className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs text-[#E8EEF9] outline-none focus:border-[#45D6C5]"
          />
        </div>

        <div>
          <label htmlFor="severity-filter-select" className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Severity</label>
          <select
            id="severity-filter-select"
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs text-[#E8EEF9] outline-none focus:border-[#45D6C5]"
          >
            <option value="ALL">All Severities</option>
            <option value="CRITICAL">Critical</option>
            <option value="HIGH">High</option>
            <option value="MEDIUM">Medium</option>
            <option value="LOW">Low</option>
          </select>
        </div>

        <div>
          <label htmlFor="status-filter-select" className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Status</label>
          <select
            id="status-filter-select"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs text-[#E8EEF9] outline-none focus:border-[#45D6C5]"
          >
            <option value="ALL">All Statuses</option>
            <option value="NEW">New</option>
            <option value="OPEN">Open</option>
            <option value="INVESTIGATING">Investigating</option>
            <option value="ESCALATED">Escalated</option>
            <option value="RESOLVED">Resolved</option>
            <option value="FALSE_POSITIVE">False Positive</option>
          </select>
        </div>
      </div>

      {/* Alerts Table */}
      <div className="rounded-xl bg-[#101B2D] border border-[#1A273D] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#1A273D] bg-[#0C1424] text-[#8C9CB5] text-[11px]">
                <th className="py-3 px-4 font-medium">Alert ID</th>
                <th className="py-3 px-4 font-medium">Severity</th>
                <th className="py-3 px-4 font-medium">Risk</th>
                <th className="py-3 px-4 font-medium">Alert Title & Reason</th>
                <th className="py-3 px-4 font-medium">Source IP</th>
                <th className="py-3 px-4 font-medium">Assigned To</th>
                <th className="py-3 px-4 font-medium">Status</th>
                <th className="py-3 px-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1A273D]">
              {filtered.map((alert) => (
                <tr
                  key={alert.id}
                  onClick={() => onSelectAlert(alert)}
                  className="hover:bg-[#15233B] transition-colors cursor-pointer"
                >
                  <td className="py-3 px-4 font-mono text-[11px] text-[#45D6C5] whitespace-nowrap">
                    {alert.id}
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <SeverityBadge severity={alert.severity} />
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-[11px] text-[#F05268] whitespace-nowrap">
                    {alert.riskScore}/100
                  </td>
                  <td className="py-3 px-4 max-w-sm">
                    <div className="font-semibold text-[#E8EEF9] truncate">{alert.title}</div>
                    <div className="text-[11px] text-[#8C9CB5] truncate mt-0.5">{alert.detectionReason}</div>
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-[#438CFF] whitespace-nowrap">
                    {alert.sourceIp || 'Internal'}
                  </td>
                  <td className="py-3 px-4 text-[#8C9CB5] whitespace-nowrap">
                    {alert.assignedToName || 'Unassigned'}
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span className="font-mono text-[11px] font-semibold text-[#E8EEF9]">
                      {alert.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => onSelectAlert(alert)}
                        className="px-2.5 py-1 rounded text-[11px] font-medium bg-[#15233B] hover:bg-[#1E2D45] text-[#45D6C5] border border-[#1A273D]"
                      >
                        Investigate
                      </button>
                      {alert.status !== 'ESCALATED' && alert.status !== 'RESOLVED' && (
                        <button
                          onClick={() => onEscalateAlert(alert.id)}
                          className="px-2.5 py-1 rounded text-[11px] font-medium bg-[#F05268]/20 hover:bg-[#F05268]/30 text-[#F05268] border border-[#F05268]/30"
                        >
                          Escalate
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-[#8C9CB5]">
                    No alerts found matching current filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
