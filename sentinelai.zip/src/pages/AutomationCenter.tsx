import React, { useState } from 'react';
import {
  Zap,
  Play,
  CheckCircle,
  XCircle,
  Clock,
  ShieldAlert,
  ArrowRight,
  GitBranch,
  RefreshCw,
  Sliders,
  Send,
  AlertTriangle,
} from 'lucide-react';
import { AutomationRun, Playbook } from '../types/index.ts';

export const AutomationCenter: React.FC<{
  runs: AutomationRun[];
  onApproveRun: (runId: string, decision: 'APPROVE' | 'REJECT', reason?: string) => Promise<any>;
  onExecutePlaybook: (playbookId: string) => Promise<any>;
}> = ({ runs, onApproveRun, onExecutePlaybook }) => {
  const [selectedRun, setSelectedRun] = useState<AutomationRun | null>(runs[0] || null);
  const [approvalReason, setApprovalReason] = useState('Approved after SOC analyst verification');
  const [isProcessing, setIsProcessing] = useState(false);

  const handleDecision = async (decision: 'APPROVE' | 'REJECT') => {
    if (!selectedRun) return;
    setIsProcessing(true);
    try {
      await onApproveRun(selectedRun.id, decision, approvalReason);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold tracking-tight text-[#E8EEF9]">Automation Center (SOAR)</h1>
        <p className="text-xs text-[#8C9CB5] mt-0.5">
          Asynchronous security playbook orchestrator, approval gatekeeper, and background task engine
        </p>
      </div>

      {/* Grid of Active Runs & Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Runs History List */}
        <div className="lg:col-span-7 space-y-3">
          <div className="p-4 rounded-xl bg-[#101B2D] border border-[#1A273D] flex items-center justify-between">
            <span className="text-xs font-semibold text-[#E8EEF9]">Recent Execution History</span>
            <span className="text-[11px] font-mono text-[#8C9CB5]">
              {runs.filter((r) => r.status === 'PENDING_APPROVAL').length} Pending Approval
            </span>
          </div>

          <div className="space-y-2.5">
            {runs.map((run) => (
              <div
                key={run.id}
                onClick={() => setSelectedRun(run)}
                className={`p-4 rounded-xl border transition-all cursor-pointer ${
                  selectedRun?.id === run.id
                    ? 'bg-[#15233B] border-[#45D6C5]'
                    : 'bg-[#101B2D] border-[#1A273D] hover:border-[#2D4263]'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <div className="font-semibold text-xs text-[#E8EEF9] truncate">{run.playbookName}</div>
                  <span
                    className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded whitespace-nowrap ${
                      run.status === 'PENDING_APPROVAL'
                        ? 'bg-[#E8AD4B]/20 text-[#E8AD4B] border border-[#E8AD4B]/30'
                        : run.status === 'COMPLETED'
                        ? 'bg-[#42C99A]/20 text-[#42C99A] border border-[#42C99A]/30'
                        : run.status === 'REJECTED'
                        ? 'bg-[#F05268]/20 text-[#F05268] border border-[#F05268]/30'
                        : 'bg-[#438CFF]/20 text-[#438CFF]'
                    }`}
                  >
                    {run.status.replace(/_/g, ' ')}
                  </span>
                </div>

                <div className="text-[11px] text-[#8C9CB5] font-mono truncate">{run.triggerPayload}</div>

                <div className="mt-2 pt-2 border-t border-[#1A273D] flex items-center justify-between text-[10px] text-[#8C9CB5]">
                  <span>Triggered by: {run.executedBy}</span>
                  <span>{new Date(run.startedAt).toLocaleTimeString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Execution Log & Approval Drawer */}
        <div className="lg:col-span-5 space-y-4">
          {selectedRun ? (
            <div className="p-5 rounded-xl bg-[#101B2D] border border-[#1A273D] space-y-4">
              <div>
                <div className="text-[11px] font-semibold text-[#8C9CB5] uppercase">Execution Details</div>
                <h3 className="text-sm font-semibold text-[#E8EEF9] mt-0.5">{selectedRun.playbookName}</h3>
                <div className="text-[11px] font-mono text-[#45D6C5] mt-1">Run ID: {selectedRun.id}</div>
              </div>

              {/* Execution Console Logs */}
              <div>
                <label className="block text-[11px] font-semibold text-[#8C9CB5] mb-1">Execution Telemetry Log</label>
                <div className="p-3 rounded-lg bg-[#0A101C] border border-[#1A273D] font-mono text-[11px] text-[#8C9CB5] space-y-1 max-h-48 overflow-y-auto">
                  {selectedRun.outputLogs.map((line, idx) => (
                    <div key={idx} className="text-[#E8EEF9]">{line}</div>
                  ))}
                </div>
              </div>

              {/* Approval Gate Actions */}
              {selectedRun.status === 'PENDING_APPROVAL' ? (
                <div className="p-4 rounded-xl bg-[#15233B] border border-[#E8AD4B]/30 space-y-3">
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#E8AD4B]">
                    <AlertTriangle className="w-4 h-4" />
                    <span>Analyst Approval Gate Required</span>
                  </div>
                  <p className="text-[11px] text-[#8C9CB5]">
                    This playbook contains non-reversible perimeter actions (e.g. Host isolation or Firewall ACL block).
                  </p>

                  <div>
                    <label className="block text-[11px] text-[#8C9CB5] mb-1 font-semibold">Approval Justification</label>
                    <input
                      type="text"
                      value={approvalReason}
                      onChange={(e) => setApprovalReason(e.target.value)}
                      className="w-full bg-[#101B2D] border border-[#1A273D] rounded-lg px-2.5 py-1.5 text-xs text-[#E8EEF9] outline-none"
                    />
                  </div>

                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={() => handleDecision('APPROVE')}
                      disabled={isProcessing}
                      className="flex-1 py-1.5 rounded-lg text-xs font-semibold bg-[#42C99A] hover:bg-[#38bcae] text-[#080D18] transition-colors"
                    >
                      Authorize Execution
                    </button>
                    <button
                      onClick={() => handleDecision('REJECT')}
                      disabled={isProcessing}
                      className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-[#F05268]/20 hover:bg-[#F05268]/30 text-[#F05268] border border-[#F05268]/30 transition-colors"
                    >
                      Deny
                    </button>
                  </div>
                </div>
              ) : selectedRun.approvalDetails ? (
                <div className="p-3 rounded-lg bg-[#15233B] border border-[#1A273D] text-xs space-y-1">
                  <span className="font-semibold text-[#42C99A]">
                    {selectedRun.status === 'COMPLETED' ? '✓ Authorized & Executed' : '✗ Denied'}
                  </span>
                  <div className="text-[11px] text-[#8C9CB5]">
                    Operator: {selectedRun.approvalDetails.approvedBy} · Reason: {selectedRun.approvalDetails.reason}
                  </div>
                </div>
              ) : null}
            </div>
          ) : (
            <div className="p-8 rounded-xl bg-[#101B2D] border border-[#1A273D] text-center text-[#8C9CB5] text-xs">
              Select an automation run from the list to view step logs and authorization status.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export const PlaybookManagement: React.FC<{
  playbooks: Playbook[];
  onExecutePlaybook: (playbookId: string) => Promise<any>;
}> = ({ playbooks, onExecutePlaybook }) => {
  const [executingId, setExecutingId] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  const handleRun = async (playbookId: string, name: string) => {
    setExecutingId(playbookId);
    setSuccessNotice(null);
    try {
      await onExecutePlaybook(playbookId);
      setSuccessNotice(`Playbook "${name}" executed. Check Automation Center for background run logs.`);
    } finally {
      setExecutingId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold tracking-tight text-[#E8EEF9]">SOAR Playbook Management</h1>
        <p className="text-xs text-[#8C9CB5] mt-0.5">
          Configured response playbooks with sequential workflow steps, approval boundaries, and audit verification
        </p>
      </div>

      {successNotice && (
        <div className="p-3 rounded-xl bg-[#42C99A]/15 border border-[#42C99A]/30 text-xs text-[#42C99A] flex items-center gap-2">
          <CheckCircle className="w-4 h-4" />
          <span>{successNotice}</span>
        </div>
      )}

      {/* Playbooks Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {playbooks.map((pb) => (
          <div
            key={pb.id}
            className="p-5 rounded-xl bg-[#101B2D] border border-[#1A273D] space-y-4 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-[#1A273D] text-[#45D6C5]">
                  {pb.category}
                </span>
                <span className="text-[11px] font-mono text-[#8C9CB5]">
                  Executed {pb.executionCount} times
                </span>
              </div>
              <h3 className="text-sm font-semibold text-[#E8EEF9]">{pb.name}</h3>
              <p className="text-xs text-[#8C9CB5] mt-1">{pb.description}</p>
            </div>

            {/* Workflow Steps Preview */}
            <div className="p-3 rounded-lg bg-[#0C1424] border border-[#1A273D] space-y-2">
              <span className="text-[10px] font-semibold text-[#8C9CB5] uppercase tracking-wider block">
                Workflow Actions Sequence:
              </span>
              <div className="space-y-1.5">
                {pb.steps.map((step) => (
                  <div
                    key={step.order}
                    className="flex items-center gap-2 text-[11px] text-[#E8EEF9]"
                  >
                    <span className="w-4 h-4 rounded-full bg-[#15233B] text-[#45D6C5] flex items-center justify-center font-mono text-[9px] shrink-0 font-bold">
                      {step.order}
                    </span>
                    <span className="truncate flex-1">{step.name}</span>
                    <span className="font-mono text-[9px] text-[#8C9CB5] uppercase">{step.actionType}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Footer Execution Button */}
            <div className="pt-2 border-t border-[#1A273D] flex items-center justify-between">
              <span className="text-[11px] text-[#E8AD4B] font-mono">
                {pb.requiresApproval ? 'Requires Analyst Approval' : 'Autonomous Action'}
              </span>
              <button
                onClick={() => handleRun(pb.id, pb.name)}
                disabled={executingId === pb.id}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#45D6C5] hover:bg-[#38bcae] text-[#080D18] transition-colors disabled:opacity-50"
              >
                <Play className="w-3.5 h-3.5" />
                <span>{executingId === pb.id ? 'Starting...' : 'Execute Playbook'}</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
