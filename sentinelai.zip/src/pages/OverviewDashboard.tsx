import React, { useState } from 'react';
import {
  ShieldAlert,
  AlertTriangle,
  LifeBuoy,
  Database,
  Server,
  Zap,
  ArrowUpRight,
  TrendingUp,
  Bot,
  RefreshCw,
  ExternalLink,
  ShieldCheck,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell,
  PieChart,
  Pie,
} from 'recharts';
import { StatCard, SeverityBadge, StatusBadge } from '../components/common/StatCard.tsx';
import { SecurityAlert, SecurityIncident } from '../types/index.ts';

interface OverviewDashboardProps {
  summaryMetrics: any;
  trendsData: any;
  alerts: SecurityAlert[];
  incidents: SecurityIncident[];
  onNavigate: (moduleKey: any) => void;
  onSelectAlert: (alert: SecurityAlert) => void;
  onSelectIncident: (incident: SecurityIncident) => void;
}

export const OverviewDashboard: React.FC<OverviewDashboardProps> = ({
  summaryMetrics,
  trendsData,
  alerts,
  incidents,
  onNavigate,
  onSelectAlert,
  onSelectIncident,
}) => {
  const [timeRange, setTimeRange] = useState('24h');
  const [isGeneratingAiSummary, setIsGeneratingAiSummary] = useState(false);
  const [aiSummaryText, setAiSummaryText] = useState(
    'SentinelAI Copilot Daily Briefing: Current security posture indicates elevated perimeter activity targeting Domain Controller DC-01 via Kerberos brute force. Workstation ws-exec-cfo has been safely isolated following phishing triage. Overall threat velocity is contained with 2 critical alerts pending final analyst review.'
  );

  const handleRegenerateSummary = async () => {
    setIsGeneratingAiSummary(true);
    try {
      const res = await fetch('/api/v1/ai/investigate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ promptContext: 'Generate an executive daily security operational briefing.' }),
      });
      const data = await res.json();
      if (data.investigation?.summary) {
        setAiSummaryText(`Executive AI Briefing: ${data.investigation.summary} Recommended priority: ${data.investigation.recommended_actions?.[0]?.step || 'Complete containment review'}`);
      }
    } catch {
      // Fallback
    } finally {
      setIsGeneratingAiSummary(false);
    }
  };

  const metrics = summaryMetrics?.metrics || {
    totalEvents: 148920,
    totalAlerts: 4,
    criticalAlerts: 2,
    highRiskAlerts: 1,
    openIncidents: 2,
    resolvedIncidents: 0,
    threatIndicatorsCount: 4,
    monitoredAssetsCount: 5,
    vulnerabilitiesDetected: 3,
    automationExecutions: 42,
  };

  const eventsData = trendsData?.eventsOverTime || [
    { time: '00:00', events: 12400, anomalies: 12 },
    { time: '04:00', events: 8900, anomalies: 8 },
    { time: '08:00', events: 24500, anomalies: 34 },
    { time: '12:00', events: 38200, anomalies: 52 },
    { time: '16:00', events: 41900, anomalies: 68 },
    { time: '20:00', events: 23000, anomalies: 28 },
  ];

  const severityData = trendsData?.severityDistribution || [
    { name: 'Critical', value: 2, color: '#F05268' },
    { name: 'High', value: 1, color: '#FF754C' },
    { name: 'Medium', value: 1, color: '#E8AD4B' },
    { name: 'Low', value: 0, color: '#438CFF' },
  ];

  const threatClassData = trendsData?.threatClassification || [
    { category: 'Credential Access', count: 18 },
    { category: 'Command & Control', count: 12 },
    { category: 'Initial Access', count: 9 },
    { category: 'Network Discovery', count: 15 },
    { category: 'Exfiltration', count: 4 },
  ];

  return (
    <div className="space-y-6">
      {/* Page Title & Time Range Filter */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#E8EEF9]">
            Security Operations Center Overview
          </h1>
          <p className="text-xs text-[#8C9CB5] mt-0.5">
            Real-time threat monitoring, telemetry aggregation, and automated defense posture
          </p>
        </div>

        {/* Time Range Filter Buttons */}
        <div className="flex items-center gap-1 p-1 bg-[#101B2D] border border-[#1A273D] rounded-lg">
          {['1h', '24h', '7d', '30d'].map((range) => (
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={`px-3 py-1 text-xs font-mono font-medium rounded-md transition-colors ${
                timeRange === range
                  ? 'bg-[#15233B] text-[#45D6C5] shadow-sm'
                  : 'text-[#8C9CB5] hover:text-[#E8EEF9]'
              }`}
            >
              {range.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* 10 Summary Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <StatCard
          label="Security Events"
          value={metrics.totalEvents}
          subtext="Processed past 24h"
          trend="+12.4%"
          trendDirection="up"
          icon={TrendingUp}
          accentColor="#438CFF"
          onClick={() => onNavigate('logs')}
        />
        <StatCard
          label="Total Alerts"
          value={metrics.totalAlerts}
          subtext="Requiring investigation"
          trend="+2 new"
          trendDirection="neutral"
          icon={AlertTriangle}
          accentColor="#E8AD4B"
          onClick={() => onNavigate('alerts')}
        />
        <StatCard
          label="Critical Alerts"
          value={metrics.criticalAlerts}
          subtext="P0/P1 immediate action"
          trend="Action required"
          trendDirection="up"
          icon={ShieldAlert}
          accentColor="#F05268"
          onClick={() => onNavigate('alerts')}
        />
        <StatCard
          label="Open Incidents"
          value={metrics.openIncidents}
          subtext="Active incident response"
          icon={LifeBuoy}
          accentColor="#FF754C"
          onClick={() => onNavigate('incidents')}
        />
        <StatCard
          label="Active IOCs"
          value={metrics.threatIndicatorsCount}
          subtext="Known bad indicators"
          icon={Database}
          accentColor="#45D6C5"
          onClick={() => onNavigate('intel')}
        />
        <StatCard
          label="Monitored Assets"
          value={metrics.monitoredAssetsCount}
          subtext="Authorized scope"
          icon={Server}
          accentColor="#42C99A"
          onClick={() => onNavigate('assets')}
        />
        <StatCard
          label="Detected Vulnerabilities"
          value={metrics.vulnerabilitiesDetected}
          subtext="CVE findings open"
          icon={AlertTriangle}
          accentColor="#E8AD4B"
          onClick={() => onNavigate('vulnerabilities')}
        />
        <StatCard
          label="SOAR Executions"
          value={metrics.automationExecutions}
          subtext="Playbook runs executed"
          trend="98% automated"
          trendDirection="down"
          icon={Zap}
          accentColor="#A070FF"
          onClick={() => onNavigate('automation')}
        />
        <StatCard
          label="High Risk Alerts"
          value={metrics.highRiskAlerts}
          subtext="Triage queue"
          icon={ShieldAlert}
          accentColor="#FF754C"
          onClick={() => onNavigate('alerts')}
        />
        <StatCard
          label="System Posture"
          value="98.2%"
          subtext="Perimeter Integrity"
          trend="Nominal"
          trendDirection="down"
          icon={ShieldCheck}
          accentColor="#42C99A"
          onClick={() => onNavigate('settings')}
        />
      </div>

      {/* AI Daily Security Summary Box */}
      <div className="p-4 rounded-xl bg-gradient-to-r from-[#101B2D] to-[#15233B] border border-[#45D6C5]/30">
        <div className="flex items-center justify-between gap-3 mb-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#45D6C5]">
            <Bot className="w-4 h-4" />
            <span>SentinelAI Copilot · Daily Threat Synthesis</span>
          </div>
          <button
            onClick={handleRegenerateSummary}
            disabled={isGeneratingAiSummary}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-medium bg-[#101B2D] hover:bg-[#1E2D45] text-[#8C9CB5] hover:text-[#E8EEF9] border border-[#1A273D] transition-colors"
          >
            <RefreshCw className={`w-3 h-3 ${isGeneratingAiSummary ? 'animate-spin text-[#45D6C5]' : ''}`} />
            <span>{isGeneratingAiSummary ? 'Analyzing...' : 'Regenerate'}</span>
          </button>
        </div>
        <p className="text-xs text-[#E8EEF9] leading-relaxed">{aiSummaryText}</p>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Event Velocity Chart */}
        <div className="lg:col-span-2 p-5 rounded-xl bg-[#101B2D] border border-[#1A273D]">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xs font-semibold text-[#E8EEF9]">Security Event Velocity & Anomalies</h3>
              <p className="text-[11px] text-[#8C9CB5]">Ingested events vs detected threshold deviations over time</p>
            </div>
            <span className="text-[11px] font-mono text-[#45D6C5]">Live Telemetry</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={eventsData}>
                <defs>
                  <linearGradient id="colorEvents" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#438CFF" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#438CFF" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="time" stroke="#8C9CB5" fontSize={11} tickLine={false} />
                <YAxis stroke="#8C9CB5" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0C1424', borderColor: '#1A273D', borderRadius: '8px', fontSize: '11px' }}
                />
                <Area type="monotone" dataKey="events" stroke="#438CFF" fillOpacity={1} fill="url(#colorEvents)" name="Total Events" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Severity Distribution */}
        <div className="p-5 rounded-xl bg-[#101B2D] border border-[#1A273D] flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-semibold text-[#E8EEF9] mb-1">Alerts by Severity</h3>
            <p className="text-[11px] text-[#8C9CB5] mb-4">Distribution of active triage queue</p>
            <div className="h-44 w-full flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={severityData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={65}
                    paddingAngle={4}
                  >
                    {severityData.map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0C1424', borderColor: '#1A273D', borderRadius: '8px', fontSize: '11px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-[#1A273D]">
            {severityData.map((item: any) => (
              <div key={item.name} className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-1.5 text-[#8C9CB5]">
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                  {item.name}
                </span>
                <span className="font-mono font-semibold text-[#E8EEF9]">{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tables: Top Suspicious IPs & Recent Critical Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Recent Alerts */}
        <div className="p-5 rounded-xl bg-[#101B2D] border border-[#1A273D]">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-xs font-semibold text-[#E8EEF9]">Active Priority Alerts</h3>
              <p className="text-[11px] text-[#8C9CB5]">High confidence alerts requiring investigation</p>
            </div>
            <button
              onClick={() => onNavigate('alerts')}
              className="text-xs text-[#45D6C5] hover:underline flex items-center gap-1 font-medium"
            >
              <span>View All</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2.5">
            {alerts.slice(0, 4).map((alert) => (
              <div
                key={alert.id}
                onClick={() => onSelectAlert(alert)}
                className="p-3 rounded-lg bg-[#15233B] border border-[#1A273D] hover:border-[#45D6C5]/40 transition-colors cursor-pointer"
              >
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-2">
                    <SeverityBadge severity={alert.severity} />
                    <span className="text-xs font-medium text-[#E8EEF9] truncate">{alert.title}</span>
                  </div>
                  <span className="text-[11px] font-mono font-bold text-[#F05268]">{alert.riskScore}/100</span>
                </div>
                <div className="flex items-center justify-between text-[11px] text-[#8C9CB5]">
                  <span>Rule: {alert.ruleName}</span>
                  <StatusBadge status={alert.status} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Suspicious IPs */}
        <div className="p-5 rounded-xl bg-[#101B2D] border border-[#1A273D]">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-xs font-semibold text-[#E8EEF9]">Top Suspicious IP Indicators</h3>
              <p className="text-[11px] text-[#8C9CB5]">Repeated connection anomalies observed at perimeter</p>
            </div>
            <button
              onClick={() => onNavigate('intel')}
              className="text-xs text-[#45D6C5] hover:underline flex items-center gap-1 font-medium"
            >
              <span>Threat Intel</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#1A273D] text-[#8C9CB5] text-[11px]">
                  <th className="pb-2 font-medium">IP Address</th>
                  <th className="pb-2 font-medium">Origin Country</th>
                  <th className="pb-2 font-medium text-right">Anomalous Hits</th>
                  <th className="pb-2 font-medium text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1A273D]">
                {(summaryMetrics?.topSuspiciousIps || [
                  { ip: '185.220.101.5', attempts: 142, threatLevel: 'CRITICAL', geo: 'Netherlands' },
                  { ip: '194.26.29.112', attempts: 89, threatLevel: 'HIGH', geo: 'Russia' },
                  { ip: '45.154.255.89', attempts: 64, threatLevel: 'MEDIUM', geo: 'Russia' },
                  { ip: '103.145.13.2', attempts: 37, threatLevel: 'MEDIUM', geo: 'Singapore' },
                ]).map((item: any) => (
                  <tr key={item.ip} className="hover:bg-[#15233B]/50 transition-colors">
                    <td className="py-2.5 font-mono text-[#E8EEF9]">{item.ip}</td>
                    <td className="py-2.5 text-[#8C9CB5]">{item.geo}</td>
                    <td className="py-2.5 font-mono text-right text-[#F05268]">{item.attempts}</td>
                    <td className="py-2.5 text-right">
                      <button
                        onClick={() => onNavigate('intel')}
                        className="text-[11px] text-[#45D6C5] hover:underline font-medium"
                      >
                        Enrich
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
