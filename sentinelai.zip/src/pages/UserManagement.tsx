import React, { useState } from 'react';
import { Users, Plus, ShieldCheck, UserCheck, Shield, Key, Search, Download } from 'lucide-react';
import { User, UserRole, AuditLogEntry } from '../types/index.ts';

export const UserManagement: React.FC<{
  users: User[];
  onAddUser: (data: any) => Promise<any>;
  onUpdateUser: (userId: string, data: any) => Promise<any>;
}> = ({ users, onAddUser, onUpdateUser }) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<UserRole>('SECURITY_ANALYST');

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email) return;
    await onAddUser({ name, email, role });
    setName('');
    setEmail('');
    setShowAddModal(false);
  };

  const handleToggleStatus = (u: User) => {
    const nextStatus = u.status === 'ACTIVE' ? 'SUSPENDED' : 'ACTIVE';
    onUpdateUser(u.id, { status: nextStatus });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#E8EEF9]">User Management & Access Control</h1>
          <p className="text-xs text-[#8C9CB5] mt-0.5">
            Role-Based Access Control (RBAC), multi-factor enforcement, and session privileges
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#45D6C5] hover:bg-[#38bcae] text-[#080D18] transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Operator</span>
        </button>
      </div>

      {/* RBAC Matrix Explainer */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl bg-[#101B2D] border border-[#1A273D] text-xs">
          <div className="font-semibold text-[#E8EEF9] mb-1">ADMIN</div>
          <p className="text-[11px] text-[#8C9CB5]">Full access: configure integrations, manage users, approve all SOAR playbooks.</p>
        </div>
        <div className="p-3.5 rounded-xl bg-[#101B2D] border border-[#1A273D] text-xs">
          <div className="font-semibold text-[#45D6C5] mb-1">SECURITY ANALYST</div>
          <p className="text-[11px] text-[#8C9CB5]">Investigate alerts, declare incidents, run authorized scans, generate reports.</p>
        </div>
        <div className="p-3.5 rounded-xl bg-[#101B2D] border border-[#1A273D] text-xs">
          <div className="font-semibold text-[#E8AD4B] mb-1">SOC MANAGER</div>
          <p className="text-[11px] text-[#8C9CB5]">Review operational dashboards, assign incidents, approve perimeter containment.</p>
        </div>
        <div className="p-3.5 rounded-xl bg-[#101B2D] border border-[#1A273D] text-xs">
          <div className="font-semibold text-[#8C9CB5] mb-1">VIEWER</div>
          <p className="text-[11px] text-[#8C9CB5]">Read-only access: view dashboards, incidents, and export compliance reports.</p>
        </div>
      </div>

      {/* Users Table */}
      <div className="rounded-xl bg-[#101B2D] border border-[#1A273D] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#1A273D] bg-[#0C1424] text-[#8C9CB5] text-[11px]">
                <th className="py-3 px-4 font-medium">User Profile</th>
                <th className="py-3 px-4 font-medium">Role</th>
                <th className="py-3 px-4 font-medium">MFA Security</th>
                <th className="py-3 px-4 font-medium">Last Active</th>
                <th className="py-3 px-4 font-medium">Status</th>
                <th className="py-3 px-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1A273D]">
              {users.map((u) => (
                <tr key={u.id} className="hover:bg-[#15233B]/40 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-semibold text-[#E8EEF9]">{u.name}</div>
                    <div className="text-[11px] text-[#8C9CB5] font-mono">{u.email}</div>
                  </td>
                  <td className="py-3 px-4">
                    <select
                      value={u.role}
                      onChange={(e) => onUpdateUser(u.id, { role: e.target.value })}
                      className="bg-[#15233B] border border-[#1A273D] rounded px-2 py-1 text-xs text-[#E8EEF9] font-mono outline-none"
                    >
                      <option value="ADMIN">ADMIN</option>
                      <option value="SECURITY_ANALYST">SECURITY_ANALYST</option>
                      <option value="SOC_MANAGER">SOC_MANAGER</option>
                      <option value="VIEWER">VIEWER</option>
                    </select>
                  </td>
                  <td className="py-3 px-4">
                    <span className="inline-flex items-center gap-1 text-[11px] font-mono text-[#42C99A]">
                      <Key className="w-3 h-3" /> Hardware Token
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-[#8C9CB5]">
                    {new Date(u.lastLogin).toLocaleTimeString()}
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded ${
                        u.status === 'ACTIVE'
                          ? 'bg-[#42C99A]/15 text-[#42C99A]'
                          : 'bg-[#F05268]/15 text-[#F05268]'
                      }`}
                    >
                      {u.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => handleToggleStatus(u)}
                      className="px-2.5 py-1 rounded text-[11px] font-medium bg-[#15233B] hover:bg-[#1E2D45] text-[#8C9CB5] hover:text-[#E8EEF9] border border-[#1A273D]"
                    >
                      {u.status === 'ACTIVE' ? 'Suspend' : 'Activate'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add User Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[#101B2D] border border-[#1A273D] rounded-2xl p-6 space-y-4">
            <h3 className="text-sm font-semibold text-[#E8EEF9]">Invite New Security Operator</h3>
            <form onSubmit={handleAdd} className="space-y-3 text-xs">
              <div>
                <label className="block text-[#8C9CB5] mb-1 font-semibold">Full Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Rachel Torres"
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-2 text-[#E8EEF9] outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-[#8C9CB5] mb-1 font-semibold">Corporate Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="rachel.torres@sentinelai.internal"
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-2 text-[#E8EEF9] font-mono outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-[#8C9CB5] mb-1 font-semibold">Assigned Role</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as any)}
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-2 text-[#E8EEF9] outline-none"
                >
                  <option value="SECURITY_ANALYST">Security Analyst</option>
                  <option value="SOC_MANAGER">SOC Manager</option>
                  <option value="ADMIN">System Administrator</option>
                  <option value="VIEWER">Viewer</option>
                </select>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg text-[#8C9CB5]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-[#45D6C5] text-[#080D18] font-semibold"
                >
                  Create User
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export const AuditLogs: React.FC<{
  logs: AuditLogEntry[];
}> = ({ logs }) => {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');

  const filtered = logs.filter((l) => {
    const matchesCat = selectedCategory === 'ALL' || l.category === selectedCategory;
    const matchesSearch =
      search === '' ||
      l.action.toLowerCase().includes(search.toLowerCase()) ||
      l.details.toLowerCase().includes(search.toLowerCase()) ||
      l.userName.toLowerCase().includes(search.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const exportAuditCsv = () => {
    const headers = 'ID,Timestamp,User,Category,Action,Details,IP,Status\n';
    const rows = filtered
      .map(
        (l) =>
          `"${l.id}","${l.timestamp}","${l.userName}","${l.category}","${l.action}","${l.details.replace(/"/g, '""')}","${l.ipAddress}","${l.status}"`
      )
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sentinelai-audit-log-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#E8EEF9]">Audit Trail & Governance</h1>
          <p className="text-xs text-[#8C9CB5] mt-0.5">
            Immutable, append-only record of all authentication, triage decisions, and configuration modifications
          </p>
        </div>

        <button
          onClick={exportAuditCsv}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#101B2D] hover:bg-[#15233B] text-[#E8EEF9] border border-[#1A273D] transition-colors"
        >
          <Download className="w-3.5 h-3.5 text-[#45D6C5]" />
          <span>Export Audit CSV</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="p-4 rounded-xl bg-[#101B2D] border border-[#1A273D] flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-[#8C9CB5] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search audit actions, users, or event details..."
            className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg pl-9 pr-3 py-1.5 text-xs text-[#E8EEF9] outline-none focus:border-[#45D6C5]"
          />
        </div>

        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs text-[#E8EEF9] outline-none"
        >
          <option value="ALL">All Categories</option>
          <option value="AUTH">Authentication</option>
          <option value="ALERT_MODIFIED">Alert Modified</option>
          <option value="INCIDENT_ACTION">Incident Action</option>
          <option value="PLAYBOOK_EXECUTED">Playbook Executed</option>
          <option value="SETTINGS_CHANGED">Settings Changed</option>
          <option value="REPORT_EXPORTED">Report Exported</option>
        </select>
      </div>

      {/* Audit Log Table */}
      <div className="rounded-xl bg-[#101B2D] border border-[#1A273D] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#1A273D] bg-[#0C1424] text-[#8C9CB5] text-[11px]">
                <th className="py-3 px-4 font-medium">Timestamp</th>
                <th className="py-3 px-4 font-medium">Operator</th>
                <th className="py-3 px-4 font-medium">Category</th>
                <th className="py-3 px-4 font-medium">Action</th>
                <th className="py-3 px-4 font-medium">Details</th>
                <th className="py-3 px-4 font-medium">IP Address</th>
                <th className="py-3 px-4 font-medium text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1A273D]">
              {filtered.map((entry) => (
                <tr key={entry.id} className="hover:bg-[#15233B]/40 transition-colors">
                  <td className="py-3 px-4 font-mono text-[11px] text-[#8C9CB5] whitespace-nowrap">
                    {new Date(entry.timestamp).toLocaleString()}
                  </td>
                  <td className="py-3 px-4 font-semibold text-[#E8EEF9] whitespace-nowrap">
                    {entry.userName}
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-[#45D6C5] whitespace-nowrap">
                    {entry.category}
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-[#E8EEF9] whitespace-nowrap">
                    {entry.action}
                  </td>
                  <td className="py-3 px-4 text-[#8C9CB5] max-w-sm truncate">{entry.details}</td>
                  <td className="py-3 px-4 font-mono text-[11px] text-[#8C9CB5] whitespace-nowrap">
                    {entry.ipAddress}
                  </td>
                  <td className="py-3 px-4 text-right whitespace-nowrap">
                    <span className="font-mono text-[11px] text-[#42C99A] font-semibold">
                      {entry.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
