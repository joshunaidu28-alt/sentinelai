import React, { useState } from 'react';
import {
  Mail,
  ShieldAlert,
  Search,
  CheckCircle,
  AlertTriangle,
  ExternalLink,
  Lock,
  Globe,
  Ban,
  Inbox,
  Sparkles,
} from 'lucide-react';
import { PhishingAnalysis } from '../types/index.ts';

interface PhishingDetectionProps {
  history: PhishingAnalysis[];
  onAnalyzePhishing: (data: any) => Promise<any>;
}

export const PhishingDetection: React.FC<PhishingDetectionProps> = ({ history, onAnalyzePhishing }) => {
  const [url, setUrl] = useState('http://billing-portal-chase-update.xyz/login?session=exp');
  const [sender, setSender] = useState('billing-alert@chase-support-services.xyz');
  const [subject, setSubject] = useState('Urgent Wire Instruction Update - Overdue Notice');
  const [bodyText, setBodyText] = useState(
    'Dear Customer, Immediate action required. Your account is suspended due to billing failure. Verify your credentials and update billing info immediately to unlock access.'
  );
  const [headers, setHeaders] = useState('Received: from mail.chase-support-services.xyz SPF: fail DKIM: none');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentResult, setCurrentResult] = useState<PhishingAnalysis | null>(history[0] || null);
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsAnalyzing(true);
    setActionNotice(null);
    try {
      const res = await onAnalyzePhishing({ url, sender, subject, bodyText, headers });
      if (res?.result) {
        setCurrentResult(res.result);
      }
    } catch {
      // Handled
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSimulateContainment = (action: string) => {
    setActionNotice(`Containment executed: ${action}. Rule synced to perimeter firewalls and Exchange mailbox gateway.`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold tracking-tight text-[#E8EEF9]">
          PhishGuard AI · Phishing & URL Analysis
        </h1>
        <p className="text-xs text-[#8C9CB5] mt-0.5">
          Heuristic brand typosquatting scanner, domain reputation analysis, and email authentication validator
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Input Form */}
        <div className="lg:col-span-5 p-5 rounded-xl bg-[#101B2D] border border-[#1A273D] space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-semibold text-[#E8EEF9] flex items-center gap-2">
              <Mail className="w-4 h-4 text-[#45D6C5]" />
              <span>Inspect Suspicious Artifact</span>
            </h2>
            <span className="text-[10px] text-[#42C99A] font-mono">Sandbox Isolation Mode</span>
          </div>

          <form onSubmit={handleAnalyze} className="space-y-3 text-xs">
            <div>
              <label className="block text-[#8C9CB5] mb-1 font-semibold">Target URL (Safely Isolated)</label>
              <input
                type="text"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://..."
                className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs font-mono text-[#E8EEF9] outline-none focus:border-[#45D6C5]"
              />
            </div>

            <div>
              <label className="block text-[#8C9CB5] mb-1 font-semibold">Sender Email Address</label>
              <input
                type="email"
                value={sender}
                onChange={(e) => setSender(e.target.value)}
                placeholder="spoofed-sender@domain.com"
                className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs font-mono text-[#E8EEF9] outline-none focus:border-[#45D6C5]"
              />
            </div>

            <div>
              <label className="block text-[#8C9CB5] mb-1 font-semibold">Email Subject Line</label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs text-[#E8EEF9] outline-none focus:border-[#45D6C5]"
              />
            </div>

            <div>
              <label className="block text-[#8C9CB5] mb-1 font-semibold">Email Body Text / Urgency Copy</label>
              <textarea
                value={bodyText}
                onChange={(e) => setBodyText(e.target.value)}
                rows={3}
                className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg p-2.5 text-xs text-[#E8EEF9] outline-none focus:border-[#45D6C5]"
              />
            </div>

            <div>
              <label className="block text-[#8C9CB5] mb-1 font-semibold">Headers (SPF / DKIM / Received)</label>
              <input
                type="text"
                value={headers}
                onChange={(e) => setHeaders(e.target.value)}
                className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs font-mono text-[#8C9CB5] outline-none focus:border-[#45D6C5]"
              />
            </div>

            <button
              type="submit"
              disabled={isAnalyzing}
              className="w-full py-2 rounded-lg text-xs font-semibold bg-[#45D6C5] hover:bg-[#38bcae] text-[#080D18] transition-colors disabled:opacity-50"
            >
              {isAnalyzing ? 'Running PhishGuard Engine...' : 'Analyze Threat Profile'}
            </button>
          </form>

          {/* Quick preset links */}
          <div className="pt-2 border-t border-[#1A273D] text-[11px] text-[#8C9CB5]">
            <span className="font-semibold block mb-1">Try Samples:</span>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  setUrl('https://microsoft-login-verify.top/auth');
                  setSender('security-update@micros0ft-support.top');
                  setSubject('Password Expired: Immediate verification required');
                  setBodyText('Your Microsoft 365 password expires in 2 hours. Click here to verify your credentials.');
                  setHeaders('SPF: fail DKIM: none');
                }}
                className="text-[#45D6C5] hover:underline"
              >
                Microsoft Spoof
              </button>
              <span>·</span>
              <button
                type="button"
                onClick={() => {
                  setUrl('https://docs.github.com/en/rest');
                  setSender('support@github.com');
                  setSubject('GitHub API Documentation Update');
                  setBodyText('Check out the newly released API changelog.');
                  setHeaders('SPF: pass DKIM: pass');
                }}
                className="text-[#45D6C5] hover:underline"
              >
                Legitimate Email
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Analysis Results Card */}
        <div className="lg:col-span-7 space-y-4">
          {currentResult ? (
            <div className="p-5 rounded-xl bg-[#101B2D] border border-[#1A273D] space-y-4">
              {/* Score Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[#1A273D] gap-2">
                <div>
                  <div className="text-[11px] font-semibold text-[#8C9CB5] uppercase">Classification Verdict</div>
                  <div
                    className={`text-xl font-bold tracking-tight mt-0.5 ${
                      currentResult.classification === 'MALICIOUS_PHISHING'
                        ? 'text-[#F05268]'
                        : currentResult.classification === 'SUSPICIOUS'
                        ? 'text-[#E8AD4B]'
                        : 'text-[#42C99A]'
                    }`}
                  >
                    {currentResult.classification.replace(/_/g, ' ')}
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-[11px] text-[#8C9CB5]">Phishing Risk Index</div>
                  <div className="text-2xl font-bold font-mono text-[#F05268]">
                    {currentResult.riskScore}
                    <span className="text-xs text-[#8C9CB5] font-normal"> / 100</span>
                  </div>
                </div>
              </div>

              {/* Domain & Reputation Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <div className="p-2.5 rounded-lg bg-[#15233B]">
                  <div className="text-[10px] text-[#8C9CB5]">Target Domain</div>
                  <div className="font-mono font-semibold text-[#E8EEF9] truncate">
                    {currentResult.domainReputation.domain}
                  </div>
                </div>
                <div className="p-2.5 rounded-lg bg-[#15233B]">
                  <div className="text-[10px] text-[#8C9CB5]">Domain Age</div>
                  <div className="font-mono font-semibold text-[#E8EEF9]">
                    {currentResult.domainReputation.ageDays} days
                  </div>
                </div>
                <div className="p-2.5 rounded-lg bg-[#15233B]">
                  <div className="text-[10px] text-[#8C9CB5]">SPF / DKIM</div>
                  <div
                    className={`font-mono font-semibold ${
                      currentResult.domainReputation.spfPassed ? 'text-[#42C99A]' : 'text-[#F05268]'
                    }`}
                  >
                    {currentResult.domainReputation.spfPassed ? 'VALID PASS' : 'FAILED / SPOOF'}
                  </div>
                </div>
                <div className="p-2.5 rounded-lg bg-[#15233B]">
                  <div className="text-[10px] text-[#8C9CB5]">VirusTotal Detections</div>
                  <div className="font-mono font-semibold text-[#F05268]">
                    {currentResult.domainReputation.virusTotalScore}
                  </div>
                </div>
              </div>

              {/* Heuristic Evidence */}
              <div>
                <h4 className="text-xs font-semibold text-[#E8EEF9] mb-2">Detected Threat Indicators</h4>
                <div className="space-y-1.5">
                  {currentResult.evidence.map((ev, i) => (
                    <div
                      key={i}
                      className="p-2 rounded-lg bg-[#15233B] text-xs flex items-center gap-2 text-[#E8EEF9]"
                    >
                      <AlertTriangle className="w-3.5 h-3.5 text-[#E8AD4B] shrink-0" />
                      <span>{ev}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recommended Actions & Simulation Buttons */}
              <div>
                <h4 className="text-xs font-semibold text-[#E8EEF9] mb-2">Recommended SOC Actions</h4>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => handleSimulateContainment(`Domain ${currentResult.domainReputation.domain} blocked on DNS Firewall`)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[#F05268]/20 hover:bg-[#F05268]/30 text-[#F05268] border border-[#F05268]/30 transition-colors"
                  >
                    <Ban className="w-3.5 h-3.5" />
                    <span>Block Domain at DNS Proxy</span>
                  </button>

                  <button
                    onClick={() => handleSimulateContainment('Message purged from all corporate mailboxes')}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[#15233B] hover:bg-[#1E2D45] text-[#45D6C5] border border-[#1A273D] transition-colors"
                  >
                    <Inbox className="w-3.5 h-3.5" />
                    <span>Quarantine Mailbox Message</span>
                  </button>
                </div>

                {actionNotice && (
                  <div className="mt-3 p-2.5 rounded-lg bg-[#42C99A]/15 border border-[#42C99A]/30 text-xs text-[#42C99A] flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 shrink-0" />
                    <span>{actionNotice}</span>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="p-8 rounded-xl bg-[#101B2D] border border-[#1A273D] text-center text-[#8C9CB5] text-xs">
              Enter suspicious email or URL parameters to view automated forensic breakdown.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
