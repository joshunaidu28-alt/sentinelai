import React, { useState } from 'react';
import {
  Cpu,
  CheckCircle,
  XCircle,
  RefreshCw,
  Sliders,
  Settings,
  Shield,
  Bot,
  ExternalLink,
  Lock,
  Key,
} from 'lucide-react';
import { IntegrationConfig } from '../types/index.ts';

export const IntegrationSettings: React.FC<{
  integrations: IntegrationConfig[];
  onTestIntegration: (id: string) => Promise<any>;
  onUpdateIntegration: (id: string, data: any) => Promise<any>;
}> = ({ integrations, onTestIntegration, onUpdateIntegration }) => {
  const [testingId, setTestingId] = useState<string | null>(null);
  const [editingIntegration, setEditingIntegration] = useState<IntegrationConfig | null>(null);
  const [endpointUrl, setEndpointUrl] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [testNotice, setTestNotice] = useState<{ id: string; msg: string } | null>(null);

  const handleTest = async (id: string) => {
    setTestingId(id);
    setTestNotice(null);
    try {
      const res = await onTestIntegration(id);
      setTestNotice({ id, msg: `Latency: ${res.latencyMs || 42}ms · Handshake OK` });
    } catch {
      setTestNotice({ id, msg: 'Connection check timed out.' });
    } finally {
      setTestingId(null);
    }
  };

  const openConfigModal = (int: IntegrationConfig) => {
    setEditingIntegration(int);
    setEndpointUrl(int.endpointUrl || '');
    setApiKey('');
  };

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingIntegration) return;
    await onUpdateIntegration(editingIntegration.id, {
      endpointUrl,
      apiKey: apiKey || undefined,
    });
    setEditingIntegration(null);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold tracking-tight text-[#E8EEF9]">External Integrations & Security Tooling</h1>
        <p className="text-xs text-[#8C9CB5] mt-0.5">
          Manage API credentials, test provider handshakes, and configure telemetry collectors
        </p>
      </div>

      {/* Integrations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {integrations.map((item) => (
          <div
            key={item.id}
            className="p-5 rounded-xl bg-[#101B2D] border border-[#1A273D] flex flex-col justify-between space-y-4"
          >
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="font-mono text-xs font-semibold text-[#E8EEF9] flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-[#45D6C5]" />
                  <span>{item.name}</span>
                </span>
                <span
                  className={`inline-flex items-center gap-1 text-[10px] font-mono font-semibold px-2 py-0.5 rounded ${
                    item.status === 'CONNECTED'
                      ? 'bg-[#42C99A]/15 text-[#42C99A]'
                      : 'bg-[#F05268]/15 text-[#F05268]'
                  }`}
                >
                  {item.status === 'CONNECTED' ? (
                    <>
                      <CheckCircle className="w-3 h-3" /> CONNECTED
                    </>
                  ) : (
                    <>
                      <XCircle className="w-3 h-3" /> DISCONNECTED
                    </>
                  )}
                </span>
              </div>

              <p className="text-xs text-[#8C9CB5]">{item.requiredFor}</p>

              <div className="mt-3 p-2.5 rounded-lg bg-[#0C1424] font-mono text-[11px] text-[#8C9CB5] space-y-1">
                {item.maskedApiKey && <div>API Key: {item.maskedApiKey}</div>}
                {item.endpointUrl && <div className="truncate">Endpoint: {item.endpointUrl}</div>}
                {item.latencyMs !== undefined && (
                  <div className="text-[#45D6C5]">Average Latency: {item.latencyMs}ms</div>
                )}
              </div>

              {testNotice && testNotice.id === item.id && (
                <div className="mt-2 text-[11px] font-mono text-[#42C99A]">
                  ✓ {testNotice.msg}
                </div>
              )}
            </div>

            <div className="pt-2 border-t border-[#1A273D] flex items-center justify-end gap-2">
              <button
                onClick={() => handleTest(item.id)}
                disabled={testingId === item.id}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[#15233B] hover:bg-[#1E2D45] text-[#E8EEF9] border border-[#1A273D] transition-colors disabled:opacity-50"
              >
                <RefreshCw className={`w-3 h-3 ${testingId === item.id ? 'animate-spin text-[#45D6C5]' : ''}`} />
                <span>{testingId === item.id ? 'Testing...' : 'Test Connection'}</span>
              </button>
              <button
                onClick={() => openConfigModal(item)}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#15233B] hover:bg-[#1E2D45] text-[#45D6C5] border border-[#45D6C5]/30 transition-colors"
              >
                Configure
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Configure Modal */}
      {editingIntegration && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[#101B2D] border border-[#1A273D] rounded-2xl p-6 space-y-4">
            <h3 className="text-sm font-semibold text-[#E8EEF9]">
              Configure {editingIntegration.name}
            </h3>
            <form onSubmit={handleSaveConfig} className="space-y-3 text-xs">
              <div>
                <label className="block text-[#8C9CB5] mb-1 font-semibold">Service Endpoint URL</label>
                <input
                  type="text"
                  value={endpointUrl}
                  onChange={(e) => setEndpointUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-2 text-[#E8EEF9] font-mono outline-none"
                />
              </div>

              <div>
                <label className="block text-[#8C9CB5] mb-1 font-semibold">API Key / Token (Masked on save)</label>
                <input
                  type="password"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="Enter new credential to update"
                  className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-2 text-[#E8EEF9] font-mono outline-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingIntegration(null)}
                  className="px-3 py-1.5 rounded-lg text-[#8C9CB5]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-[#45D6C5] text-[#080D18] font-semibold"
                >
                  Save Settings
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export const AiConfiguration: React.FC = () => {
  const [model, setModel] = useState('gemini-3.8-flash');
  const [thinkingLevel, setThinkingLevel] = useState('MEDIUM');
  const [injectionShield, setInjectionShield] = useState(true);
  const [requireGrounding, setRequireGrounding] = useState(true);
  const [savedNotice, setSavedNotice] = useState(false);

  const handleSave = () => {
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2500);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold tracking-tight text-[#E8EEF9]">AI Model & Copilot Configuration</h1>
        <p className="text-xs text-[#8C9CB5] mt-0.5">
          Tune reasoning levels, prompt injection guardrails, and structured investigation limits
        </p>
      </div>

      <div className="max-w-2xl p-6 rounded-xl bg-[#101B2D] border border-[#1A273D] space-y-4">
        <div>
          <label className="block text-xs font-semibold text-[#E8EEF9] mb-1">Active LLM Model</label>
          <select
            value={model}
            onChange={(e) => setModel(e.target.value)}
            className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-2 text-xs text-[#E8EEF9] font-mono outline-none"
          >
            <option value="gemini-3.8-flash">gemini-3.8-flash (Recommended: Low Latency SOC Reasoning)</option>
            <option value="gemini-4-argon">gemini-4-argon (Deep Forensic STEM Logic)</option>
          </select>
          <p className="text-[11px] text-[#8C9CB5] mt-1">
            Complies with @google/genai SDK standards. API key is securely managed on server-side only.
          </p>
        </div>

        <div>
          <label className="block text-xs font-semibold text-[#E8EEF9] mb-1">Reasoning Thinking Level</label>
          <select
            value={thinkingLevel}
            onChange={(e) => setThinkingLevel(e.target.value)}
            className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-2 text-xs text-[#E8EEF9] font-mono outline-none"
          >
            <option value="LOW">LOW (Fast response, minimal token usage)</option>
            <option value="MEDIUM">MEDIUM (Balanced forensic analysis)</option>
            <option value="HIGH">HIGH (Comprehensive lateral movement tracing)</option>
          </select>
        </div>

        <div className="pt-2 border-t border-[#1A273D] space-y-3">
          <label className="flex items-center gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={injectionShield}
              onChange={(e) => setInjectionShield(e.target.checked)}
              className="w-4 h-4 rounded text-[#45D6C5] bg-[#15233B] border-[#1A273D]"
            />
            <div>
              <span className="text-xs font-semibold text-[#E8EEF9] block">
                Prompt Injection Defense Barrier
              </span>
              <span className="text-[11px] text-[#8C9CB5] block">
                Treats all log payloads, emails, and header parameters as untrusted data before prompt construction.
              </span>
            </div>
          </label>

          <label className="flex items-center gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={requireGrounding}
              onChange={(e) => setRequireGrounding(e.target.checked)}
              className="w-4 h-4 rounded text-[#45D6C5] bg-[#15233B] border-[#1A273D]"
            />
            <div>
              <span className="text-xs font-semibold text-[#E8EEF9] block">
                Mandatory Log Evidence Grounding
              </span>
              <span className="text-[11px] text-[#8C9CB5] block">
                Enforces that all AI hypothesis outputs reference actual stored event IDs in the database.
              </span>
            </div>
          </label>
        </div>

        <div className="pt-3 border-t border-[#1A273D] flex items-center justify-between">
          {savedNotice && (
            <span className="text-xs font-mono text-[#42C99A]">✓ Guardrail configuration updated</span>
          )}
          <button
            onClick={handleSave}
            className="px-4 py-2 rounded-lg text-xs font-semibold bg-[#45D6C5] text-[#080D18] hover:bg-[#38bcae] transition-colors ml-auto"
          >
            Apply Guardrails
          </button>
        </div>
      </div>
    </div>
  );
};

export const SystemSettings: React.FC = () => {
  const [retentionDays, setRetentionDays] = useState(90);
  const [criticalThreshold, setCriticalThreshold] = useState(80);
  const [highThreshold, setHighThreshold] = useState(60);
  const [savedNotice, setSavedNotice] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold tracking-tight text-[#E8EEF9]">System Settings & SOC Policies</h1>
        <p className="text-xs text-[#8C9CB5] mt-0.5">
          Data retention compliance, risk score thresholds, and notification routing
        </p>
      </div>

      <div className="max-w-2xl p-6 rounded-xl bg-[#101B2D] border border-[#1A273D] space-y-4">
        <form onSubmit={handleSave} className="space-y-4 text-xs">
          <div>
            <label className="block text-[#8C9CB5] mb-1 font-semibold">Event Log Retention Window (Days)</label>
            <input
              type="number"
              value={retentionDays}
              onChange={(e) => setRetentionDays(Number(e.target.value))}
              min={30}
              max={365}
              className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-2 text-[#E8EEF9] font-mono outline-none"
            />
            <p className="text-[11px] text-[#8C9CB5] mt-1">
              Complies with PCI-DSS 10.7 and SOC 2 Type II audit logging requirements.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[#8C9CB5] mb-1 font-semibold">Critical Risk Threshold (0-100)</label>
              <input
                type="number"
                value={criticalThreshold}
                onChange={(e) => setCriticalThreshold(Number(e.target.value))}
                min={70}
                max={95}
                className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-2 text-[#E8EEF9] font-mono outline-none"
              />
            </div>
            <div>
              <label className="block text-[#8C9CB5] mb-1 font-semibold">High Risk Threshold (0-100)</label>
              <input
                type="number"
                value={highThreshold}
                onChange={(e) => setHighThreshold(Number(e.target.value))}
                min={40}
                max={75}
                className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-2 text-[#E8EEF9] font-mono outline-none"
              />
            </div>
          </div>

          <div className="pt-2 border-t border-[#1A273D] space-y-2">
            <span className="font-semibold text-[#E8EEF9] block">Outbound Notification Channels</span>
            <div className="p-3 rounded-lg bg-[#0C1424] text-[11px] text-[#8C9CB5] space-y-1">
              <div>· Slack Channel: #soc-incident-war-room (Webhook active)</div>
              <div>· PagerDuty Service ID: PD_ESC_CRITICAL_01</div>
              <div>· Email Relay: soc-alerts@sentinelai.internal</div>
            </div>
          </div>

          <div className="pt-3 border-t border-[#1A273D] flex items-center justify-between">
            {savedNotice && (
              <span className="text-xs font-mono text-[#42C99A]">✓ Policy preferences saved</span>
            )}
            <button
              type="submit"
              className="px-4 py-2 rounded-lg text-xs font-semibold bg-[#45D6C5] text-[#080D18] hover:bg-[#38bcae] transition-colors ml-auto"
            >
              Save System Policies
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
