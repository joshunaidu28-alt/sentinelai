import React, { useState } from 'react';
import { Network, ShieldCheck, AlertTriangle, ArrowUpDown, Filter, Activity, Server, Zap } from 'lucide-react';
import { NetworkConnection, Vulnerability, MonitoredAsset } from '../types/index.ts';
import { SeverityBadge, StatusBadge } from '../components/common/StatCard.tsx';

export const NetworkSecurity: React.FC<{
  connections: NetworkConnection[];
  stats: any;
}> = ({ connections, stats }) => {
  const [filterType, setFilterType] = useState('ALL');

  const filtered = connections.filter((c) => {
    if (filterType === 'ANOMALIES') return c.status === 'FLAGGED_ANOMALOUS';
    if (filterType === 'TCP') return c.protocol === 'TCP' || c.protocol === 'HTTPS' || c.protocol === 'SSH';
    if (filterType === 'DNS') return c.protocol === 'DNS';
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold tracking-tight text-[#E8EEF9]">Network Security Monitoring</h1>
        <p className="text-xs text-[#8C9CB5] mt-0.5">
          Connection metadata telemetry, protocol bandwidth distribution, and unusual beaconing detection
        </p>
      </div>

      {/* Network Stats KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl bg-[#101B2D] border border-[#1A273D]">
          <div className="text-[11px] font-semibold text-[#8C9CB5] uppercase mb-1">Aggregated Bandwidth</div>
          <div className="text-xl font-bold font-mono text-[#45D6C5]">
            {stats?.totalBandwidthMbps || 482.4} <span className="text-xs font-normal text-[#8C9CB5]">Mbps</span>
          </div>
          <div className="text-[11px] text-[#8C9CB5] mt-1">Across 8 active monitoring taps</div>
        </div>

        <div className="p-4 rounded-xl bg-[#101B2D] border border-[#1A273D]">
          <div className="text-[11px] font-semibold text-[#8C9CB5] uppercase mb-1">Flagged Anomalous Flows</div>
          <div className="text-xl font-bold font-mono text-[#F05268]">
            {stats?.anomalousConnectionsCount || 2} <span className="text-xs font-normal text-[#8C9CB5]">flows</span>
          </div>
          <div className="text-[11px] text-[#8C9CB5] mt-1">Unusual port/entropy triggers</div>
        </div>

        <div className="p-4 rounded-xl bg-[#101B2D] border border-[#1A273D]">
          <div className="text-[11px] font-semibold text-[#8C9CB5] uppercase mb-1">Primary Transport</div>
          <div className="text-xl font-bold font-mono text-[#438CFF]">HTTPS (TLS 1.3)</div>
          <div className="text-[11px] text-[#8C9CB5] mt-1">64% of total perimeter ingress</div>
        </div>

        <div className="p-4 rounded-xl bg-[#101B2D] border border-[#1A273D]">
          <div className="text-[11px] font-semibold text-[#8C9CB5] uppercase mb-1">Capture Authorization</div>
          <div className="text-xl font-bold font-mono text-[#42C99A]">Scope Verified</div>
          <div className="text-[11px] text-[#8C9CB5] mt-1">Metadata only · No plaintext capture</div>
        </div>
      </div>

      {/* Protocol Distribution Bar */}
      <div className="p-5 rounded-xl bg-[#101B2D] border border-[#1A273D] space-y-3">
        <div className="flex items-center justify-between text-xs">
          <span className="font-semibold text-[#E8EEF9]">Perimeter Protocol Distribution</span>
          <span className="font-mono text-[#8C9CB5]">Total Monitored Flows</span>
        </div>
        <div className="w-full h-3 rounded-full overflow-hidden flex bg-[#15233B]">
          <div className="h-full bg-[#45D6C5]" style={{ width: '64%' }} title="HTTPS 64%" />
          <div className="h-full bg-[#438CFF]" style={{ width: '14%' }} title="DNS 14%" />
          <div className="h-full bg-[#A070FF]" style={{ width: '10%' }} title="SSH 10%" />
          <div className="h-full bg-[#E8AD4B]" style={{ width: '8%' }} title="Kerberos 8%" />
          <div className="h-full bg-[#8C9CB5]" style={{ width: '4%' }} title="Other 4%" />
        </div>
        <div className="flex flex-wrap items-center gap-4 text-[11px] text-[#8C9CB5]">
          <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#45D6C5]" /> HTTPS 64%</span>
          <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#438CFF]" /> DNS 14%</span>
          <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#A070FF]" /> SSH 10%</span>
          <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#E8AD4B]" /> Kerberos 8%</span>
        </div>
      </div>

      {/* Filter Tabs & Connections Table */}
      <div className="rounded-xl bg-[#101B2D] border border-[#1A273D] overflow-hidden">
        <div className="px-5 py-3.5 bg-[#0C1424] border-b border-[#1A273D] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-[#E8EEF9]">Active Connection Flows</span>
            <div className="flex gap-1 ml-4">
              {['ALL', 'ANOMALIES', 'TCP', 'DNS'].map((f) => (
                <button
                  key={f}
                  onClick={() => setFilterType(f)}
                  className={`px-2.5 py-1 rounded text-[11px] font-mono transition-colors ${
                    filterType === f ? 'bg-[#15233B] text-[#45D6C5]' : 'text-[#8C9CB5] hover:text-[#E8EEF9]'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#1A273D] text-[#8C9CB5] text-[11px]">
                <th className="py-3 px-4 font-medium">Timestamp</th>
                <th className="py-3 px-4 font-medium">Protocol</th>
                <th className="py-3 px-4 font-medium">Source Socket</th>
                <th className="py-3 px-4 font-medium">Destination Socket</th>
                <th className="py-3 px-4 font-medium text-right">Bytes In/Out</th>
                <th className="py-3 px-4 font-medium">Status / Anomaly Detail</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1A273D]">
              {filtered.map((c) => (
                <tr key={c.id} className="hover:bg-[#15233B]/40 transition-colors">
                  <td className="py-3 px-4 font-mono text-[11px] text-[#8C9CB5]">
                    {new Date(c.timestamp).toLocaleTimeString()}
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-[#45D6C5] font-semibold">
                    {c.protocol}
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-[#E8EEF9]">
                    {c.sourceIp}:{c.sourcePort}
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-[#438CFF]">
                    {c.destinationIp}:{c.destinationPort}
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-right text-[#8C9CB5]">
                    {c.bytesSent.toLocaleString()} / {c.bytesReceived.toLocaleString()}
                  </td>
                  <td className="py-3 px-4">
                    {c.status === 'FLAGGED_ANOMALOUS' ? (
                      <div className="flex items-center gap-1.5 text-[#F05268]">
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                        <span className="font-medium text-[11px]">{c.anomalyReason}</span>
                      </div>
                    ) : (
                      <span className="text-[#42C99A] text-[11px] font-mono font-medium">ALLOWED</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export const VulnerabilityManagement: React.FC<{
  vulnerabilities: Vulnerability[];
  assets: MonitoredAsset[];
  onTriggerScan: (assetId: string, scanType: string) => Promise<any>;
}> = ({ vulnerabilities, assets, onTriggerScan }) => {
  const [selectedAssetId, setSelectedAssetId] = useState(assets[0]?.id || '');
  const [scanType, setScanType] = useState('NMAP_VULNERS');
  const [isScanning, setIsScanning] = useState(false);
  const [scanNotice, setScanNotice] = useState<string | null>(null);

  const handleScan = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsScanning(true);
    setScanNotice(null);
    try {
      const res = await onTriggerScan(selectedAssetId, scanType);
      setScanNotice(`Authorized scan completed: Added finding ${res.finding?.cveId || 'New Finding'}`);
    } catch (err: any) {
      setScanNotice(`Scan error: ${err.message}`);
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold tracking-tight text-[#E8EEF9]">Vulnerability Management</h1>
        <p className="text-xs text-[#8C9CB5] mt-0.5">
          Authorized vulnerability assessment, CVSS v3.1 scoring, and patch remediation tracking
        </p>
      </div>

      {/* Authorized Scan Trigger Bar */}
      <div className="p-5 rounded-xl bg-[#101B2D] border border-[#1A273D] space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-semibold text-[#E8EEF9] flex items-center gap-2">
            <Zap className="w-4 h-4 text-[#45D6C5]" />
            <span>Launch Authorized Vulnerability Assessment</span>
          </h2>
          <span className="text-[11px] text-[#42C99A] font-mono">Scope Authorization Enforced</span>
        </div>

        <form onSubmit={handleScan} className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div>
            <label className="block text-[#8C9CB5] mb-1 font-semibold">Authorized Target Asset</label>
            <select
              value={selectedAssetId}
              onChange={(e) => setSelectedAssetId(e.target.value)}
              className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs text-[#E8EEF9] outline-none"
            >
              {assets.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name} ({a.ipAddress})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[#8C9CB5] mb-1 font-semibold">Scanner Profile</label>
            <select
              value={scanType}
              onChange={(e) => setScanType(e.target.value)}
              className="w-full bg-[#15233B] border border-[#1A273D] rounded-lg px-3 py-1.5 text-xs text-[#E8EEF9] outline-none"
            >
              <option value="NMAP_VULNERS">Nmap + Vulners CVE Script Engine</option>
              <option value="OWASP_ZAP">OWASP ZAP Dynamic API Fuzzer</option>
            </select>
          </div>

          <div className="flex items-end">
            <button
              type="submit"
              disabled={isScanning}
              className="w-full py-2 rounded-lg text-xs font-semibold bg-[#45D6C5] hover:bg-[#38bcae] text-[#080D18] transition-colors disabled:opacity-50"
            >
              {isScanning ? 'Executing Scan Engine...' : 'Run Authorized Scan'}
            </button>
          </div>
        </form>

        {scanNotice && (
          <div className="p-2.5 rounded-lg bg-[#42C99A]/15 border border-[#42C99A]/30 text-xs text-[#42C99A]">
            {scanNotice}
          </div>
        )}
      </div>

      {/* Vulnerabilities Table */}
      <div className="rounded-xl bg-[#101B2D] border border-[#1A273D] overflow-hidden">
        <div className="px-5 py-3.5 bg-[#0C1424] border-b border-[#1A273D] flex items-center justify-between">
          <h2 className="text-xs font-semibold text-[#E8EEF9]">Active CVE Vulnerability Register</h2>
          <span className="text-[11px] font-mono text-[#8C9CB5]">{vulnerabilities.length} Open Findings</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#1A273D] text-[#8C9CB5] text-[11px]">
                <th className="py-3 px-4 font-medium">CVE Identifier</th>
                <th className="py-3 px-4 font-medium">CVSS v3.1</th>
                <th className="py-3 px-4 font-medium">Severity</th>
                <th className="py-3 px-4 font-medium">Affected Asset</th>
                <th className="py-3 px-4 font-medium">Vulnerability Description & Remediation</th>
                <th className="py-3 px-4 font-medium">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1A273D]">
              {vulnerabilities.map((v) => (
                <tr key={v.id} className="hover:bg-[#15233B]/40 transition-colors">
                  <td className="py-3 px-4 font-mono font-semibold text-[#45D6C5] whitespace-nowrap">
                    {v.cveId}
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-[11px] text-[#F05268] whitespace-nowrap">
                    {v.cvssScore.toFixed(1)}
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <SeverityBadge severity={v.severity} />
                  </td>
                  <td className="py-3 px-4 text-[#E8EEF9] whitespace-nowrap">{v.assetName}</td>
                  <td className="py-3 px-4 max-w-md">
                    <div className="font-semibold text-[#E8EEF9]">{v.title}</div>
                    <div className="text-[11px] text-[#8C9CB5] mt-0.5">{v.description}</div>
                    <div className="text-[11px] text-[#45D6C5] mt-1 font-mono">
                      Fix: {v.remediationPlan}
                    </div>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <StatusBadge status={v.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
