import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateRiskScore, analyzePhishing, correlateMitre } from './detection.ts';

test('calculateRiskScore: correctly identifies critical multi-factor risk', () => {
  const result = calculateRiskScore({
    baseSeverity: 'CRITICAL',
    assetCriticality: 'TIER_1_CRITICAL',
    hasKnownBadIoc: true,
    iocReputationScore: 90,
    eventFrequencyPerHour: 20,
    unauthorizedAccessAttempt: true,
  });

  assert.equal(result.tier, 'CRITICAL');
  assert.ok(result.score >= 80, `Expected score >= 80, got ${result.score}`);
  assert.ok(result.factors.length >= 4);
});

test('calculateRiskScore: calculates low risk for informational routine baseline', () => {
  const result = calculateRiskScore({
    baseSeverity: 'INFO',
    assetCriticality: 'TIER_4_LOW',
  });

  assert.equal(result.tier, 'LOW');
  assert.ok(result.score < 30, `Expected score < 30, got ${result.score}`);
});

test('analyzePhishing: catches brand spoofing and urgency keywords', () => {
  const result = analyzePhishing({
    url: 'http://paypa1-security-verify.xyz/login',
    sender: 'support@paypa1-security-verify.xyz',
    subject: 'Immediate action required: verify your account',
    bodyText: 'Your account is suspended. Click here to unlock your crypto wallet.',
    spfValid: false,
    dkimValid: false,
  });

  assert.equal(result.classification, 'MALICIOUS_PHISHING');
  assert.ok(result.score >= 60, `Expected score >= 60, got ${result.score}`);
  assert.ok(result.matchedKeywords.length >= 2);
});

test('analyzePhishing: marks clean corporate email as safe', () => {
  const result = analyzePhishing({
    url: 'https://github.com/organization/repo',
    sender: 'notifications@github.com',
    subject: 'Weekly engineering standup recap',
    bodyText: 'Here is the summary of closed pull requests for this week.',
    spfValid: true,
    dkimValid: true,
  });

  assert.equal(result.classification, 'SAFE');
  assert.ok(result.score < 30, `Expected score < 30, got ${result.score}`);
});

test('correlateMitre: correctly correlates known attack signatures', () => {
  const bruteForce = correlateMitre('AUTH_FAILURE', 'Repeated failed login attempts from IP');
  assert.equal(bruteForce.id, 'T1110');
  assert.equal(bruteForce.name, 'Brute Force');

  const scan = correlateMitre('PORT_SCAN', 'Syn scan across ports 20-1024');
  assert.equal(scan.id, 'T1046');

  const privEsc = correlateMitre('PRIVILEGE_ESCALATION', 'Attempted unauthorized sudo execution');
  assert.equal(privEsc.id, 'T1078');
});
