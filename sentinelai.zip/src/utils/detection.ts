/**
 * SentinelAI - Detection & Scoring Engine Core Utilities
 * Pure deterministic functions for risk scoring, heuristics, and MITRE correlation.
 */

export interface RiskInput {
  baseSeverity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';
  assetCriticality?: 'TIER_1_CRITICAL' | 'TIER_2_HIGH' | 'TIER_3_MEDIUM' | 'TIER_4_LOW';
  hasKnownBadIoc?: boolean;
  iocReputationScore?: number; // 0 to 100
  eventFrequencyPerHour?: number;
  unauthorizedAccessAttempt?: boolean;
}

export type RiskTier = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface RiskResult {
  score: number; // 0 to 100
  tier: RiskTier;
  factors: string[];
}

/**
 * Calculates a composite security risk score (0-100) based on weighted factors.
 */
export function calculateRiskScore(input: RiskInput): RiskResult {
  let score = 0;
  const factors: string[] = [];

  // 1. Base Severity Weight (up to 45 pts)
  switch (input.baseSeverity) {
    case 'CRITICAL':
      score += 45;
      factors.push('Critical base severity (+45)');
      break;
    case 'HIGH':
      score += 35;
      factors.push('High base severity (+35)');
      break;
    case 'MEDIUM':
      score += 20;
      factors.push('Medium base severity (+20)');
      break;
    case 'LOW':
      score += 10;
      factors.push('Low base severity (+10)');
      break;
    case 'INFO':
    default:
      score += 2;
      factors.push('Informational baseline (+2)');
      break;
  }

  // 2. Asset Criticality (up to 25 pts)
  if (input.assetCriticality) {
    switch (input.assetCriticality) {
      case 'TIER_1_CRITICAL':
        score += 25;
        factors.push('Target is Tier 1 Mission-Critical Asset (+25)');
        break;
      case 'TIER_2_HIGH':
        score += 18;
        factors.push('Target is Tier 2 High Priority Asset (+18)');
        break;
      case 'TIER_3_MEDIUM':
        score += 10;
        factors.push('Target is Tier 3 Internal Asset (+10)');
        break;
      case 'TIER_4_LOW':
        score += 4;
        factors.push('Target is Tier 4 Low Impact Asset (+4)');
        break;
    }
  }

  // 3. Known Threat Intelligence Correlation (up to 20 pts)
  if (input.hasKnownBadIoc) {
    const rep = input.iocReputationScore ?? 75;
    const iocPoints = Math.min(20, Math.round((rep / 100) * 20));
    score += iocPoints;
    factors.push(`Correlated with Threat Intelligence indicator (+${iocPoints})`);
  }

  // 4. Anomaly Velocity & Frequency (up to 15 pts)
  if (input.eventFrequencyPerHour && input.eventFrequencyPerHour > 5) {
    const freqBoost = Math.min(15, Math.floor(input.eventFrequencyPerHour / 5) * 3);
    score += freqBoost;
    factors.push(`High anomaly frequency: ${input.eventFrequencyPerHour} events/hr (+${freqBoost})`);
  }

  // 5. Unauthorized privilege / access attempt (up to 10 pts)
  if (input.unauthorizedAccessAttempt) {
    score += 10;
    factors.push('Privilege escalation or unauthorized access pattern (+10)');
  }

  // Clamp 0 - 100
  const normalizedScore = Math.max(0, Math.min(100, score));

  // Determine tier according to specification:
  // 0–29: Low, 30–59: Medium, 60–79: High, 80–100: Critical
  let tier: RiskTier = 'LOW';
  if (normalizedScore >= 80) {
    tier = 'CRITICAL';
  } else if (normalizedScore >= 60) {
    tier = 'HIGH';
  } else if (normalizedScore >= 30) {
    tier = 'MEDIUM';
  }

  return {
    score: normalizedScore,
    tier,
    factors,
  };
}

export interface PhishingInput {
  url?: string;
  sender?: string;
  subject?: string;
  bodyText?: string;
  spfValid?: boolean;
  dkimValid?: boolean;
}

export interface PhishingAnalysisResult {
  score: number;
  classification: 'SAFE' | 'SUSPICIOUS' | 'MALICIOUS_PHISHING';
  reasons: string[];
  matchedKeywords: string[];
}

/**
 * Heuristic Phishing Detection Engine
 */
export function analyzePhishing(input: PhishingInput): PhishingAnalysisResult {
  let score = 5;
  const reasons: string[] = [];
  const matchedKeywords: string[] = [];

  const textToCheck = `${input.subject ?? ''} ${input.bodyText ?? ''}`.toLowerCase();
  const urlToCheck = (input.url ?? '').toLowerCase();
  const senderToCheck = (input.sender ?? '').toLowerCase();

  // Suspicious keywords list
  const suspiciousKeywords = [
    'immediate action required',
    'password expire',
    'verify your account',
    'wire transfer',
    'gift card',
    'security alert: suspended',
    'update billing info',
    'crypto wallet',
    'unauthorized login detected',
    'irs tax refund',
    'click here to unlock',
  ];

  for (const kw of suspiciousKeywords) {
    if (textToCheck.includes(kw)) {
      matchedKeywords.push(kw);
      score += 12;
    }
  }
  if (matchedKeywords.length > 0) {
    reasons.push(`Contains high-risk credential/urgency keywords: ${matchedKeywords.join(', ')}`);
  }

  // Typosquatting / homoglyph heuristics on URL or sender
  const brandSpoofs = [
    { brand: 'paypal', spoofRegex: /paypa[l1i]|p-a-y-p-a-l/ },
    { brand: 'microsoft', spoofRegex: /micros[o0]ft|m1crosoft|msft-verify/ },
    { brand: 'google', spoofRegex: /g[o0]{2}gle|goog1e|account-security-google/ },
    { brand: 'apple', spoofRegex: /app1e|apple-id-verify/ },
    { brand: 'chase', spoofRegex: /chase-verify|chase-security/ },
  ];

  for (const item of brandSpoofs) {
    if (item.spoofRegex.test(urlToCheck) || item.spoofRegex.test(senderToCheck)) {
      score += 35;
      reasons.push(`Potential brand impersonation / typosquatting detected targeting ${item.brand}`);
    }
  }

  // Suspicious TLD check
  const dangerousTlds = ['.xyz', '.top', '.ru', '.work', '.click', '.monster', '.loan', '.gq', '.cf'];
  for (const tld of dangerousTlds) {
    if (urlToCheck.includes(tld)) {
      score += 20;
      reasons.push(`Suspicious top-level domain (${tld}) frequently used in malicious campaigns`);
      break;
    }
  }

  // IP address as host in URL
  if (/https?:\/\/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/.test(urlToCheck)) {
    score += 30;
    reasons.push('Raw IP address host detected in URL (bypassing DNS validation)');
  }

  // SPF / DKIM verification
  if (input.spfValid === false) {
    score += 15;
    reasons.push('Sender SPF record failed validation (spoofed sender domain likely)');
  }
  if (input.dkimValid === false) {
    score += 10;
    reasons.push('DKIM cryptographic signature missing or invalid');
  }

  const finalScore = Math.max(0, Math.min(100, score));

  let classification: 'SAFE' | 'SUSPICIOUS' | 'MALICIOUS_PHISHING' = 'SAFE';
  if (finalScore >= 60) {
    classification = 'MALICIOUS_PHISHING';
  } else if (finalScore >= 30) {
    classification = 'SUSPICIOUS';
  }

  return {
    score: finalScore,
    classification,
    reasons,
    matchedKeywords,
  };
}

/**
 * MITRE ATT&CK Mapping
 */
export function correlateMitre(eventType: string, message: string): { id: string; name: string; tactic: string } {
  const content = `${eventType} ${message}`.toLowerCase().replace(/_/g, ' ');

  if (content.includes('brute') || content.includes('failed login') || content.includes('auth failure')) {
    return {
      id: 'T1110',
      name: 'Brute Force',
      tactic: 'Credential Access',
    };
  }
  if (content.includes('port scan') || content.includes('recon') || content.includes('service discovery')) {
    return {
      id: 'T1046',
      name: 'Network Service Scanning',
      tactic: 'Discovery',
    };
  }
  if (content.includes('powershell') || content.includes('bash') || content.includes('cmd.exe') || content.includes('script')) {
    return {
      id: 'T1059',
      name: 'Command and Scripting Interpreter',
      tactic: 'Execution',
    };
  }
  if (content.includes('privilege') || content.includes('sudo') || content.includes('root access') || content.includes('uac')) {
    return {
      id: 'T1078',
      name: 'Valid Accounts / Privilege Escalation',
      tactic: 'Privilege Escalation',
    };
  }
  if (content.includes('exfiltration') || content.includes('outbound beacon') || content.includes('dns tunnel')) {
    return {
      id: 'T1041',
      name: 'Exfiltration Over C2 Channel',
      tactic: 'Exfiltration',
    };
  }
  if (content.includes('cve-') || content.includes('sql injection') || content.includes('remote code')) {
    return {
      id: 'T1190',
      name: 'Exploit Public-Facing Application',
      tactic: 'Initial Access',
    };
  }

  return {
    id: 'T1071',
    name: 'Application Layer Protocol',
    tactic: 'Command and Control',
  };
}
