# SentinelAI Installation Guide

Follow these steps to deploy and run SentinelAI in local development or production environments.

---

## Local Development (Full-Stack Mode)

1. Clone or extract the project repository:
   ```bash
   cd sentinelai
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Configure environment variables in `.env`:
   ```bash
   cp .env.example .env
   # Add your GEMINI_API_KEY if available (the application runs with robust offline fallbacks if omitted)
   ```

4. Start the full-stack SOC server:
   ```bash
   npm run dev
   ```

5. Open your browser and navigate to:
   ```
   http://localhost:3000
   ```

---

## Running Automated Tests

Run the pure logic test suite:
```bash
npx --yes tsx --test src/utils/detection.test.ts
```

Check TypeScript types and lint:
```bash
npm run lint
```
