# SentinelAI System Architecture

This document describes the high-level design, component boundaries, and data flow of the SentinelAI cybersecurity platform.

---

## 1. Architectural Layers

### Frontend Presentation Layer
- **Framework**: React 19 SPA running on Vite.
- **Styling**: Tailwind CSS v4 with dark command-center aesthetic (#080D18 baseline, #0C1424 sidebars, #101B2D structural cards, #45D6C5 primary cyan accent, #438CFF blue accent).
- **Icons & Data Visualization**: Lucide React and Recharts (Area, Bar, Pie charts).
- **Navigation Model**: 20 distinct modules categorized into:
  - Operations (Dashboard, Monitoring, Logs, Threat Detection, Alerts, Incidents)
  - Intel & Analysis (Phishing Guard, Network Security, Vulnerabilities, Threat Intel, AI Copilot)
  - SOAR & Automation (Automation Center, Playbook Management, Security Reports, Asset Management)
  - Administration (User Management, Audit Logs, Integrations, AI Configuration, System Settings)

### Application Server & Ingestion Layer
- **Full-Stack Runtime**: Express server (`server.ts`) with Vite dev middleware for single-port execution on 3000.
- **FastAPI Backend Parity**: Standalone Python FastAPI microservice architecture located in `backend/app/` with Alembic migration definitions and asyncpg/SQLAlchemy 2 models.
- **Event Ingestion Pipeline**: Ingests JSON security logs, runs real-time schema validation, applies normalized risk scoring, checks sliding window frequencies, and triggers automated alert generation when threshold >= 50.

### AI & Threat Detection Engine
- **Copilot LLM Provider**: Google Gemini (`gemini-3.8-flash` via `@google/genai` TypeScript SDK on the server).
- **Prompt Injection Defense**: All user-supplied logs, emails, and header text are treated as untrusted data and wrapped in structural boundaries.
- **Grounded Forensics**: AI investigation outputs are strictly validated to cite actual database log IDs and event records.

### Threat Intelligence & External Integrations
- **VirusTotal API**: Domain, URL, and SHA256 reputation enrichment.
- **MITRE ATT&CK Enterprise v14**: Technique taxonomy mapping (e.g. T1110 Brute Force, T1059 Command and Scripting, T1046 Network Service Scanning).
- **Nmap / Vulners & OWASP ZAP**: Authorized asset scanning and CVE vulnerability tracking.
- **Redis & Celery**: Background task queue orchestration for asynchronous playbook execution.
- **n8n Webhook**: Signed webhook delivery for external SOC ticketing and chatops notifications.
