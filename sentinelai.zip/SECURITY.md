# SentinelAI Security Architecture & Safeguards

Security operations platforms require exceptional defensive engineering. SentinelAI adheres to strict DevSecOps, least privilege, and anti-tamper security controls.

---

## 1. Authentication & Session Management
- **Password Storage**: Argon2id hashing with unique per-user salts.
- **Tokens**: Short-lived JWT access tokens (15m) with rotating refresh tokens and IP binding.
- **Hardware MFA**: WebAuthn/FIDO2 hardware security keys and TOTP support.
- **Session Revocation**: Centralized session invalidation upon privilege modification or suspicious login.

## 2. Role-Based Access Control (RBAC)
- Enforced strictly on backend API routes through authorization middleware.
- `ADMIN`: Full access to configure integrations, user management, and playbook approvals.
- `SECURITY_ANALYST`: Alert triage, forensic investigation, incident declarations, and scan triggers.
- `SOC_MANAGER`: Operational oversight, incident assignment, and playbook execution approvals.
- `VIEWER`: Read-only reporting access.

## 3. AI Safety & Prompt Injection Mitigation
- **Untrusted Input Wrapping**: All ingested logs, email texts, sender domains, and raw payloads are treated as untrusted data.
- **Strict Delimiters**: Prompts delivered to Gemini (`gemini-3.8-flash`) are isolated using strict schema constraints.
- **Grounded Verification**: The AI investigator is programmatically barred from executing database mutations or arbitrary shell commands. It operates in a strictly scoped, read-only analytical mode.
- **Fact vs Hypothesis Distinction**: The system requires evidence to cite verified database log IDs.

## 4. Controlled Execution & Anti-Destructive Controls
- **No Autonomous Destruction**: Perimeter IP blocks, host network isolations, and account lockouts require affirmative manual operator approval via SOAR gates.
- **Authorized Target Scoping**: Vulnerability scans (Nmap / OWASP ZAP) reject targets outside explicitly verified CIDR blocks and asset registrations.
- **Isolated URL Inspection**: PhishGuard AI never opens suspect URLs directly; all domain analysis occurs via DNS inspection and VirusTotal reputation queries.
